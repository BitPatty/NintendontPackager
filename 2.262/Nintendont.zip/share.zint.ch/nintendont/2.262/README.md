# Nintendont 2.262
Commit: ee8c96d1998c8e59764f6b4d0059332c3c75e10f  
Time: Mon Dec 22 15:27:07 2014   

-----

```
commit ee8c96d1998c8e59764f6b4d0059332c3c75e10f
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Dec 22 15:27:07 2014 +0000

    -Added Nunchuck support
```
