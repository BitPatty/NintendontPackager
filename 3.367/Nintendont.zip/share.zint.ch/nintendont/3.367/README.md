# Nintendont 3.367
Commit: db18d9785b404cdbcd486c30b4ee8a4a47987e63  
Time: Wed Aug 5 20:30:20 2015   

-----

```
commit db18d9785b404cdbcd486c30b4ee8a4a47987e63
Author: FIX94 <fix94.1@gmail.com>
Date:   Wed Aug 5 20:30:20 2015 +0200

    -changed some video mode patching hopefully for the better
    -disabling force progressive patch for mega man x collection simply because the game gets confused otherwise
```
