# Nintendont 1.128
Commit: 8aee5311ac78896e68d9d1d27ce728fda6f54856  
Time: Mon Jul 14 16:27:02 2014   

-----

```
commit 8aee5311ac78896e68d9d1d27ce728fda6f54856
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Jul 14 16:27:02 2014 +0000

    -added custom ARStartDMA crash solutions for paper mario, mario superstar baseball, need for speed hot pursuit 2, viewtiful joe, mega man x command mission and animal crossing
```
