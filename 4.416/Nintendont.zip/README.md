# Nintendont 4.416
Commit: 77fe0c3c47fb16ab53ea5bca3d435ee7d53e253b  
Time: Sat Jul 9 18:40:01 2016   

-----

```
commit 77fe0c3c47fb16ab53ea5bca3d435ee7d53e253b
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Jul 9 18:40:01 2016 +0200

    -enabled commented out fwrite patch again, works fine
    -made the patching system a little cleaner
    -compressed loader font to save some space
```
