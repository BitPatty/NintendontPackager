# Nintendont 2.208
Commit: 0c90405a68a7208bec330b4b9b19a9b60fc8828f  
Time: Thu Nov 6 22:35:56 2014   

-----

```
commit 0c90405a68a7208bec330b4b9b19a9b60fc8828f
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Thu Nov 6 22:35:56 2014 +0000

    -Fixed loaders inability to set video modes introduced in 2.204
    The first time you start this version If you are starting it from the homebrew channel set the video mode.
    This should fix black screens people were seeing in 2.204 - 2.207 that didn't occur in 2.03
```
