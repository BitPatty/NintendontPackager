# Nintendont 3.372
Commit: a3fd505c7fd563c62230705fbcc65c029d74af6f  
Time: Sat Sep 12 18:53:08 2015   

-----

```
commit a3fd505c7fd563c62230705fbcc65c029d74af6f
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Sep 12 18:53:08 2015 +0200

    oh yea, heres the .S file for the new widescreen patch if you want to compile it yourselfs
```

```
commit b02aea5a500bbb50fb6eb450cbec9c0c12b91c84
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Sep 12 18:50:51 2015 +0200

    -added skies of arcadia widescreen patch
    -fixed auto-format of japanese memory card emu files
```
