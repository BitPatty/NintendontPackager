# Nintendont 1.76
Commit: 7b46d248b11a138daea5a26dce492c11b7efdf0f  
Time: Mon Jun 2 22:26:46 2014   

-----

```
commit 7b46d248b11a138daea5a26dce492c11b7efdf0f
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Jun 2 22:26:46 2014 +0000

    -some more tiny changes which should let metroid prime boot again, fix controls in gp1, maybe more
```
