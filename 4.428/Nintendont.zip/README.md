# Nintendont 4.428
Commit: d8039dda7ee34dc9748a4b3eb2a2445fd8ab156f  
Time: Thu Dec 1 23:09:22 2016   

-----

```
commit d8039dda7ee34dc9748a4b3eb2a2445fd8ab156f
Author: FIX94 <fix94.1@gmail.com>
Date:   Thu Dec 1 23:09:22 2016 +0100

    fixed up compiler warnings
```

```
commit a5d7ea4e85a28f26d99f37436ba147865a690221
Merge: 2260400 135a25f
Author: FIX94 <fix94.1@gmail.com>
Date:   Thu Dec 1 22:34:34 2016 +0100

    Merge pull request #331 from GerbilSoft/widescreen-hax.r422
    
    CISO, MD5, cache fixes, and others
```
