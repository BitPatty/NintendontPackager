# Nintendont 2.155
Commit: 21dd8aaf967fb6a63bfe4e642351acb14bc71737  
Time: Mon Sep 8 21:02:41 2014   

-----

```
commit 21dd8aaf967fb6a63bfe4e642351acb14bc71737
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Sep 8 21:02:41 2014 +0000

    -changed up interrupt message reading a bit, fixes startup of luigis mansion
    -changed SI error message when no controller is connected, fixes burnout 2 and pandora tomorrow
    -added army men and cel damage to the multidol exception list, cel damage still doesnt work though, state of that game is unknown
    -increased rumble of the wiiu pro controller
    -improved the calculation accuracy of the wiiu pro controller analog sticks
```
