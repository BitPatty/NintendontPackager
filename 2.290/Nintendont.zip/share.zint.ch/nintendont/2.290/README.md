# Nintendont 2.290
Commit: 3e758e8fcdf66676c4b5e14a2a8f5aa175168940  
Time: Fri Feb 6 19:31:31 2015   

-----

```
commit 3e758e8fcdf66676c4b5e14a2a8f5aa175168940
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Feb 6 19:31:31 2015 +0000

    -removed menu timers from f-zero ax, thanks dj_skual
    -removed the rest of the menu timers in gp2 and made them invisible
    -changed the item and cancel button reading to a non-hacked version in both gp1 and gp2 so button presses wont happen multiple times in a row anymore
```
