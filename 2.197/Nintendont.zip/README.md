# Nintendont 2.197
Commit: a19294693efe0c4d8497041457f95490e7ed28a2  
Time: Mon Oct 27 23:08:59 2014   

-----

```
commit a19294693efe0c4d8497041457f95490e7ed28a2
Author: JoostinOnline@gmail.com <JoostinOnline@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Oct 27 23:08:59 2014 +0000

    -Most of the update system has been rewritten.  On the surface, the only change is that you can now download titles.txt in-app
```
