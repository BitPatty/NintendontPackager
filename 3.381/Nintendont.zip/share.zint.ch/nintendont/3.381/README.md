# Nintendont 3.381
Commit: 97c1ba153579552f5d24ae18ba44d9988bad7a5b  
Time: Sat Dec 12 17:41:37 2015   

-----

```
commit 97c1ba153579552f5d24ae18ba44d9988bad7a5b
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Dec 12 17:41:37 2015 +0100

    -properly setting the japanese triforce version of virtua striker 3 to japanese language if the game id equals GVS32J (as set by triforce-header-patcher)
```
