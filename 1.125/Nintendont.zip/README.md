# Nintendont 1.125
Commit: 9ad827cbe29429099e8947aff3cb8d54a0dfee26  
Time: Sun Jul 6 12:25:14 2014   

-----

```
commit 9ad827cbe29429099e8947aff3cb8d54a0dfee26
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Jul 6 12:25:14 2014 +0000

    -added new SIInit patch pattern for games like animal crossing ntscu
    -added animal crossing ntscu to the list of ARQPostRequest exceptions to get it boot up
```
