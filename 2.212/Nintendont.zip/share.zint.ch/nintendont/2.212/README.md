# Nintendont 2.212
Commit: c9588a258b426442cd5e057e2b1c1b2d242f36e7  
Time: Mon Nov 10 01:51:18 2014   

-----

```
commit c9588a258b426442cd5e057e2b1c1b2d242f36e7
Author: JoostinOnline@gmail.com <JoostinOnline@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Nov 10 01:51:18 2014 +0000

    Great, now PAL games don't work.  I'm reverting the UI until I can order a PAL game and test it out.
```
