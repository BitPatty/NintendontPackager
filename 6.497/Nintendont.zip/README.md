# Nintendont 6.497
[Direct Download](./Nintendont.zip)

Commit: bd8c5374d0d62f3e3fd3c9caf87f68ee5345383d  
Time: Sun Aug 29 01:15:29 2021   

-----

```
commit bd8c5374d0d62f3e3fd3c9caf87f68ee5345383d
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Sun Aug 29 01:15:29 2021 +0100

    Fixed sonic riders usa crash on tag
    
    Sonic riders ntsc needs isocache or else it freezes in tag mode, afew more pull requests added in too
```
