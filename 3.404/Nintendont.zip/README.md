# Nintendont 3.404
Commit: af2af1a9aa6bee5081fc0ba15933f6ab5ef7e2bb  
Time: Sat Jun 18 03:39:28 2016   

-----

```
commit af2af1a9aa6bee5081fc0ba15933f6ab5ef7e2bb
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Jun 18 03:39:28 2016 +0200

    -always set PAL50 flag as it seems to be the default PAL BIOS behavior, should fix PAL Ikaruga with no PAL BIOS present
```
