# Nintendont 2.184
Commit: 7f2c0872595fbd1334307a3088db0e65b678a6b1  
Time: Mon Oct 20 21:54:38 2014   

-----

```
commit 7f2c0872595fbd1334307a3088db0e65b678a6b1
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Oct 20 21:54:38 2014 +0000

    -searching much more detailed for PADInit so we dont miss it
    -reworked Patch31A0 to work with negative offsets too, fixes for example namco museum and midway arcade treasures 2
```
