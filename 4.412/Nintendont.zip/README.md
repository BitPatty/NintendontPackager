# Nintendont 4.412
Commit: 2d9ef2923ce0c86dae074ca6bf1b09d1dd926e3a  
Time: Mon Jun 27 17:41:45 2016   

-----

```
commit 2d9ef2923ce0c86dae074ca6bf1b09d1dd926e3a
Author: FIX94 <fix94.1@gmail.com>
Date:   Mon Jun 27 17:41:45 2016 +0200

    -fixed up the internal updater, since v4 it was broken so you have to update manually to this again working file and cleaned up the updater zip code
```
