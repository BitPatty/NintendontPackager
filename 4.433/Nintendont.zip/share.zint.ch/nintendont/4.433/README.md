# Nintendont 4.433
Commit: 76d3869f799638e659c0b67303179a0bd63c151c  
Time: Mon Jan 16 22:13:23 2017   

-----

```
commit 76d3869f799638e659c0b67303179a0bd63c151c
Author: FIX94 <fix94.1@gmail.com>
Date:   Mon Jan 16 22:13:23 2017 +0100

    -added new timer patch which now fixes resident evil 4 pal running too fast in pal50 mode
    -removed static killer7 pal50 patch since its now covered by the dynamic timer patch
```
