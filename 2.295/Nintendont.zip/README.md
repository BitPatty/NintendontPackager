# Nintendont 2.295
Commit: 95142149ee1bcc5bb8907e6a56a62cd62f200bf1  
Time: Wed Feb 11 00:20:57 2015   

-----

```
commit 95142149ee1bcc5bb8907e6a56a62cd62f200bf1
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Feb 11 00:20:57 2015 +0000

    -added some security checks for triforce CARD and settings writing
    -added missing code in ax CARD support which made it impossible for the game to read data if a settings file is in use
```
