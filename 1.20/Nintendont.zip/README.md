# Nintendont 1.20
Commit: 23ae0a0f8039a791a15d570ab35dcf46b68b32d1  
Time: Wed Apr 30 21:33:15 2014   

-----

```
commit 23ae0a0f8039a791a15d570ab35dcf46b68b32d1
Author: JoostinOnline@gmail.com <JoostinOnline@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Apr 30 21:33:15 2014 +0000

    -Cleaned up all the #ifdef DEBUG in kernel and loader, as they are pointless
    -gprintf can be disabled like dbgprintf
    -Added carriage return \r to all log code so nl_debug.log and ndebug.log can be read properly with Windows Notepad
```
