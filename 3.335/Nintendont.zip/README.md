# Nintendont 3.335
Commit: 244e61a97e5e62abb02ead0cabcde927ae2631c0  
Time: Fri May 15 00:34:54 2015   

-----

```
commit 244e61a97e5e62abb02ead0cabcde927ae2631c0
Author: FIX94 <fix94.1@gmail.com>
Date:   Fri May 15 00:34:54 2015 +0200

    -added a widescreen patch for both metroid prime 1 and 2, please note that I did not test it 100% so I cant say for sure that it works perfectly at all times
```
