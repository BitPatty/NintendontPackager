# Nintendont 2.214
Commit: 68c74a3f6e2d94e125ecb3aa9bcf3080d413695c  
Time: Tue Nov 11 17:35:11 2014   

-----

```
commit 68c74a3f6e2d94e125ecb3aa9bcf3080d413695c
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Nov 11 17:35:11 2014 +0000

    -Fixed Logitech RumblePad 2 and Rumble Gamepad F510 controller.ini Triggers
    -Fixed Auto video mode for region I & removed region G (Thanks Cyan)
```
