# Nintendont 3.334
Commit: 02faa71e32f87c2acf4b28bf9e753254e6761e85  
Time: Tue May 12 23:38:28 2015   

-----

```
commit 02faa71e32f87c2acf4b28bf9e753254e6761e85
Author: FIX94 <fix94.1@gmail.com>
Date:   Tue May 12 23:38:28 2015 +0200

    -updated download function to allow https downloads
    -fixed a small bug in Patch31A0 which might've affected a few games
```
