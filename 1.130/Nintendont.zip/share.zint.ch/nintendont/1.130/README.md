# Nintendont 1.130
Commit: 9c4791716c5fdea0c169fb1dc58082c765d642ac  
Time: Sun Jul 27 06:07:23 2014   

-----

```
commit 9c4791716c5fdea0c169fb1dc58082c765d642ac
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Jul 27 06:07:23 2014 +0000

    Add SIInterruptHandler C. Thanks sabykos.
    -Fixes The Simpsons Road Rage and Peach's castle Tech demo.
```
