# Nintendont 1.57
Commit: 0ef1f77e34a885bb57e693e4ebb0af28c015ff5f  
Time: Sat May 24 17:54:49 2014   

-----

```
commit 0ef1f77e34a885bb57e693e4ebb0af28c015ff5f
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat May 24 17:54:49 2014 +0000

    Don't patch ARQPostRequest for Metroid Prime.
```
