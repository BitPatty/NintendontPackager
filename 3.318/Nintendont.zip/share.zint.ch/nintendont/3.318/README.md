# Nintendont 3.318
Commit: dc1b0f3d2c971bceb866ef766e6f352a1a250dcd  
Time: Sat Mar 7 00:50:07 2015   

-----

```
commit dc1b0f3d2c971bceb866ef766e6f352a1a250dcd
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Mar 7 00:50:07 2015 +0000

    -added ReadROM patch when emu memcard is used, fixes issues with multiple reads in games such as mr driller drill land
```
