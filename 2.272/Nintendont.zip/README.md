# Nintendont 2.272
Commit: 093d8bc80b5dc887dac4da71fba9ccd93dd17f8c  
Time: Wed Jan 7 15:55:30 2015   

-----

```
commit 093d8bc80b5dc887dac4da71fba9ccd93dd17f8c
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Jan 7 15:55:30 2015 +0000

    -commented out some debug patches for ax which should let it start if OSReport is not enabled
    -forgot to actually use a updated function, made sure its used now
```
