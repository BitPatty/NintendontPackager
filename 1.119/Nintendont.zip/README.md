# Nintendont 1.119
Commit: d02a083b802af85b36fe361c8da2f4a4efe65fc3  
Time: Fri Jul 4 19:05:03 2014   

-----

```
commit d02a083b802af85b36fe361c8da2f4a4efe65fc3
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Jul 4 19:05:03 2014 +0000

    -completely removed the device ipl rom code, it will now be directly taken from the console
```
