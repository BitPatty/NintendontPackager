# Nintendont 6.500
[Direct Download](./Nintendont.zip)

Commit: 85130d6dab6c9b80b17c329816a660efd0da3bc4  
Time: Tue Mar 21 20:47:26 2023   

-----

```
commit 85130d6dab6c9b80b17c329816a660efd0da3bc4
Merge: a4c8e0e 6dfb129
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Tue Mar 21 20:47:26 2023 +0000

    Merge pull request #1088 from gilesep/Multiple-HID-Support
    
    Fix for issue 643 - Support multiple HID controllers.
```

```
commit a4c8e0e3bda8e49491ff8f4c64a5893cd290614b
Merge: 7b1b4cd 007e567
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Fri Jan 20 18:10:27 2023 +0000

    Merge pull request #1054 from ghostserverd/wiiugamepadslot-fix
    
    do not override WiiUGamepadSlot to 0 when NIN_CFG_AUTO_BOOT and HID_PAD_NONE
```
