# Nintendont 3.305
Commit: 6e9374f37f66c0c58b355565ae8e20f25cd53926  
Time: Mon Feb 23 16:43:31 2015   

-----

```
commit 6e9374f37f66c0c58b355565ae8e20f25cd53926
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Feb 23 16:43:31 2015 +0000

    -if no extension is plugged into your wiimote it will disconnect automatically after 20 seconds
    -in the triforce games you now need to hold the test button for 2 seconds in order to enter the test menu
```
