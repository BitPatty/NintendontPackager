# Nintendont 1.143
Commit: 5f76d6e73d3e782a5acfe4d9daabb8e6ddbd1abc  
Time: Sat Aug 16 04:23:05 2014   

-----

```
commit 5f76d6e73d3e782a5acfe4d9daabb8e6ddbd1abc
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Aug 16 04:23:05 2014 +0000

    -Added Support for Thrustmaster Dual Analog 4 (Thanks nastysdsi)
    -Fixed reading old version 2 of nincfg.bin so loaders that havent been upgraded will still work.
```
