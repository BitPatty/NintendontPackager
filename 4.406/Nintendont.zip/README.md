# Nintendont 4.406
Commit: 92e46d90c5e8c5e1b083e9a2ce56ddc80b49602d  
Time: Sat Jun 18 19:40:24 2016   

-----

```
commit 92e46d90c5e8c5e1b083e9a2ce56ddc80b49602d
Merge: 3c87be3 727dab4
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Jun 18 19:40:24 2016 +0200

    Merge pull request #262 from GerbilSoft/FatFS-use-in-loader
    
    Switch loader to FatFS; add support for exFAT.
```
