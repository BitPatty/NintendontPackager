# Nintendont 2.221
Commit: 62b8b0c8ed076023200037b404b9e15d9fc72c7c  
Time: Fri Nov 21 15:14:13 2014   

-----

```
commit 62b8b0c8ed076023200037b404b9e15d9fc72c7c
Author: JoostinOnline@gmail.com <JoostinOnline@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Nov 21 15:14:13 2014 +0000

    -Fixed previous status messages disappearing if there is an error
    -Fixed the menu info appearing one frame after the games/options
    -251 blocks is now listed as recommended in the "Memcard Blocks" option
    -Set the groundwork for a timeout if the drive doesn't respond.  This doesn't work yet, and I can't finish it until I receive a drive that doesn't work (it's coming)
    -Moved the options up 13 pixels for people who had the bottom cut off
    -A few minor cleanups.
```
