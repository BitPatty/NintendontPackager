# Nintendont 3.395
Commit: af0292c4d38f243b206087ac0b13e6e954af6168  
Time: Thu May 19 23:51:52 2016   

-----

```
commit af0292c4d38f243b206087ac0b13e6e954af6168
Author: FIX94 <fix94.1@gmail.com>
Date:   Thu May 19 23:51:52 2016 +0200

    -made the patching system a little quicker by doing some things only once
    -added a potential fix for original nintendo memory cards not being mounted by the ntsc 1.0 bios (untested)
```
