# Nintendont 3.336
Commit: 03136e7d6f8ab825ea536693270db0824aca4c7b  
Time: Fri May 15 16:17:41 2015   

-----

```
commit 03136e7d6f8ab825ea536693270db0824aca4c7b
Author: FIX94 <fix94.1@gmail.com>
Date:   Fri May 15 16:17:41 2015 +0200

    -removed the need of kenobiwii by including a codehandler into the kernel, this codehandler has a higher compatibility with codes and can load more cheats total (gcts up to 8KB)
```
