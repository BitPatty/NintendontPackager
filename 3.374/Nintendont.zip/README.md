# Nintendont 3.374
Commit: 1b55dd12e540bc4b0d29de5b9742a2549a2ae066  
Time: Fri Nov 6 19:35:10 2015   

-----

```
commit 1b55dd12e540bc4b0d29de5b9742a2549a2ae066
Author: FIX94 <fix94.1@gmail.com>
Date:   Fri Nov 6 19:35:10 2015 +0100

    -added support for triforce games virtua striker 3 (jap and exp), virtua striker 4 (jap and exp) and virtua striker 4 ver 2006 jap
```
