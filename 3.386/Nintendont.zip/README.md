# Nintendont 3.386
Commit: 0c7f48475047cf472a0422a183fde1a9165febc3  
Time: Sun Feb 14 15:37:54 2016   

-----

```
commit 0c7f48475047cf472a0422a183fde1a9165febc3
Merge: 80a92e4 9715588
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Feb 14 15:37:54 2016 +0100

    Merge pull request #203 from GerbilSoft/gpt-support-fix-8GB
    
    [GPT] Fix support for drives >= 8 GB.
```

```
commit 80a92e4939dc1e2f7bceb7fce4b68344ded8f1cd
Author: FIX94 <fix94.1@gmail.com>
Date:   Fri Feb 5 15:57:00 2016 +0100

    -pushed up version number to 386
```
