# Nintendont 1.110
Commit: 97e9fc3e9022490fcca568f6c37a6217e596bbe0  
Time: Tue Jul 1 12:57:04 2014   

-----

```
commit 97e9fc3e9022490fcca568f6c37a6217e596bbe0
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Jul 1 12:57:04 2014 +0000

    Fix swapped widescreen/progressive options.
```
