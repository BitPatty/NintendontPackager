# Nintendont 6.501
[Direct Download](./Nintendont.zip)

Commit: 3a70496b4345a701e22300ea366416349302551c  
Time: Sat Jul 27 10:25:21 2024   

-----

```
commit 3a70496b4345a701e22300ea366416349302551c
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Sat Jul 27 10:25:21 2024 +0100

    Added rumble to dualshock 4 v1 and v2
    
    Thanks to MetaheuristicaCucei only tested v1 ds4 since i dont have a v2  just redownload or udated your controller.ini files to get rumble.
```

```
commit 8b140805db8882adcc9af5d293288b3aa77da457
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Thu Aug 24 19:40:52 2023 +0100

    Logic fixes on controller order
    
    Some logic fixes to wiiugamepad slot and hid controllers
    If wiiu gamepad slot is now set to player one it will have priority over wiiugc adapter player 1 slot which will be disabled, slots 2 two 4 will still work on wiiugc adapter and the likes.
```
