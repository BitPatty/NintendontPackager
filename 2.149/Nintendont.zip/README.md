# Nintendont 2.149
Commit: 336b2a7664716f507a2e085ce3d01247796dbd03  
Time: Mon Aug 25 00:39:19 2014   

-----

```
commit 336b2a7664716f507a2e085ce3d01247796dbd03
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Aug 25 00:39:19 2014 +0000

    -Added support for Mayflash Classic controller Pro USB Adapter - PC045 This requires updating nintendont and the controller.ini (THANKS CoreyW)
    -Fixed Dpad=1 not allowing the dpad and some other control to be used at the same time (Thanks CoreyW)
    -Fixed MayFlash Wii CC USB Adapter - PC052 controller.ini triggers
```
