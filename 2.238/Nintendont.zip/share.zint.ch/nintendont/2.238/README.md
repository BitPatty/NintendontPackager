# Nintendont 2.238
Commit: 4677920cf602367a7f6a7ac43b6386704289a72b  
Time: Fri Dec 5 17:03:48 2014   

-----

```
commit 4677920cf602367a7f6a7ac43b6386704289a72b
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Dec 5 17:03:48 2014 +0000

    -added a libfat version to the nintendont loader which supports ustealth and updated the kernel fatfs version to the latest 0.10c
```
