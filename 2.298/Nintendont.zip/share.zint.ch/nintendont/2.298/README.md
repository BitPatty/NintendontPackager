# Nintendont 2.298
Commit: 90c0c62b3594d5f713249b70142148ece8a94135  
Time: Mon Feb 16 18:46:36 2015   

-----

```
commit 90c0c62b3594d5f713249b70142148ece8a94135
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Feb 16 18:46:36 2015 +0000

    -added missing h files
    -modified HID code the same way USB was modified so it should work again
    -updated fatfs to the latest v0.11
    -made various usb sync changes to hopefully work more stable
```
