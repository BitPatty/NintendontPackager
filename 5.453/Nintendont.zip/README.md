# Nintendont 5.453
Commit: f67b94cc2d5a1673aa4fd467bf30aa9edaf31983  
Time: Sat Sep 16 07:32:13 2017   

-----

```
commit f67b94cc2d5a1673aa4fd467bf30aa9edaf31983
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Sep 16 07:32:13 2017 +0200

    fixed possible loader crash
```
