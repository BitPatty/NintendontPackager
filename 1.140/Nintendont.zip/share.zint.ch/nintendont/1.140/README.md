# Nintendont 1.140
Commit: 64b46f6354c74e792ae2136af06170585fa1dba4  
Time: Fri Aug 8 09:10:01 2014   

-----

```
commit 64b46f6354c74e792ae2136af06170585fa1dba4
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Aug 8 09:10:01 2014 +0000

    -added hardcoded timer patch for majoras mask pal and ntscu
```
