# Nintendont 2.234
Commit: 539e5142b8b2e18298009ca5430985dd1bbad910  
Time: Sun Nov 30 21:27:35 2014   

-----

```
commit 539e5142b8b2e18298009ca5430985dd1bbad910
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Nov 30 21:27:35 2014 +0000

    -some general cleanup, changed the kernel build mode which makes it run a bit smoother overall
```
