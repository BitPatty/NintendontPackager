# Nintendont 3.371
Commit: 11b5b242c55d5709c8782957b80e6450ca090b85  
Time: Wed Aug 12 23:15:57 2015   

-----

```
commit 11b5b242c55d5709c8782957b80e6450ca090b85
Author: FIX94 <fix94.1@gmail.com>
Date:   Wed Aug 12 23:15:57 2015 +0200

    -added Doubutsu no Mori e+ into the arstartdma exception list (how did I miss this?)
```
