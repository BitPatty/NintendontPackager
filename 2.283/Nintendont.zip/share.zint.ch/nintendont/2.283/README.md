# Nintendont 2.283
Commit: 327718552d037a348d75f30c345b6f9f28cd664a  
Time: Sun Jan 25 21:59:21 2015   

-----

```
commit 327718552d037a348d75f30c345b6f9f28cd664a
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Jan 25 21:59:21 2015 +0000

    -made __GXSetVAT patch a bit more dynamic and added smugglers run into its list, should fix the freezes it had
```
