# Nintendont 1.51
Commit: 63817a58d5c4556fbdf34543ee1615ce456b37e9  
Time: Sun May 18 01:12:37 2014   

-----

```
commit 63817a58d5c4556fbdf34543ee1615ce456b37e9
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun May 18 01:12:37 2014 +0000

    Generate .h files from .S files.
    Generate .S files for DVDInquiryAsync and DVDSeekAbsAsyncPrio.
    Remove built files from repository.
    Simplify PadStub calling (use a global location for PadBuff).
```
