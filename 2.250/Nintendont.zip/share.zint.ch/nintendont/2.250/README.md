# Nintendont 2.250
Commit: a5798e9feed8ffe50c2b33500e0aaa2b0917b9c8  
Time: Thu Dec 11 01:44:29 2014   

-----

```
commit a5798e9feed8ffe50c2b33500e0aaa2b0917b9c8
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Thu Dec 11 01:44:29 2014 +0000

    -Fix Datel AGP to use the simpler DVD patching in r249.
```
