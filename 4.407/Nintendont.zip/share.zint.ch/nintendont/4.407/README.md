# Nintendont 4.407
Commit: f115ac5d86f3c705c1e49b4b09ecf3fed3ea800e  
Time: Sat Jun 18 20:04:01 2016   

-----

```
commit f115ac5d86f3c705c1e49b4b09ecf3fed3ea800e
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Jun 18 20:04:01 2016 +0200

    Nintendont is now officially in major version 4! Make sure to read the NEWS.md to find out more about all the changes since the last major version.
```
