# Nintendont 1.69
Commit: a096c164b729b41f36ad690744e2aa22096ff078  
Time: Wed May 28 15:25:42 2014   

-----

```
commit a096c164b729b41f36ad690744e2aa22096ff078
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed May 28 15:25:42 2014 +0000

    -use the original ARStartDMA code, only patch it for megaman x command mission, fixes metroid prime 1 and 2
    -fixed a small bug in the auto-cache
    -changed the disc read thread code a bit
```
