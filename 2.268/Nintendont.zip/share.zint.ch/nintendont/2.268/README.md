# Nintendont 2.268
Commit: 002f1f0fe380cc3dcb9532bcd36bd7fce517c135  
Time: Fri Jan 2 15:54:21 2015   

-----

```
commit 002f1f0fe380cc3dcb9532bcd36bd7fce517c135
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Jan 2 15:54:21 2015 +0000

    -cleaned up some patching, triforce games now have a bit less patching in order to run
    -added a bit of security when reading data
```
