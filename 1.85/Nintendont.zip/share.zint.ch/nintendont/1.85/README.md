# Nintendont 1.85
Commit: ba3a3995a920b6636b8679b552bbc517b9491e66  
Time: Sun Jun 15 05:00:39 2014   

-----

```
commit ba3a3995a920b6636b8679b552bbc517b9491e66
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Jun 15 05:00:39 2014 +0000

    Clean up changes to SI.
```
