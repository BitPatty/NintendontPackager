# Nintendont 2.293
Commit: b24b32c83ae0516a7125786b488e4601fcb5c07e  
Time: Mon Feb 9 17:56:44 2015   

-----

```
commit b24b32c83ae0516a7125786b488e4601fcb5c07e
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Feb 9 17:56:44 2015 +0000

    -activated CARD support in f-zero ax, please note that on saving and loading the screen will be frozen until its finished but you can hear on the audio the game still runs
    -slighly slimmed down the triforce game data being constantly sent to nintendont to make it more smooth
    -added a "Free Play" patch to SegaBoot so started triforce games will now use that
```
