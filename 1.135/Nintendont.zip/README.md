# Nintendont 1.135
Commit: 6eb7376f35133d09dd0f0a18c93e7e9fdd19e2c0  
Time: Wed Aug 6 02:38:31 2014   

-----

```
commit 6eb7376f35133d09dd0f0a18c93e7e9fdd19e2c0
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Aug 6 02:38:31 2014 +0000

    Add support for multiple saves in a single memory card file.
    Add support for selecting memcard size.
    Prevent disc reads beyond the end of the buffer.
    Check for controller.ini.ini if can't find correct file.
```
