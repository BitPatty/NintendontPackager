# Nintendont 2.189
Commit: c2c1fa62ac8805d34e8e0c78c6989893ebbb6c5e  
Time: Wed Oct 22 23:29:15 2014   

-----

```
commit c2c1fa62ac8805d34e8e0c78c6989893ebbb6c5e
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Oct 22 23:29:15 2014 +0000

    Make PATCHSI a menu selectable option (Native Control On means PATCHSI is disabled).
```
