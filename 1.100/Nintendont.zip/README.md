# Nintendont 1.100
Commit: cc49e6ab42e776db1fe238d82cf8181221f56242  
Time: Thu Jun 26 23:27:42 2014   

-----

```
commit cc49e6ab42e776db1fe238d82cf8181221f56242
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Thu Jun 26 23:27:42 2014 +0000

    PI_FIFO_WP bit fix.
    -Fixes F-Zero GX
    Minor Zelda DSP clean up.
    Disable _fwrite D patch.  Doesn't appear to be the right function to patch.
    Speed up hexdump.
    -Perform 1 file write per line of text with a buffer instead of 35 without.
```
