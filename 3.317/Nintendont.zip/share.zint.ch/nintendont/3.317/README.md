# Nintendont 3.317
Commit: c7698e49c1c1b45e29a988a1719bd087fd805df9  
Time: Fri Mar 6 15:57:39 2015   

-----

```
commit c7698e49c1c1b45e29a988a1719bd087fd805df9
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Mar 6 15:57:39 2015 +0000

    -fixed a tiny mistake in the read speed code
    -added the resident evil 4 demo to the arstartdma exception list to fix it
```
