# Nintendont 2.261
Commit: 7a86d70cdb1db07566e1f649262ef2b60be66ed8  
Time: Sun Dec 21 15:27:58 2014   

-----

```
commit 7a86d70cdb1db07566e1f649262ef2b60be66ed8
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Dec 21 15:27:58 2014 +0000

    -fixed a little bug in disc reading which now fixes reading burned gc discs on old wiis
```
