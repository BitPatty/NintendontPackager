# Nintendont 1.30
Commit: 019120650bf16b8f53791757faa2723c501a10fa  
Time: Wed May 7 21:25:30 2014   

-----

```
commit 019120650bf16b8f53791757faa2723c501a10fa
Author: JoostinOnline@gmail.com <JoostinOnline@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed May 7 21:25:30 2014 +0000

    -Made the cache code a little easier to read
    -Added note about not enabling DEBUG and DEBUG_DI at the same time (looking into it, problem is in Patch.c)
```
