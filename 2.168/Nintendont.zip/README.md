# Nintendont 2.168
Commit: b53d82954f43059c3790d7a6f45b028b40941cc1  
Time: Thu Oct 9 21:01:38 2014   

-----

```
commit b53d82954f43059c3790d7a6f45b028b40941cc1
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Thu Oct 9 21:01:38 2014 +0000

    -added a bit of code to actually allow usage of a real memory card on wii when memory card emulation is turned off
    -added a small compiler option in global.h, PATCHSI, if you comment out this option and recompile nintendont it will use the original gamecube pad ports instead of emulating them, allowing accessories like gba and bongos but will remove things like hid, bluetooth and return to loader
```
