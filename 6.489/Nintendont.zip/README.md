# Nintendont 6.489
Commit: e178ac3455f107bcd6c8212df2c658463c211397  
Time: Tue Nov 5 00:19:50 2019   

-----

```
commit e178ac3455f107bcd6c8212df2c658463c211397
Author: FIX94 <fix94.1@gmail.com>
Date:   Tue Nov 5 00:19:50 2019 +0100

    finally uploaded small helper tool I've been using over the years, may be useful to some people wanting to work on nintendont a bit more in depth
```

```
commit bd19357571a3c049f2d7e5e35fb50af2b2a7e41a
Author: FIX94 <fix94.1@gmail.com>
Date:   Mon Oct 14 21:41:27 2019 +0200

    Update BBA_Readme.md
```

```
commit 2dfa4fdb9766edd030dc021797abe6bcbd53212e
Author: FIX94 <fix94.1@gmail.com>
Date:   Tue Oct 8 03:54:44 2019 +0200

    forgot to update small part of code for majoras mask patch
```
