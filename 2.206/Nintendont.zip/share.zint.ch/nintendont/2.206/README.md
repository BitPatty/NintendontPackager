# Nintendont 2.206
Commit: 64481488cb0659afebaf162c0e11f8faa00d4b6c  
Time: Mon Nov 3 17:29:13 2014   

-----

```
commit 64481488cb0659afebaf162c0e11f8faa00d4b6c
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Nov 3 17:29:13 2014 +0000

    -changed up game loading in order to make the loader dol size much more expandable
```
