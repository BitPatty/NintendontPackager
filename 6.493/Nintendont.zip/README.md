# Nintendont 6.493
Commit: 098b55fd946a97ec87ebbf6b94d53a45a53aac4c  
Time: Mon May 10 20:28:09 2021   

-----

```
commit 098b55fd946a97ec87ebbf6b94d53a45a53aac4c
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Mon May 10 20:28:09 2021 +0100

    Some mergers and updated version
    
    You will need to redo all your settings again, since the menu was changed you settings will be ignored, just redo them.
    
    merged fix for Gc controllers that had more range than regular gc controllers and behaved erraticaly on wiiu gc adapters or real wii with gc ports by Aurelio92
    
    Merged wiiu gamepad position  which can now be changed in nintendont sesstings position 1-4 or noone by sailormoon
    
    Changed the ps4 ini power button which should now alow you to exit by using the share button again.
```
