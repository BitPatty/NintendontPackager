# Nintendont 2.269
Commit: c20196159660ffa9a8a1e3336c70bf54c0d90261  
Time: Fri Jan 2 20:32:02 2015   

-----

```
commit c20196159660ffa9a8a1e3336c70bf54c0d90261
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Jan 2 20:32:02 2015 +0000

    -fixed up gc disc reading of multi-iso discs created with very old tools
    -more security updates to try to fix return to loader freezing
```
