# Nintendont 3.311
Commit: 3504c35a55860c1def9de51c612ef1277421fd91  
Time: Sun Mar 1 21:05:35 2015   

-----

```
commit 3504c35a55860c1def9de51c612ef1277421fd91
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Mar 1 21:05:35 2015 +0000

    -wrote a special arstartdma exception for the last 2 broken games, ghost recon 2 and rainbow six 3, now both should run just fine
```
