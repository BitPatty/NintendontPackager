# Nintendont 5.483
Commit: 10f52316a67d955e2c9608ae6cefc277ccfb8abe  
Time: Sun Mar 18 22:06:48 2018   

-----

```
commit 10f52316a67d955e2c9608ae6cefc277ccfb8abe
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Mar 18 22:06:48 2018 +0100

    made sure the native control option has no effect on wiiu when its enabled
```
