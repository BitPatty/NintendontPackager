# Nintendont 3.349
Commit: 5607fd71cd47c50589c204e266fbb71a1ece1c3b  
Time: Thu Jun 25 17:22:36 2015   

-----

```
commit 5607fd71cd47c50589c204e266fbb71a1ece1c3b
Author: FIX94 <fix94.1@gmail.com>
Date:   Thu Jun 25 17:22:36 2015 +0200

    -added a patch for Capcom vs. SNK 2 EO NTSC to work with force progressive
```
