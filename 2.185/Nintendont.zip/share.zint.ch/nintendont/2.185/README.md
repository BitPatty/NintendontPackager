# Nintendont 2.185
Commit: 4a5d74f06c00bbf714f80726f04c384f101c3f2a  
Time: Tue Oct 21 08:13:45 2014   

-----

```
commit 4a5d74f06c00bbf714f80726f04c384f101c3f2a
Author: JoostinOnline@gmail.com <JoostinOnline@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Oct 21 08:13:45 2014 +0000

    -Added database support for those unsightly game names.  Copy the included titles.txt to your Nintendont directory
    -The loader now updates the meta.xml file prior to checking for AHB access, so you don't have to fix the meta.xml file manually.
    
    Note: To save space, the database doesn't care about region.
```
