# Nintendont 2.148
Commit: e326f208d097c2f0c79e067adabac3917f7b1aba  
Time: Wed Aug 20 00:23:09 2014   

-----

```
commit e326f208d097c2f0c79e067adabac3917f7b1aba
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Aug 20 00:23:09 2014 +0000

    -if language is set to auto, actually set the language according to the system config (fixes games like batman begins)
```
