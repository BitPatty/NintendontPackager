# Nintendont 2.223
Commit: 254a57843cb7319389f1e4d9c68ed44daeca1e1e  
Time: Sat Nov 22 15:31:14 2014   

-----

```
commit 254a57843cb7319389f1e4d9c68ed44daeca1e1e
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Nov 22 15:31:14 2014 +0000

    -made it more simple to modify the memcard emu timings, added timing exceptions for starfox assault and luigis mansion in a simple way
    -when you selected a device to load your games from nintendont will display a small loading message to confirm that it is loading the game list, this should hopefully help to avoid confusion if nintendont actually regonized the button press
```
