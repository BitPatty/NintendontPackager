# Nintendont 5.462
Commit: 3e81dadcfc4b19129f08a947905331f1d45a1b0b  
Time: Sat Sep 23 23:15:14 2017   

-----

```
commit 3e81dadcfc4b19129f08a947905331f1d45a1b0b
Merge: 7bb1e4d 629f7ad
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Sep 23 23:15:14 2017 +0200

    Merge pull request #474 from GerbilSoft/feature/MemCard-hax.r462
    
    MemCard Hax branch: Support for Slot B; saving optimizations.
```

```
commit 7bb1e4d23d97bd0a70f4abf626b5fc97dc0c2685
Author: FIX94 <fix94.1@gmail.com>
Date:   Fri Sep 22 19:15:25 2017 +0200

    looks like the loader dol didnt get pushed yet again
```

```
commit c83f4e1b06d7e240d2cf436aea9cc26ec61305db
Author: FIX94 <fix94.1@gmail.com>
Date:   Fri Sep 22 10:36:56 2017 +0200

    added gamepad ABXY switching by pressing minus just like on a wiiu pro controller
```
