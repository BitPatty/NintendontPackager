# Nintendont 4.424
Commit: c8e194dee0ac2fc7c4bc685d106994af033f528b  
Time: Fri Oct 14 02:39:40 2016   

-----

```
commit c8e194dee0ac2fc7c4bc685d106994af033f528b
Author: FIX94 <fix94.1@gmail.com>
Date:   Fri Oct 14 02:39:40 2016 +0200

    -added a new option called "TRI Arcade Mode", enabling this will remove all timer patches and the free play patch from triforce games giving it a more original feel, to insert coins in this mode just move the c-stick into any direction
    -fixed a bug which made nintendont crash on startup with no FAT device found, now it will properly exit
```
