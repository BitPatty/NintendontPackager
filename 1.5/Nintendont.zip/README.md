# Nintendont 1.5
Commit: 5a3b3c13e29ec53e5b1d987ebf8a56b072ae1036  
Time: Mon Apr 28 17:24:14 2014   

-----

```
commit 5a3b3c13e29ec53e5b1d987ebf8a56b072ae1036
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Apr 28 17:24:14 2014 +0000

    -attempted to fix crashes on autoboot, on return to homebrew channel and when using memory card emulation
```
