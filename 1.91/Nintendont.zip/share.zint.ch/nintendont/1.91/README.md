# Nintendont 1.91
Commit: e6049c78f1a39a305a9d35889d8c9330d31c802e  
Time: Wed Jun 18 15:11:26 2014   

-----

```
commit e6049c78f1a39a305a9d35889d8c9330d31c802e
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Jun 18 15:11:26 2014 +0000

    -fixed the issue that after playing a japanese gc game with a console from a different region the other games get started as japanese games if you used the return to feature
    -fixed the issue that non-japanese games on japanese consoles always get started like japanese games
```
