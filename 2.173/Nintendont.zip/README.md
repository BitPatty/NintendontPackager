# Nintendont 2.173
Commit: 05bf01a3e8cecbbce9336f417658f5f00bd6afc0  
Time: Mon Oct 13 23:42:19 2014   

-----

```
commit 05bf01a3e8cecbbce9336f417658f5f00bd6afc0
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Oct 13 23:42:19 2014 +0000

    -added micro machines to the ARStartDMA exception list to help it stabilize
    -assume on ELF loading that the header is already loaded in the buffer, fixes sonic cd
```
