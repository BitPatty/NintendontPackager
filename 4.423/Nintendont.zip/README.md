# Nintendont 4.423
Commit: ad9ad25eb572e85d2ecef91206cced751fc89059  
Time: Sat Sep 24 19:30:49 2016   

-----

```
commit ad9ad25eb572e85d2ecef91206cced751fc89059
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Sep 24 19:30:49 2016 +0200

    -when launching games through another loader nintendont will now boot silently so it will just stay on a black screen until the game comes up or an error occurs
```
