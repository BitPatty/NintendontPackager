# Nintendont 3.316
Commit: 44d6d6f795367aa32bf26ccff0229a40c4e4262b  
Time: Fri Mar 6 01:53:36 2015   

-----

```
commit 44d6d6f795367aa32bf26ccff0229a40c4e4262b
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Mar 6 01:53:36 2015 +0000

    -further worked on the disc read speed emulation, now it (more or less) emulates the disc drive caching which quite alot of games were dependent on, those should now run at a more proper speed again
```
