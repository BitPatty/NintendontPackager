# Nintendont 1.31
Commit: a240e7d2d88ae3710415b5f2d5349c7c8e59a199  
Time: Wed May 7 22:38:24 2014   

-----

```
commit a240e7d2d88ae3710415b5f2d5349c7c8e59a199
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed May 7 22:38:24 2014 +0000

    -made the disc read threaded, that should greatly reduce the random beeps in games if you go from one screen to another and also should improve control reaction times
    -moved up most of the memory positions to make space for the cache
```
