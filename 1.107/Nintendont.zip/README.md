# Nintendont 1.107
Commit: 246eafd3f3432d46b362a78cfe1a3269c00efbc6  
Time: Mon Jun 30 05:58:38 2014   

-----

```
commit 246eafd3f3432d46b362a78cfe1a3269c00efbc6
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Jun 30 05:58:38 2014 +0000

    Skip GC pad read on Wii U.
```
