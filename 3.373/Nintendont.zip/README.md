# Nintendont 3.373
Commit: 9ebaad042577e5cf1fae1c3f191f18f6824a04cf  
Time: Tue Sep 29 20:20:37 2015   

-----

```
commit 9ebaad042577e5cf1fae1c3f191f18f6824a04cf
Author: FIX94 <fix94.1@gmail.com>
Date:   Tue Sep 29 20:20:37 2015 +0200

    -removed the deflicker flag from the nintendont loader to make it sharper and more readable
    -fixed small timer code problem with gt cube
```
