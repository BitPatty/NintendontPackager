# Nintendont 1.94
Commit: 7388730781a67e6c8d6abc392ad2e2c89411eea7  
Time: Fri Jun 20 17:04:10 2014   

-----

```
commit 7388730781a67e6c8d6abc392ad2e2c89411eea7
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Jun 20 17:04:10 2014 +0000

    -Fixed reference  to old website (Thanks Naxil)
```

```
commit a49c64dbf1d451183dcd648931990b328eadc9e2
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Jun 20 03:21:37 2014 +0000

    Add Dsp v12 (Pikmin PAL).
    Cleaned up Zelda Dsp patching code.
```
