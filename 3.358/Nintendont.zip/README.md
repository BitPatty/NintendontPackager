# Nintendont 3.358
Commit: b6450f96d93442b8f84a4620d39f3eca14b06730  
Time: Sat Jul 18 13:16:59 2015   

-----

```
commit b6450f96d93442b8f84a4620d39f3eca14b06730
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Jul 18 13:16:59 2015 +0200

    -added option to disable the read speed limiter, note that doing that will lower the overall game compatibility
    -added better configuration updater so old loaders should be better supported
    -to other loaders:updated the configuration again
```
