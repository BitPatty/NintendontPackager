# Nintendont 2.271
Commit: e85d02e90cb496ed151620c86b7b52e812b9ca16  
Time: Mon Jan 5 16:22:31 2015   

-----

```
commit e85d02e90cb496ed151620c86b7b52e812b9ca16
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Jan 5 16:22:31 2015 +0000

    -changed out some buffers in jvsio and changed some flushing code in order to help out triforce random crashes, missing controls and problems
    -changed the default triforce ingame coin count to 9 so just in case it doesnt automatically refresh the coins you dont run out directly and may get lucky on the next coin update to get new coins
    -commented out some possibly problematic debug code which might crash games on bootup
    -added ARStartDMA exceptions for both Multi-Game Demo Disc 18 and Street Racing Syndicate
```
