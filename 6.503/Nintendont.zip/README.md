# Nintendont 6.503
[Direct Download](./Nintendont.zip)

Commit: bb96878ff19241d8bc2467be47920efc4ba95df5  
Time: Tue Apr 29 21:52:22 2025   

-----

```
commit bb96878ff19241d8bc2467be47920efc4ba95df5
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Tue Apr 29 21:52:22 2025 +0100

    just some merges and recompile to fix on exit.
```

```
commit cec724a7970ba36a93e66e301dfe19c3863d9521
Merge: 7b4f9a7 a3a225a
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Tue Apr 29 21:45:39 2025 +0100

    Merge pull request #1164 from pftmclub/custom_controllers
    
    Add support for Qanba Drone  Arcade Stick
```

```
commit 7b4f9a7339176a6957e551ad511bcaf8c75292f7
Merge: 7a37912 a1a99cd
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Tue Apr 29 21:40:21 2025 +0100

    Merge pull request #1188 from caleb39411/dualsense-edge
    
    Add DualSense Edge support
```

```
commit 7a37912fa707e2a6c32da0c01143b331c2f10026
Merge: b500012 a3e0b29
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Tue Apr 29 21:39:41 2025 +0100

    Merge pull request #1213 from ShadowTheHedgehogHacking/master
    
    Oversized Image Support
```

```
commit b500012dedf2adb5fc9881eeb02dc47b7959a2a5
Merge: 97cecec f2a77fa
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Tue Apr 29 21:38:47 2025 +0100

    Merge pull request #1220 from GameCubeOnline/master
    
    Add support for BBA
```

```
commit 97cecec54a655eb62b411b6b6815a71b077e2cae
Merge: 0e1a521 d9e7661
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Tue Apr 29 21:38:08 2025 +0100

    Merge pull request #1237 from NewGBAXL/master
    
    Patch all regions of HomeLand and Nintendo Puzzle Collection
```

```
commit 0e1a5216da66d2199c18e1b8fe41ab8211c2456b
Merge: d8278cd 0ab6ac6
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Tue Apr 29 21:37:35 2025 +0100

    Merge pull request #1242 from zardam/fix_wiiu_gc_adapter_clone_not_working
    
    Fix Wii U adapter clone not working in Wii U mode
```

```
commit d8278cddf1b84b5b4da9605be27a0dbc889c95a2
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Tue Apr 29 21:35:05 2025 +0100

    Update NintendontVersion.h
```
