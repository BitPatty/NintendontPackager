# Nintendont 3.309
Commit: d913cb23a8b1c9cb49918f7c3bf2519ad7ef903f  
Time: Sat Feb 28 23:42:03 2015   

-----

```
commit d913cb23a8b1c9cb49918f7c3bf2519ad7ef903f
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Feb 28 23:42:03 2015 +0000

    -added a code fix for certain crashes in x-men legends 2
    -excluded sonic fighers from the arstartdma list
```
