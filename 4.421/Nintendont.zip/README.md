# Nintendont 4.421
Commit: a43bacb9af2b143e660e6b33bed0bf0bd52701fe  
Time: Sat Jul 23 03:14:30 2016   

-----

```
commit a43bacb9af2b143e660e6b33bed0bf0bd52701fe
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Jul 23 03:14:30 2016 +0200

    -added back OSSleepThread hook since it might catch some cases of cheats which have to be applied very often every second which the PADRead hook cant get
```
