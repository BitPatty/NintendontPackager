# Nintendont 1.93
Commit: 667e55b801dc894ba9d19837d3f4de26ca515b74  
Time: Thu Jun 19 02:08:12 2014   

-----

```
commit 667e55b801dc894ba9d19837d3f4de26ca515b74
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Thu Jun 19 02:08:12 2014 +0000

    -Fixed HUGE omission in the meta file.
    It doesn't affect compatibility so no new dol.
```

```
commit 94f8923dbdb1a4006874ffa8d8162916d5208e2a
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Thu Jun 19 01:29:50 2014 +0000

    Corrected name for SIEnablePollingInterrupt (was SIReadHandler).
    Fixed SIEnablePollingInterrupt.
    -Mistakenly thought a patch was needed for an interrupt bit.  It was actually the mask bit.
    -Fixes Pokemon Colosseum.
```
