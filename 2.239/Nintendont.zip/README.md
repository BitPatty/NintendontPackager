# Nintendont 2.239
Commit: ecb2ae2a284da53a4ff7b2441cca05438310e53d  
Time: Sat Dec 6 21:02:56 2014   

-----

```
commit ecb2ae2a284da53a4ff7b2441cca05438310e53d
Author: JoostinOnline@gmail.com <JoostinOnline@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Dec 6 21:02:56 2014 +0000

    -Reworked part of how the update system works
    -HID files are now saved to the drive with games, not the drive that Nintendont was launched from.
    -You are now given a choice to redownload the latest version in case someone forgets to update NintendontVersion.h
    -Changed the update menu to be scrollable.
    -Menus use an actual arrow now instead of a greater/lesser than symbol.
    -Got rid of the loader.h/loader.c files since they haven't been necessary for I don't know how long
    -A little minor cleanup.
```
