# Nintendont 5.485
Commit: 467cf2a4666823eb7a98adc5d0b1ca17e61132ff  
Time: Sun Aug 26 14:28:10 2018   

-----

```
commit 467cf2a4666823eb7a98adc5d0b1ca17e61132ff
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Aug 26 14:28:10 2018 +0200

    -fixed triforce games not booting after last update
    -if the mpal bios is detected and video is set to auto, it will now boot in pal-m mode
```
