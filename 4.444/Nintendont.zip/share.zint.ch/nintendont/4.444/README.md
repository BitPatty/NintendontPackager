# Nintendont 4.444
Commit: 5f3cda5908ba17e83294768690e3ff8542c09c65  
Time: Sat May 20 04:44:55 2017   

-----

```
commit 5f3cda5908ba17e83294768690e3ff8542c09c65
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat May 20 04:44:55 2017 +0200

    -added missing triforce titles into hardcoded loader list (issue #412)
    -set BloodRayne into the arstartdma hook list to fix its audio issues (issue #417)
```
