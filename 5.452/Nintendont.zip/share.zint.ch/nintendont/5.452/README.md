# Nintendont 5.452
Commit: 5a95477aac068a370ffabc0165f087c3d6f23667  
Time: Sat Sep 16 01:17:23 2017   

-----

```
commit 5a95477aac068a370ffabc0165f087c3d6f23667
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Sep 16 01:17:23 2017 +0200

    -reworked how nintendont gets booted, hopefully everything that worked still works
    This massive change allows bootup inside a WiiU Wii VC title, so the WiiU Gamepad can be used as an input for player 1, details on that will be on gbatemp, besides that it should still work exactly as it did in the past on Wii/vWii
```
