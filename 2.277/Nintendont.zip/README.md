# Nintendont 2.277
Commit: 96796bc43630e95dc056ebb76bf7b8b7f829eea5  
Time: Tue Jan 13 23:04:55 2015   

-----

```
commit 96796bc43630e95dc056ebb76bf7b8b7f829eea5
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Jan 13 23:04:55 2015 +0000

    -wrote up a small pal gc ipl patch to try prevent its startup crashing
    -make sure that the timer memory info is always set to the correct values
```
