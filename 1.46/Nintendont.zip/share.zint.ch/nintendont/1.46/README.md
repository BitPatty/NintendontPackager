# Nintendont 1.46
Commit: 142667e1a22d25d2c3ecf482c9e728d843b936fd  
Time: Wed May 14 19:58:02 2014   

-----

```
commit 142667e1a22d25d2c3ecf482c9e728d843b936fd
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed May 14 19:58:02 2014 +0000

    -some more work on the pad read code, now for example final fantasy crystal chronicles works again
    -changed up some timings again to help making for example melee more stable
```
