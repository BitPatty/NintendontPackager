# Nintendont 2.227
Commit: 1aafe301d53e3a823529badc6d761b32f70e30f0  
Time: Tue Nov 25 16:21:56 2014   

-----

```
commit 1aafe301d53e3a823529badc6d761b32f70e30f0
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Nov 25 16:21:56 2014 +0000

    Fix Entry load cache invalidation.
    This was causing PSO 1&2P/III EXIImm issue, so removed the patch for that.
    Commented out 31A0 patch until we know of a case where it's needed.
```
