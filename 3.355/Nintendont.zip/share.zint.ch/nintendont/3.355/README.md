# Nintendont 3.355
Commit: 2800a07fc8cd84b4be0c1dccdc8a35620ecf7c6a  
Time: Mon Jul 13 23:39:57 2015   

-----

```
commit 2800a07fc8cd84b4be0c1dccdc8a35620ecf7c6a
Author: FIX94 <fix94.1@gmail.com>
Date:   Mon Jul 13 23:39:57 2015 +0200

    -wasted 2 days of my life just to prove a point (added widescreen patch to sonic r)
```
