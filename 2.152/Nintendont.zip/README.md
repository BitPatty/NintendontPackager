# Nintendont 2.152
Commit: 2700a76be0c1dfdb345388eb9380adf7f23414e2  
Time: Tue Sep 2 14:05:26 2014   

-----

```
commit 2700a76be0c1dfdb345388eb9380adf7f23414e2
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Sep 2 14:05:26 2014 +0000

    -Fixed auto boot from some loaders when maxpads is set to 0
    -Fixed PS4 controller.ini digital triggers
    -Fixed JPN and non JPN saves trying to use the same multi save file. If you were saving JPN saves in a multi save file you need to rename ninmem.raw to ninmemj.raw when upgrading to this version.
```
