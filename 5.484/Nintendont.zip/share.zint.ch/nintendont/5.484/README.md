# Nintendont 5.484
Commit: b967aab87b35e391623642abeb0e999e2ad5c18c  
Time: Sun Aug 26 02:15:39 2018   

-----

```
commit b967aab87b35e391623642abeb0e999e2ad5c18c
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Aug 26 02:15:39 2018 +0200

    -updated and compiled with the latest devkitppc r32, libogc 1.8.20 and devkitarm r49-1
    -fixed potential issue in arstartdma (issue #595)
    -properly fixed mario party 4 crash (issue #437)
```
