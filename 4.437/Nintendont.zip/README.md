# Nintendont 4.437
Commit: 710ccef2218f6eddc8143b40c9c17d00b922add6  
Time: Mon Apr 17 18:28:30 2017   

-----

```
commit 710ccef2218f6eddc8143b40c9c17d00b922add6
Author: FIX94 <fix94.1@gmail.com>
Date:   Mon Apr 17 18:28:30 2017 +0200

    -added rel timer patches for barnyard, nicktoons unite and battle for volcano island (issue #390)
    -pushed the hobbit into rel timer patches instead of patching it the aggressive way
```
