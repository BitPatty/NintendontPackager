# Nintendont 1.67
Commit: 1d9cf5bb54ff5ceded36057d2713bcbdaf546cad  
Time: Wed May 28 14:02:44 2014   

-----

```
commit 1d9cf5bb54ff5ceded36057d2713bcbdaf546cad
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed May 28 14:02:44 2014 +0000

    -Added Generic USB Gamepad PID=0079 VID=0006 controller.ini This controller was sold under several brands and models.
    -Fixed "flickering" problem some users were having with Genreic_USB_Gamepad_PID=0079_VID=0006
```

```
commit de6d3e4aabd9b89a9391f4dfbd89edd959339d3c
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue May 27 18:36:39 2014 +0000

    -added alot of exceptions to fix Killer7, Cubivore, Frogger's Adventures, Two Towers, Chibi-Robo, Resident Evil 4, Hudson Selection Vol 2 and Kururin Squash
    -if you dont give a cache.txt, nintendont will automatically cache files, thats not as efficient but should help improve loading times if you get to some area a second time for example
```
