# Nintendont 5.458
Commit: afcfa4b6539ca4db50f38889eacd8924391d84f1  
Time: Wed Sep 20 06:14:16 2017   

-----

```
commit afcfa4b6539ca4db50f38889eacd8924391d84f1
Author: FIX94 <fix94.1@gmail.com>
Date:   Wed Sep 20 06:14:16 2017 +0200

    -added deadzones to wii vc gamepad reads and heavily changed memory to make space for that, hopefully it didnt break anything
    -completely restructured how internal wii vc titles get read in, again hopefully it didnt break anything
```
