# Nintendont 2.274
Commit: e3e431895e930f8e417f47b4360b776d0a534e9a  
Time: Fri Jan 9 15:39:35 2015   

-----

```
commit e3e431895e930f8e417f47b4360b776d0a534e9a
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Jan 9 15:39:35 2015 +0000

    -added a proper audio streaming resample check so games with too fast audio should now sound correct
    -moved the Street Racing Syndicate exception to hopefully fix the game
```
