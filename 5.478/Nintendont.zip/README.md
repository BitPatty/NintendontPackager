# Nintendont 5.478
Commit: 70fbd537126ad83c8bbac64478fcce6454b805c5  
Time: Mon Oct 30 20:55:31 2017   

-----

```
commit 70fbd537126ad83c8bbac64478fcce6454b805c5
Author: FIX94 <fix94.1@gmail.com>
Date:   Mon Oct 30 20:55:31 2017 +0100

    added street racing syndicate into instant exi irq exception list to allow it to save
```
