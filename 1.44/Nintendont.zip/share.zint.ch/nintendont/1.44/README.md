# Nintendont 1.44
Commit: 24b013c5b995c4ee8462bbbd3427e673986b364a  
Time: Sun May 11 21:25:48 2014   

-----

```
commit 24b013c5b995c4ee8462bbbd3427e673986b364a
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun May 11 21:25:48 2014 +0000

    -changed up some thread priorities
```
