# Nintendont 2.158
Commit: 813295cbda7f47e9253f8e7206a1bbe154c6909e  
Time: Sun Sep 14 00:04:32 2014   

-----

```
commit 813295cbda7f47e9253f8e7206a1bbe154c6909e
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Sep 14 00:04:32 2014 +0000

    -Added new controller.ini button LZ
     it adds the same functionality the bluetooth controllers have when DigitalLR=1 for half pressed AnalogR and AnalogR triggers when L or R are pressed at the same time as the LZ button.
    -Changed game selection menu Dpad Left and Right buttons to advance a screen at a time
    -Updated Logitech Thrustmaster Firestorm Dual Analog 2 controller.ini to support the LZ button
```
