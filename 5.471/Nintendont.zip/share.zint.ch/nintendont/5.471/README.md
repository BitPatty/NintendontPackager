# Nintendont 5.471
Commit: 450d082152911fe6ff4b5f94f8ab21e7f2f14748  
Time: Wed Oct 11 23:19:31 2017   

-----

```
commit 450d082152911fe6ff4b5f94f8ab21e7f2f14748
Author: FIX94 <fix94.1@gmail.com>
Date:   Wed Oct 11 23:19:31 2017 +0200

    give japanese version of mario kart arcade gp 2 its own save file
```
