# Nintendont 6.492
Commit: c0e97a5efba3c3d184d7c20d6036916b2877703b  
Time: Mon May 10 20:04:04 2021   

-----

```
commit c0e97a5efba3c3d184d7c20d6036916b2877703b
Merge: a3bc17c 85d54bd
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Mon May 10 20:04:04 2021 +0100

    Merge pull request #887 from sailormoon/master
    
    Support configuring Wii U Gamepad controller slot.
```

```
commit a3bc17c079078229790f6b159773f82a9d1a1b96
Merge: eae8129 172a07c
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Mon May 10 19:22:39 2021 +0100

    Merge pull request #893 from Aurelio92/master
    
    Fixed sticks under-/over-flow in PADReadGC
```

```
commit eae81294b4f701612f2f467676310c54c614e5c2
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Sun Feb 28 18:55:57 2021 +0000

    several  merges and more
    
    Added  need for speed carbon and most wanted to force connected expection so they wont randomly disconnect
    Did alot of merges  including
    Fix for smash ultimate gc controller Dr-Crow
    Remove iso cache and tweaked sonic ridders patch (SuperrSonic) helps fire emblem issues and games where music wnet silent after awhile.
    Lots of controller.inis
```
