# Nintendont 6.492
Commit: eae81294b4f701612f2f467676310c54c614e5c2  
Time: Sun Feb 28 18:55:57 2021   

-----

```
commit eae81294b4f701612f2f467676310c54c614e5c2
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Sun Feb 28 18:55:57 2021 +0000

    several  merges and more
    
    Added  need for speed carbon and most wanted to force connected expection so they wont randomly disconnect
    Did alot of merges  including
    Fix for smash ultimate gc controller Dr-Crow
    Remove iso cache and tweaked sonic ridders patch (SuperrSonic) helps fire emblem issues and games where music wnet silent after awhile.
    Lots of controller.inis
```
