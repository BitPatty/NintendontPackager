# Nintendont 2.266
Commit: 01395d74d33d19b3eb72c6907c1c32ac6e46a323  
Time: Thu Jan 1 00:46:47 2015   

-----

```
commit 01395d74d33d19b3eb72c6907c1c32ac6e46a323
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Thu Jan 1 00:46:47 2015 +0000

    -Added Trio Linker Plus II controller.ini (Thanks gillhaj02)
```

```
commit c369c4fd07fdff6156880e07d75683983f98c3c7
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Dec 31 20:59:24 2014 +0000

    -fixed up the triforce game virtua striker 4 so it should boot and also added basic controls code for it
    -small changes and bugfixes
```
