# Nintendont 3.344
Commit: 26169668a36202008ada00e951ac8a7be9d20041  
Time: Sat Jun 6 23:06:45 2015   

-----

```
commit 26169668a36202008ada00e951ac8a7be9d20041
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Jun 6 23:06:45 2015 +0200

    -added some code to allow real discs on wii to actually be taken out and placed back in, should allow for things like disc switching with actual discs
```
