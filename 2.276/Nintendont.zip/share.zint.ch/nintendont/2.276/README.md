# Nintendont 2.276
Commit: 92d33151a69abd9f7d23911c05bec0b1e46673b3  
Time: Mon Jan 12 16:23:42 2015   

-----

```
commit 92d33151a69abd9f7d23911c05bec0b1e46673b3
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Jan 12 16:23:42 2015 +0000

    -added gamecube bios support, please note that this is still very early in testing so it might not fully work, to let a game start using the original gamecube bios place iplusa.bin, ipljap.bin and/or iplpal.bin onto your device root, if nintendont finds the bios fitting to the game region it tries to start it, as of right now this feature has no use whatsoever and only exists for pure demonstration purposes
```
