# Nintendont 1.114
Commit: 877122ee6998b8f727be03ef84bda17fc94744a2  
Time: Wed Jul 2 15:29:35 2014   

-----

```
commit 877122ee6998b8f727be03ef84bda17fc94744a2
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Jul 2 15:29:35 2014 +0000

    -check for valid tgc header before copying in our own apploader (fixes sonic gems collection)
    -added animal crossing to the arstartdma exception list, lets animal crossing pal boot without any modifications for the first time via the new tgc apploader
```
