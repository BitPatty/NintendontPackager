# Nintendont 3.338
Commit: 1649ba1ea0a8be32a51258521c742e1e7348b0c4  
Time: Sat May 23 18:59:43 2015   

-----

```
commit 1649ba1ea0a8be32a51258521c742e1e7348b0c4
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat May 23 18:59:43 2015 +0200

    -added majoras mask alternative audio stream hook to fix missing ocarina confirmation sound and missing credits music
    -slightly changed patcher debug output
```
