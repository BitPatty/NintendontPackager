# Nintendont 5.482
Commit: 19bb71c1a3fcc6b36e3bea78ef6543a5cee8d793  
Time: Mon Mar 12 01:45:02 2018   

-----

```
commit 19bb71c1a3fcc6b36e3bea78ef6543a5cee8d793
Author: FIX94 <fix94.1@gmail.com>
Date:   Mon Mar 12 01:45:02 2018 +0100

    added force progressive fix for Capcom vs. SNK 2 EO NTSC-J
```
