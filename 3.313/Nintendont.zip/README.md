# Nintendont 3.313
Commit: 7051d1c1727c299c679876db0d2fcbfbe43782f8  
Time: Mon Mar 2 18:58:39 2015   

-----

```
commit 7051d1c1727c299c679876db0d2fcbfbe43782f8
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Mar 2 18:58:39 2015 +0000

    -limited the amount of fake interrupt checks to 120 times a second, this should still give a rather quick overall loading speed and should prevent certain games from creating a read overflow and freezing itself with that
```
