# Nintendont 5.464
Commit: 57228f82583ab141adecc17934c6556ef52c4f1e  
Time: Sun Sep 24 23:59:28 2017   

-----

```
commit 57228f82583ab141adecc17934c6556ef52c4f1e
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Sep 24 23:59:28 2017 +0200

    -added shutdown for vwii and wii vc
    -added shutdown button of gamepad to be read in on wii vc
```
