# Nintendont 1.24
Commit: 7a09c03ba868b377384c8be09d101f6731e3feac  
Time: Tue May 6 19:37:58 2014   

-----

```
commit 7a09c03ba868b377384c8be09d101f6731e3feac
Author: JoostinOnline@gmail.com <JoostinOnline@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue May 6 19:37:58 2014 +0000

    -Made some of the init code clearer
    -Fixed some typo's
    -Removed empty Debug folders.
```
