# Nintendont 2.187
Commit: bd05ac85facbb2a042be3e1ab6de6d2bf180b509  
Time: Tue Oct 21 14:42:39 2014   

-----

```
commit bd05ac85facbb2a042be3e1ab6de6d2bf180b509
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Oct 21 14:42:39 2014 +0000

    -only apply Patch31A0 if the entry point is below that, fixes 007 from russia with love
    -if PADInit cant be found use SIInit instead to start reading pad inputs, fixes alien hominid controls
```
