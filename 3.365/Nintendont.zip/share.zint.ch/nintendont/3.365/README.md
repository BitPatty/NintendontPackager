# Nintendont 3.365
Commit: b7203a9303b508baf38d8ca420978a4e640ef26c  
Time: Tue Aug 4 17:01:48 2015   

-----

```
commit b7203a9303b508baf38d8ca420978a4e640ef26c
Author: FIX94 <fix94.1@gmail.com>
Date:   Tue Aug 4 17:01:48 2015 +0200

    -creating triforce save file before boot if it doesnt exist, this should prevent crashes
    -actually made the panel du pon timer 1.5x, the game is in fact mistimed, tested on gc
```
