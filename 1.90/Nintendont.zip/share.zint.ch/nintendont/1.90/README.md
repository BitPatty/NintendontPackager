# Nintendont 1.90
Commit: 2a376b8f3ab3c3ffa85bfdc3ef25f4e144e38c62  
Time: Wed Jun 18 04:17:44 2014   

-----

```
commit 2a376b8f3ab3c3ffa85bfdc3ef25f4e144e38c62
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Jun 18 04:17:44 2014 +0000

    Add SIInit C patch for SSBM.
    Add new function patch.
    -Unsure of the name, but the function performs SIHandleRead for SSBM.
```
