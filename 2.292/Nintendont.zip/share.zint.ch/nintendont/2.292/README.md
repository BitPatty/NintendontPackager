# Nintendont 2.292
Commit: 2796afce3a63a4b815628f1eaccc4e54eadebdd5  
Time: Sun Feb 8 02:35:02 2015   

-----

```
commit 2796afce3a63a4b815628f1eaccc4e54eadebdd5
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Feb 8 02:35:02 2015 +0000

    -removed the timer patch for virtua striker 4 again cause it seems to produce crashes and instead set the menu timer to about 51 days which seems to work fine and should get rid of crashing
```
