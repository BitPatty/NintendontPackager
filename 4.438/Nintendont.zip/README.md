# Nintendont 4.438
Commit: b8d5aeabebcde81c86986a473ec5c571c01c5f29  
Time: Thu Apr 27 18:14:42 2017   

-----

```
commit b8d5aeabebcde81c86986a473ec5c571c01c5f29
Merge: fe0b79c 1a74d18
Author: FIX94 <fix94.1@gmail.com>
Date:   Thu Apr 27 18:14:42 2017 +0200

    Merge pull request #401 from cheatfreak47/master
    
    update gcn_md5.txt
```

```
commit fe0b79c9df487e29b38ff43b5a0929d4f88cbb89
Author: FIX94 <fix94.1@gmail.com>
Date:   Thu Apr 27 05:17:11 2017 +0200

    -fixed bmx xxx with 480p yet again (broken since commit e6e1c6a)
```
