# Nintendont 2.220
Commit: 975f5958f7244684b1bea2b92edc9e069394ce0b  
Time: Mon Nov 17 20:34:11 2014   

-----

```
commit 975f5958f7244684b1bea2b92edc9e069394ce0b
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Nov 17 20:34:11 2014 +0000

    -did some more work on the game specific widescreen hacks, making at least 7 different games (mkdd, super mario sunshine, crash bandicoot, nfs hp2, wind waker, twilight princess, paper mario) in all their regions get widescreen patched properly
```
