# Nintendont 1.92
Commit: 3ce89c08a2bed8b8dccbe11912aa1ede92afaac9  
Time: Wed Jun 18 18:18:08 2014   

-----

```
commit 3ce89c08a2bed8b8dccbe11912aa1ede92afaac9
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Jun 18 18:18:08 2014 +0000

    -some minor changes, logs now get closed and devices get properly unmounted
```
