# Nintendont 2.264
Commit: 5b8c85f7c203109254f99a768fdfc60c62effb78  
Time: Wed Dec 24 12:21:27 2014   

-----

```
commit 5b8c85f7c203109254f99a768fdfc60c62effb78
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Dec 24 12:21:27 2014 +0000

    -if nintendont gets loaded with the wrong IOS it will try to load IOS58 by itself
    -added code which makes sure we have permission to use the disc drive
    -added a missing redraw when you change settings
```
