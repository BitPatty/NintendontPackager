# Nintendont 2.224
Commit: 066408c9570ec0b8ad42803535f23eff3e46d8d4  
Time: Sun Nov 23 14:42:22 2014   

-----

```
commit 066408c9570ec0b8ad42803535f23eff3e46d8d4
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Nov 23 14:42:22 2014 +0000

    -made nintendont compilable with the latest devkitARM r43
```
