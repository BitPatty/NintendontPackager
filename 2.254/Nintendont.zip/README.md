# Nintendont 2.254
Commit: 096a4f89040deeda76a1df9a73968bba35cebb93  
Time: Sun Dec 14 01:51:11 2014   

-----

```
commit 096a4f89040deeda76a1df9a73968bba35cebb93
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Dec 14 01:51:11 2014 +0000

    -missed .h file
```

```
commit 9aafca570aac1a65eb3e2cd61960d72cee462015
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Dec 14 01:46:37 2014 +0000

    -added some code which will create pre-formatted memory cards for the memcard emu on file creation, that means you dont need to format it manually ingame anymore
```
