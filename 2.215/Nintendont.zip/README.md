# Nintendont 2.215
Commit: a694d895dfc878cf8238710b4586ac9e85fac395  
Time: Tue Nov 11 19:37:34 2014   

-----

```
commit a694d895dfc878cf8238710b4586ac9e85fac395
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Nov 11 19:37:34 2014 +0000

    -cut memcard emu access time in half since after testing it doesnt seem to cause any problems
    -when playing from usb, let the drive read a random sector every 10 seconds to stay alive
```
