# Nintendont 3.385
Commit: 779ea8bb8be0fb21a67d76fb131d9def1e5e58b3  
Time: Fri Feb 5 15:53:08 2016   

-----

```
commit 779ea8bb8be0fb21a67d76fb131d9def1e5e58b3
Merge: 3228848 ae7fc2d
Author: FIX94 <fix94.1@gmail.com>
Date:   Fri Feb 5 15:53:08 2016 +0100

    Merge pull request #192 from GerbilSoft/gpt-support
    
    [RFC] Basic GPT support
```

```
commit 3228848a8e4f14cc50d0742508670f5d7eb84dfb
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Jan 23 20:49:58 2016 +0100

    -applying the same colosseum memory card patch to the bonus disc in hopes to fix its memcard emu
```
