# Nintendont 5.468
Commit: b49f684a9b744dc5b318fe1693506fe3356fec2d  
Time: Wed Oct 4 03:13:23 2017   

-----

```
commit b49f684a9b744dc5b318fe1693506fe3356fec2d
Author: FIX94 <fix94.1@gmail.com>
Date:   Wed Oct 4 03:13:23 2017 +0200

    added patch to f-zero ax to allow it being forced to pal60
```
