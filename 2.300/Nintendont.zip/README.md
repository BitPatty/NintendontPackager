# Nintendont 2.300
Commit: 1690ebc0c79760ef481e852d617b3e48e4f45550  
Time: Wed Feb 18 21:32:35 2015   

-----

```
commit 1690ebc0c79760ef481e852d617b3e48e4f45550
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Feb 18 21:32:35 2015 +0000

    -heavy cleanup in the usb code, its now really small compared to before but should still do the same
```
