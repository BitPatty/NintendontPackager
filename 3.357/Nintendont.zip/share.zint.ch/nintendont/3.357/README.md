# Nintendont 3.357
Commit: 1b4978566eafc32732ed3ae83d7d8b03557ceb9c  
Time: Fri Jul 17 20:26:05 2015   

-----

```
commit 1b4978566eafc32732ed3ae83d7d8b03557ceb9c
Author: FIX94 <fix94.1@gmail.com>
Date:   Fri Jul 17 20:26:05 2015 +0200

    -added a patch to fix melees weird video mode breaking when using a different video scale option than 640
```
