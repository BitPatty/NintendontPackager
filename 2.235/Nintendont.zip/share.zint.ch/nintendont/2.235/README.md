# Nintendont 2.235
Commit: 04df5bb5ddfad208eb9af0df63c180a4b2e427ef  
Time: Tue Dec 2 21:36:41 2014   

-----

```
commit 04df5bb5ddfad208eb9af0df63c180a4b2e427ef
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Dec 2 21:36:41 2014 +0000

    -Fixed lack of responsiveness on HID controllers. This fixes the problem several of you were having trying to dash dance with the gamecube adapter for wii u
```
