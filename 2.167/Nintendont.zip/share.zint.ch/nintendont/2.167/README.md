# Nintendont 2.167
Commit: efbc87d2b1e8205fc463bc6c83389ddf73f67d9b  
Time: Fri Oct 3 15:44:51 2014   

-----

```
commit efbc87d2b1e8205fc463bc6c83389ddf73f67d9b
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Oct 3 15:44:51 2014 +0000

    -added new PI_FIFO_WP patch pattern for pokemon xd and changed up ARStartDMA reading, this makes xd fully work for the first time
    -moved atv quad power racing 2 and pn03 into the paper mario ARStartDMA exception list to get them stable
```
