# Nintendont 1.22
Commit: d77829a7dbf217b7bf518a8b26f41fa74425c63d  
Time: Sun May 4 14:35:47 2014   

-----

```
commit d77829a7dbf217b7bf518a8b26f41fa74425c63d
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun May 4 14:35:47 2014 +0000

    Fix UStealth. - Thanks airline38
```
