# Nintendont 2.196
Commit: cff00c73f12d6011e6b15147bf4192ba9de9b294  
Time: Mon Oct 27 16:25:36 2014   

-----

```
commit cff00c73f12d6011e6b15147bf4192ba9de9b294
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Oct 27 16:25:36 2014 +0000

    Add hack for PacMan World 2 to force the SiInit true.
```
