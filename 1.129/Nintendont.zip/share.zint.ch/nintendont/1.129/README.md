# Nintendont 1.129
Commit: 7267041b79e1ce58e3da4268c40c4f46cae42f28  
Time: Wed Jul 23 16:48:47 2014   

-----

```
commit 7267041b79e1ce58e3da4268c40c4f46cae42f28
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Jul 23 16:48:47 2014 +0000

    -made the ARStartDMA crash solution more complex for need for speed hot pursuit 2 to hopefully get it more stable
    -fixed a bug in ARStartDMA which used the wrong memory address base, that should fix some games like tony hawk pro skater
    -increased HID controller reading, it now reads about 60 times a second
    -added chronicles of narnia to the ARQPostRequest exception list
```
