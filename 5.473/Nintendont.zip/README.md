# Nintendont 5.473
Commit: 8a7d3f266087b61cbfc58260a1c418176ea8cc4d  
Time: Sat Oct 21 20:07:41 2017   

-----

```
commit 8a7d3f266087b61cbfc58260a1c418176ea8cc4d
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Oct 21 20:07:41 2017 +0200

    properly handle the vwii case of having no bootable game on selected device
```
