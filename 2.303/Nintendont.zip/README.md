# Nintendont 2.303
Commit: 7fdd22da06559946ce9b7f36d3c7ab8a7e304c16  
Time: Sun Feb 22 01:02:03 2015   

-----

```
commit 7fdd22da06559946ce9b7f36d3c7ab8a7e304c16
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Feb 22 01:02:03 2015 +0000

    -updated the nintendont kernel to support all the characters in the filenames that the loader supports, this way you cant get sudden error messages about nonexistant files anymore
```
