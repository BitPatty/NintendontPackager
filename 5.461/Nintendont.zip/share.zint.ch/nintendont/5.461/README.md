# Nintendont 5.461
Commit: 07d55554df4b83be17aea38924a5f64b350a152e  
Time: Fri Sep 22 09:45:50 2017   

-----

```
commit 07d55554df4b83be17aea38924a5f64b350a152e
Author: FIX94 <fix94.1@gmail.com>
Date:   Fri Sep 22 09:45:50 2017 +0200

    moved exit code up a little to hopefully fix it sometimes not being recognized
```
