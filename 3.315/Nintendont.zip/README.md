# Nintendont 3.315
Commit: ab8a951524385869b1ed570ed5300641c24d4f84  
Time: Thu Mar 5 01:09:42 2015   

-----

```
commit ab8a951524385869b1ed570ed5300641c24d4f84
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Thu Mar 5 01:09:42 2015 +0000

    -added a patch for GXLoadTlut, fixes "rainbow sky" in burnout and possibly more
```
