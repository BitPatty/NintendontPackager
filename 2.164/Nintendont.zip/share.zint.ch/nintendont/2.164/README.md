# Nintendont 2.164
Commit: ccc8952e218b1c41b3109b973375fc02a06d2b5c  
Time: Sun Sep 28 13:23:43 2014   

-----

```
commit ccc8952e218b1c41b3109b973375fc02a06d2b5c
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Sep 28 13:23:43 2014 +0000

    -moved most audio streaming and interrupt relevant info into unused hardware registers
    -skipping SIGetType patch for sonic adventure dx to fix its double presses
    -started adding more patterns and patches for games using the debug sdk, none of them work yet though, alot needs to be done still
```
