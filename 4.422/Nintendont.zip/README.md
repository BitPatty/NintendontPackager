# Nintendont 4.422
Commit: 1ac0fdf55fae3f21cc7c49c5b9fb42fb55235958  
Time: Fri Aug 5 20:21:54 2016   

-----

```
commit 1ac0fdf55fae3f21cc7c49c5b9fb42fb55235958
Author: FIX94 <fix94.1@gmail.com>
Date:   Fri Aug 5 20:21:54 2016 +0200

    -allow pal60 flag again, but only when actually forcing a video mode other than pal50
```
