# Nintendont 1.49
Commit: 249f515e5c14d96b43206475d5fbac0f0ddd0036  
Time: Sat May 17 15:56:04 2014   

-----

```
commit 249f515e5c14d96b43206475d5fbac0f0ddd0036
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat May 17 15:56:04 2014 +0000

    -Fixed reading controller.ini when lines are separated by only a <line feed>
    =Added Logitech Cordless Rumblepad 2 controller.ini (Thanks BravaCentauri)
    =Added PDP Afterglow AP.1 Controller for PS3 controller.ini (Thanks BravaCentauri)
    =Added Gioteck SC-1 controller.ini (Thanks Rockohoward)
```
