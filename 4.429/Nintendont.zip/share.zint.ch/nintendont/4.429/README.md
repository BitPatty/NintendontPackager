# Nintendont 4.429
Commit: adf3de525cfb8d1fb0538b23121fff0c462604f0  
Time: Sat Dec 3 02:51:27 2016   

-----

```
commit adf3de525cfb8d1fb0538b23121fff0c462604f0
Merge: d8039dd 97985ba
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Dec 3 02:51:27 2016 +0100

    Merge pull request #337 from GerbilSoft/bugfix/disc2.md5.r428
    
    Fix disc swapping if disc 2 is selected; MD5 database fixes
```
