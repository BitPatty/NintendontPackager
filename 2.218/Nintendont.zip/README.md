# Nintendont 2.218
Commit: e81a67b1ac8c7365468e057ba1d047cfea510a5b  
Time: Sun Nov 16 21:18:39 2014   

-----

```
commit e81a67b1ac8c7365468e057ba1d047cfea510a5b
Author: JoostinOnline@gmail.com <JoostinOnline@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Nov 16 21:18:39 2014 +0000

    -Fixed update menu and "Return to Loader" not always showing.
```
