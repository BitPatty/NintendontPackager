# Nintendont 4.446
Commit: 5cc89418f0e3a8229d6403c533618459b972a0b0  
Time: Wed Jun 28 03:25:32 2017   

-----

```
commit 5cc89418f0e3a8229d6403c533618459b972a0b0
Author: FIX94 <fix94.1@gmail.com>
Date:   Wed Jun 28 03:25:32 2017 +0200

    -added patches to allow the japanese versions of pso 1&2 (retail and demo), pso 1&2 plus and pso 3 to boot up, note that the demo of pso 1&2 wont actually be playable since it actually requires a currently not emulated internet connection
```
