# Nintendont 1.40
Commit: 3eaaa2eeaa20b67e5cbcb8ebd3f8d7cf3ee0aeab  
Time: Fri May 9 23:33:37 2014   

-----

```
commit 3eaaa2eeaa20b67e5cbcb8ebd3f8d7cf3ee0aeab
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri May 9 23:33:37 2014 +0000

    -read in fonts before staring the game (fixes a few games)
    -do not check for new disc read inputs if we are still reading a file (fixes a few games)
```
