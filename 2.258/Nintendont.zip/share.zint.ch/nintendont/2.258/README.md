# Nintendont 2.258
Commit: 7542ec42d196ba3755fd308cbf1486d0f4f97431  
Time: Thu Dec 18 18:43:42 2014   

-----

```
commit 7542ec42d196ba3755fd308cbf1486d0f4f97431
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Thu Dec 18 18:43:42 2014 +0000

    -added option for wiiu widescreen, if its off your wiiu will resize the picture to be 4:3 and if its on it'll stretch the picture to fullscreen
```
