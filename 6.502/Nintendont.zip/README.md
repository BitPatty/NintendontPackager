# Nintendont 6.502
[Direct Download](./Nintendont.zip)

Commit: a9167924e2994802d6e202ac41beb8ca8ca8d1d3  
Time: Sat Apr 19 23:09:51 2025   

-----

```
commit a9167924e2994802d6e202ac41beb8ca8ca8d1d3
Merge: a69f2f1 8054f91
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Sat Apr 19 23:09:51 2025 +0100

    Merge pull request #1273 from jmlee337/sync2
    
    Add missing `sync_after_write` after writing to `0x319C` in `Patch31A0`
```

```
commit a69f2f134daf0f06a1b01da4b5337a984ac6dcf1
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Sun Jul 28 14:20:21 2024 +0100

    Dualshock 4 rumble added to hardcoded inis
    
    Forgot to add rumble to the in memory values, even without the ini files you can get rumble on ds4 controllers now.
```
