# Nintendont 6.502
[Direct Download](./Nintendont.zip)

Commit: a69f2f134daf0f06a1b01da4b5337a984ac6dcf1  
Time: Sun Jul 28 14:20:21 2024   

-----

```
commit a69f2f134daf0f06a1b01da4b5337a984ac6dcf1
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Sun Jul 28 14:20:21 2024 +0100

    Dualshock 4 rumble added to hardcoded inis
    
    Forgot to add rumble to the in memory values, even without the ini files you can get rumble on ds4 controllers now.
```
