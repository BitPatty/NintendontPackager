# Nintendont 5.460
Commit: fa65bb6c883cfc38b8cef75561a6b4a52ce0635e  
Time: Thu Sep 21 03:32:40 2017   

-----

```
commit fa65bb6c883cfc38b8cef75561a6b4a52ce0635e
Merge: cef0ee0 91731c8
Author: FIX94 <fix94.1@gmail.com>
Date:   Thu Sep 21 03:32:40 2017 +0200

    Merge pull request #468 from GerbilSoft/feature/fix-wiiu-multi-drive.r459
    
    Fix Wii U multi-drive support.
```
