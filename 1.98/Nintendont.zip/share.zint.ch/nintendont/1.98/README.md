# Nintendont 1.98
Commit: ddd6fdc8c6c62ad672545fdaca93bb5bf97876a4  
Time: Tue Jun 24 21:28:59 2014   

-----

```
commit ddd6fdc8c6c62ad672545fdaca93bb5bf97876a4
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Jun 24 21:28:59 2014 +0000

    -sorry, the previous revision will always clear the config because I messed up a simple value, fixed
```

```
commit 6f63b30d91d51a14b06d6b044f652124b7248a6f
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Jun 24 13:33:59 2014 +0000

    -nintendont now accepts args to autoboot games, other usb loader devs can look at wiiflow on howto implement it
    -added ios 58.25.32 onto the supported wii ios list as suggested by the gbatemp member realromhunter
```
