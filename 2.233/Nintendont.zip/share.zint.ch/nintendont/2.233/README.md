# Nintendont 2.233
Commit: cd74ce2fe1e359b2e2841a1543a5dc82c8f18ddb  
Time: Sun Nov 30 00:25:36 2014   

-----

```
commit cd74ce2fe1e359b2e2841a1543a5dc82c8f18ddb
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Nov 30 00:25:36 2014 +0000

    -merged SD and USB kernel into a single one
    -fixed a very small bug in both DI and SD code, probably a very few people will have a benefit from that
    -removed loader.elf and boot.dol since everything only takes the loader.dol anyways, lets not waste any space
    -general code cleanup
```
