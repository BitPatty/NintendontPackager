# Nintendont 2.209
Commit: 49e7ed62787aa78ba1fab6de0f79be2e2d876283  
Time: Sat Nov 8 16:50:34 2014   

-----

```
commit 49e7ed62787aa78ba1fab6de0f79be2e2d876283
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Nov 8 16:50:34 2014 +0000

    (binary please)
```

```
commit 0ab070e1f9666f1e0fe49c6001439f22415ed886
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Nov 8 16:50:12 2014 +0000

    -added __CARDUnlock patch to fix original nintendo memory card support, thanks tueidj for pointing at it
    -only set a progressive video mode on game boot if force progressive is enabled, should fix some PAL games to start normally on wiiu
    -removed old include which doesnt exist anymore to fix compiling errors
```
