# Nintendont 2.200
Commit: 5ad2cbf759ac62c27a54ea1efca5eba8fd2a075c  
Time: Fri Oct 31 20:22:06 2014   

-----

```
commit 5ad2cbf759ac62c27a54ea1efca5eba8fd2a075c
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Oct 31 20:22:06 2014 +0000

    -added an option to enable/disable video deflicker when using force video mode, basically disabling deflickering will make a sharper image but might not work properly on your tv and enabling deflickering will be a bit more blurry but should be smooth on all tvs
```
