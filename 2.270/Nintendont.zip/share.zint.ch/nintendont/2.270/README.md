# Nintendont 2.270
Commit: f0d2e84c0c52762698d5a1a05b9f5191a7dadd90  
Time: Sat Jan 3 19:41:30 2015   

-----

```
commit f0d2e84c0c52762698d5a1a05b9f5191a7dadd90
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Jan 3 19:41:30 2015 +0000

    -added proper memory flush security as well as proper ARStartDMA data copying if the data to be copied is not properly aligned already, fixes various games such as happy feet, legends of wrestling and gun
```
