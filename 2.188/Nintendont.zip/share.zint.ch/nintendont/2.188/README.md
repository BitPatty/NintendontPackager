# Nintendont 2.188
Commit: 7abc350cbbde3955e8fcded18e167f6f90903494  
Time: Wed Oct 22 12:32:14 2014   

-----

```
commit 7abc350cbbde3955e8fcded18e167f6f90903494
Author: JoostinOnline@gmail.com <JoostinOnline@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Oct 22 12:32:14 2014 +0000

    -Added support for special (Triforce) games in database, which were previously identified incorrectly
    -Removed some duplicates from titles.txt (you don't need to update your local copy)
    -Updated the meta.xml file just so the online version has correct credits
    
    Note: Thanks to Xenith and sonictopfan for testing
```
