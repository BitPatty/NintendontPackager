# Nintendont 2.153
Commit: a5b93cba446ffc80c43ed9452bd5dcd171b74074  
Time: Sat Sep 6 02:02:26 2014   

-----

```
commit a5b93cba446ffc80c43ed9452bd5dcd171b74074
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Sep 6 02:02:26 2014 +0000

    -added bluetooth support, so far you can use the wiiu pro controller, classic controller and classic controller pro, the controllers need to be synced with the system menu to work just like it is with other homebrew applications, credits to the original author of lwBT, the people behind the libogc port, the creators of the wiimote wiki entry on wiibrew.org and to TeHaxor69 for the wiiu pro controller documentation
    -added raw rumble data support to controller.ini files, so far controller_ps2.ini and controller_Genreic_USB_Gamepad_PID=0079_VID=0006.ini have rumble support
    IMPORTANT: The bluetooth code is very long so it is highly possible that they are new bugs coming with this version, dont be surprised when you encounter new problems
```
