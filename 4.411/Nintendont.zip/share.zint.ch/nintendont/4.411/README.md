# Nintendont 4.411
Commit: 90368c8769eda1cc9e9f6ecfc9019e3720f37509  
Time: Sat Jun 25 20:37:29 2016   

-----

```
commit 90368c8769eda1cc9e9f6ecfc9019e3720f37509
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Jun 25 20:37:29 2016 +0200

    -added rumble support to both mario kart arcade gp and gp 2
```
