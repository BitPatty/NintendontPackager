# Nintendont 1.109
Commit: 089505e72232a8c72ba6cc4704511a9286037dc4  
Time: Tue Jul 1 06:07:27 2014   

-----

```
commit 089505e72232a8c72ba6cc4704511a9286037dc4
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Jul 1 06:07:27 2014 +0000

    More code cleanup.
    -Menu code
    -FuncPattern Groups
    Added another PI_FIFO_WP function.
    Added log to the config settings.
```
