# Nintendont 1.26
Commit: b6a8be0cae064377eda8364e85e3acbae4183cb9  
Time: Tue May 6 23:52:01 2014   

-----

```
commit b6a8be0cae064377eda8364e85e3acbae4183cb9
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue May 6 23:52:01 2014 +0000

    Try to use font_ansi.bin if no ipl.bin file is found.
```
