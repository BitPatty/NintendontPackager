# Nintendont 2.248
Commit: 61cde294a023ae4b81c5676469a11211808022fc  
Time: Mon Dec 8 18:23:25 2014   

-----

```
commit 61cde294a023ae4b81c5676469a11211808022fc
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Dec 8 18:23:25 2014 +0000

    -further refined DVD function check in order to properly patch games, should fix things like disc switching again
```
