# Nintendont 1.70
Commit: 11caf4ab4c87dfb1cd3fdd97c74d037b65065ef2  
Time: Fri May 30 19:18:56 2014   

-----

```
commit 11caf4ab4c87dfb1cd3fdd97c74d037b65065ef2
Author: crediar@rypp.net <crediar@rypp.net@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri May 30 19:18:56 2014 +0000

    *Updated code to allow larger section sizes
```

```
commit 9883c372bc25f177a7ad93c3abaa91b0ab5cfe63
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri May 30 16:03:22 2014 +0000

    -worked some more on the auto-cache, also fixed a little bug in it again
```
