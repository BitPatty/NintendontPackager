# Nintendont 3.401
Commit: 8c1ee19c540578014039d4db3deb9e2959e33567  
Time: Sat Jun 4 14:51:32 2016   

-----

```
commit 8c1ee19c540578014039d4db3deb9e2959e33567
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Jun 4 14:51:32 2016 +0200

    -added 2 more demos into special patch lists and added a text file listing all the currently special patched demos
    -added proper app switcher patch trigger to handle them more safely
    -made quite a few patch copies dynamic to save some low mem1 memory
    -added a second security check in the n64 emulator detection so it wont apply to a wrong file anymore
    -removed 2 more old and unused .S files to save some space
```
