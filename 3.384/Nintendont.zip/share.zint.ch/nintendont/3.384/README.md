# Nintendont 3.384
Commit: 1c865922539780f026248d89b083e01d4bd9a80b  
Time: Sat Jan 23 16:22:13 2016   

-----

```
commit 1c865922539780f026248d89b083e01d4bd9a80b
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Jan 23 16:22:13 2016 +0100

    -fixed the japanese colosseum bonus disc by including it in the xd and colosseum patches since it uses the same engine
```
