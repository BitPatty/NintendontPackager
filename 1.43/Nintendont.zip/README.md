# Nintendont 1.43
Commit: ae89cbe4a5e47b4c390765351e1ce12c9072d7f2  
Time: Sat May 10 02:50:22 2014   

-----

```
commit ae89cbe4a5e47b4c390765351e1ce12c9072d7f2
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat May 10 02:50:22 2014 +0000

    -Fixed GC analog triggers on controllers 2, 3 and 4 controlling player 1
```
