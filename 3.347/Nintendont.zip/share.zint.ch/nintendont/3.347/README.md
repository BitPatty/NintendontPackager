# Nintendont 3.347
Commit: 268791a1de4a6dd4064569eda3b001a851830e85  
Time: Tue Jun 23 21:41:07 2015   

-----

```
commit 268791a1de4a6dd4064569eda3b001a851830e85
Author: FIX94 <fix94.1@gmail.com>
Date:   Tue Jun 23 21:41:07 2015 +0200

    -added a fix for 007 from russia with love not booting
```
