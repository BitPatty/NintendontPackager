# Nintendont 5.456
Commit: 02446e53b9e0dde5468f64a3005c7a695eaee0e3  
Time: Mon Sep 18 21:37:11 2017   

-----

```
commit 02446e53b9e0dde5468f64a3005c7a695eaee0e3
Author: FIX94 <fix94.1@gmail.com>
Date:   Mon Sep 18 21:37:11 2017 +0200

    -hopefully fixed nintendont startup problems now
    -fixed HID controllers being broken in the last few versions
    -make wii vc version boot quicker and actually show its wii vc
    -started implementing wii vc internal game.iso launch, code is not finished yet and will give you a launch error but its a start
```
