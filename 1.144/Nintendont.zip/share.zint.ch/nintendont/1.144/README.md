# Nintendont 1.144
Commit: 97c7be5349b99b340205a40e7917b2cdebf1e833  
Time: Sun Aug 17 19:30:00 2014   

-----

```
commit 97c7be5349b99b340205a40e7917b2cdebf1e833
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Aug 17 19:30:00 2014 +0000

    -Fixed when reading a version 2 nincfg.bin the version number is updated as well otherwise any changes to the config result in an unusable file on subsequent boots
```
