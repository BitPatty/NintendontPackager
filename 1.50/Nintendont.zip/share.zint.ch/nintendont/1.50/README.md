# Nintendont 1.50
Commit: b9dd146e9b4f54f8ee68ad6e2edbc302a81652cf  
Time: Sat May 17 21:45:29 2014   

-----

```
commit b9dd146e9b4f54f8ee68ad6e2edbc302a81652cf
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat May 17 21:45:29 2014 +0000

    -changed up some things to hopefully help save crashes
```
