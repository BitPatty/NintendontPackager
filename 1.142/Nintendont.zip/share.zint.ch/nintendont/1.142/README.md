# Nintendont 1.142
Commit: 8becec74de3ebbfbbd19381e6a525fa45bac8d61  
Time: Mon Aug 11 14:23:35 2014   

-----

```
commit 8becec74de3ebbfbbd19381e6a525fa45bac8d61
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Aug 11 14:23:35 2014 +0000

    -added new patches to emulate the wii reset button by pressing the buttons R+Z+Start on your controller
```
