# Nintendont 4.420
Commit: 5a068b248b3e3f65e3205c4eae8f2266631f158d  
Time: Thu Jul 21 20:06:08 2016   

-----

```
commit 5a068b248b3e3f65e3205c4eae8f2266631f158d
Author: FIX94 <fix94.1@gmail.com>
Date:   Thu Jul 21 20:06:08 2016 +0200

    -added a little extra code for fake wiiu pro controllers so they have a higher chance of actually connecting properly
```
