# Nintendont 2.273
Commit: c9d34a2d56f1bd60ca575aa67dd6990da9be670c  
Time: Fri Jan 9 05:31:56 2015   

-----

```
commit c9d34a2d56f1bd60ca575aa67dd6990da9be670c
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Jan 9 05:31:56 2015 +0000

    -Added new boot status message "Cheat path is empty" when cheats are  on and cheat path is on and the cheat path isn't set
    -Changed boot status messages "Initing devices..." to "Initing storage devices..."
    -improved gamecube adapter for wii u bongo support
```
