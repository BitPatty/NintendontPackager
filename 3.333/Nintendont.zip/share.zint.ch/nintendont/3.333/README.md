# Nintendont 3.333
Commit: e30b4b829ef2b9859cfb19f5dbbc12ab7c5c126a  
Time: Tue May 5 16:07:20 2015   

-----

```
commit e30b4b829ef2b9859cfb19f5dbbc12ab7c5c126a
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue May 5 16:07:20 2015 +0000

    -slightly decreased the wiiu pro controller stick sensitivity to more accurately represent the original gc controller
    -added /codes/gameid.gct as possible cheatpath as requested
```
