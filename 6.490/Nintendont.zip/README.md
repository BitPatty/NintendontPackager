# Nintendont 6.490
Commit: d1b29b0d08899ca8e2cd4cd7899d9dd2fda281df  
Time: Sat Nov 14 16:17:22 2020   

-----

```
commit d1b29b0d08899ca8e2cd4cd7899d9dd2fda281df
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Sat Nov 14 16:17:22 2020 +0000

    Fix for wiivc crash with hid
    
    Since fix94 never replyed and has been a year this is a solution to fixing wiivc with hid controllers, basicaly added afew changes from GaryOderNichts, if Fix94 ever returns he can change to what he sees best.
```
