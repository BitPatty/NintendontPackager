# Nintendont 1.60
Commit: e600a5b53fdaea1829e08938cb337f6d243ba35a  
Time: Sun May 25 01:00:06 2014   

-----

```
commit e600a5b53fdaea1829e08938cb337f6d243ba35a
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun May 25 01:00:06 2014 +0000

    Fix Harvest Moon Magical Melody.
```
