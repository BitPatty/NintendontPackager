# Nintendont 3.308
Commit: ef048e606ecc68cc1db23b31e35fd08b2d9a9117  
Time: Sat Feb 28 17:28:20 2015   

-----

```
commit ef048e606ecc68cc1db23b31e35fd08b2d9a9117
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Feb 28 17:28:20 2015 +0000

    -added a small disc read delay which should make sure that the read speed is somewhat equal to the original disc drive, this should fix some weird game issues such as suddenly stopping music in kururin squash
    -added the japanese wind waker demo to the __gxsetvat list
    -added sonic mega collection and moved sonic gems collection arstartdma exception
```
