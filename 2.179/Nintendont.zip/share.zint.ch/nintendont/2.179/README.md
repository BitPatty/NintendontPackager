# Nintendont 2.179
Commit: 308555667ab6c6f0950da29df9f38e5d01aa0dd8  
Time: Sat Oct 18 15:29:05 2014   

-----

```
commit 308555667ab6c6f0950da29df9f38e5d01aa0dd8
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Oct 18 15:29:05 2014 +0000

    -added safety check for GCAMIdentify patch, fixes mario kart gp1
    -other tiny optimizations
```
