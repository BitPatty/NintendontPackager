# Nintendont 3.366
Commit: cbdf9382ffbdcb8ba00318f5379712d282094f79  
Time: Wed Aug 5 16:14:55 2015   

-----

```
commit cbdf9382ffbdcb8ba00318f5379712d282094f79
Author: FIX94 <fix94.1@gmail.com>
Date:   Wed Aug 5 16:14:55 2015 +0200

    -added code to remove the vs4 menu timer updater
```
