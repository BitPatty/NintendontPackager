# Nintendont 1.34
Commit: b51abec406412840d2ce7dd9f028c69b5561a171  
Time: Fri May 9 02:47:25 2014   

-----

```
commit b51abec406412840d2ce7dd9f028c69b5561a171
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri May 9 02:47:25 2014 +0000

    Only cache fonts section of ipl.bin. (Save 1.5MB)
```
