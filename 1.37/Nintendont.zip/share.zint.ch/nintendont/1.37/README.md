# Nintendont 1.37
Commit: 70cb354b7db4c1cb30b056367b2539ca1cd063e8  
Time: Fri May 9 15:33:54 2014   

-----

```
commit 70cb354b7db4c1cb30b056367b2539ca1cd063e8
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri May 9 15:33:54 2014 +0000

    Added configuration file for Thrustmaster T-Wireless(Thanks ALSINJAN)
    Fixed compile error on systems where caps make a difference
```

```
commit 8786dda82dd8118b915773e5ebc081714bcbbaf6
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri May 9 14:11:38 2014 +0000

    -slightly increased wait delay again to help stabilize games like melee
```

```
commit e692b05e2c8e2d5985b4c4773a6192cd694b0906
Author: JoostinOnline@gmail.com <JoostinOnline@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri May 9 13:58:43 2014 +0000

    -Optimized for space so DEBUG can stay enabled with USB kernel
    -Nintendont version is now shown in log
    -Added a few missing carriage returns
```
