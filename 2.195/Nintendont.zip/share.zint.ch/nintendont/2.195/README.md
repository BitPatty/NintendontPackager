# Nintendont 2.195
Commit: 6a7af1f24cdd2bfebaa91c16333350d681239d8a  
Time: Mon Oct 27 02:59:41 2014   

-----

```
commit 6a7af1f24cdd2bfebaa91c16333350d681239d8a
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Oct 27 02:59:41 2014 +0000

    Made PSO hacks more generic (work for PSO III).
    Added new PatchBuffer code for PSO III.
```
