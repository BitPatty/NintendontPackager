# Nintendont 2.296
Commit: 68d2399fb36f60bacbc8ed752fe0abd831bd5935  
Time: Mon Feb 16 15:40:07 2015   

-----

```
commit 68d2399fb36f60bacbc8ed752fe0abd831bd5935
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Feb 16 15:40:07 2015 +0000

    -completely rewrote the way nintendont starts, now the kernel is directly loaded on startup meaning there is no more usb reloading, this should increase the usb compatibility by quite a bit
    -set the usb refresh rate to 2 minutes and 30 seconds
    -added a patch to mario kart gp2 to disable the red item button so if you go into 1st person it doesnt shoot the item away anymore
    -added sources for the custom libfat version
```
