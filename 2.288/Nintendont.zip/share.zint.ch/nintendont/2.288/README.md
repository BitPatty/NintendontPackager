# Nintendont 2.288
Commit: fcde434311d589be6331325f86f1fe903c1723e2  
Time: Wed Feb 4 23:59:33 2015   

-----

```
commit fcde434311d589be6331325f86f1fe903c1723e2
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Feb 4 23:59:33 2015 +0000

    -added widescreen patches to 1080, pikmin and pikmin 2
    -patched a few more menu timers in gp2 and also made a few invisible
```
