# Nintendont 5.480
Commit: 04bb84a51c4c9054853749a96f16447c6c6af65d  
Time: Tue Jan 23 07:08:07 2018   

-----

```
commit 04bb84a51c4c9054853749a96f16447c6c6af65d
Merge: 7bdfaca 7c3af34
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Tue Jan 23 07:08:07 2018 +0000

    Merge pull request #542 from cheatfreak47/master
    
    fix Disney Magical Mirror Starring Mickey Mouse
```

```
commit 7bdfaca4836549c6c2ca1204926c5ac6353e0a31
Author: FIX94 <fix94.1@gmail.com>
Date:   Mon Nov 27 10:01:38 2017 +0100

    recompiled dol
```

```
commit ce39fa9eec8b515719f1d27817b558a24d197113
Merge: d6bf7e5 8f1ff3f
Author: FIX94 <fix94.1@gmail.com>
Date:   Mon Nov 27 05:53:33 2017 +0100

    Merge pull request #523 from SuperrSonic/master
    
    Fire Emblem and Smash Bros. Melee
```
