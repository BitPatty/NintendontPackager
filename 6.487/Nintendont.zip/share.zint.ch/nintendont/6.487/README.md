# Nintendont 6.487
Commit: 00747afc88370d1fff9e3105f871e8ec3f1af47a  
Time: Sun Oct 6 08:06:44 2019   

-----

```
commit 00747afc88370d1fff9e3105f871e8ec3f1af47a
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Oct 6 08:06:44 2019 +0200

    how did it not commit this file???
```

```
commit 8ec02d29f5ff20b60e1018ace0cfb68576a33138
Merge: a6b2205 035423f
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Oct 6 07:48:38 2019 +0200

    Merge branch 'master' of https://github.com/FIX94/Nintendont
```

```
commit a6b2205a457194191923a596f8750fa6fdc52e9b
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Oct 6 07:48:11 2019 +0200

    attempt of fixing issue #705 by making new makefiles closer to loader
```

```
commit 069200e0cd4b228e09961f02e48006bab6444279
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Oct 6 05:47:12 2019 +0200

    Update README.md
```

```
commit 96f6af37ee4ecbd4e60cd2cb1383025c3bb89b80
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Oct 6 05:41:30 2019 +0200

    Create BBA_Readme.md
```

```
commit 3ee42a9e35f0dcb21da84bbd99116048ea6d7ada
Merge: 7be1b6d 1481e3c
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Oct 6 05:00:52 2019 +0200

    Merge pull request #700 from FIX94/bbatest_cur
    
    Implementing BBA Emulation, closes issue #144
```
