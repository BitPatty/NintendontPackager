# Nintendont 1.33
Commit: a7d8041bb8fb16546ecebc21efb3ef02b342fbe7  
Time: Fri May 9 00:25:40 2014   

-----

```
commit a7d8041bb8fb16546ecebc21efb3ef02b342fbe7
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri May 9 00:25:40 2014 +0000

    -further improved the disc read thread introduced with r31
    -improved usability of the return to feature, it should be more reliable now
    -caching the font file by default now
```
