# Nintendont 1.64
Commit: 4e1f2b729cdc1de720434c3293f0001b86bfc835  
Time: Mon May 26 22:21:52 2014   

-----

```
commit 4e1f2b729cdc1de720434c3293f0001b86bfc835
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon May 26 22:21:52 2014 +0000

    Dsp version does not control if ARQPostRequest is needed.  Revert to lists.
```
