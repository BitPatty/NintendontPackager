# Nintendont 1.120
Commit: 4ba2a8725e094534609d9afae97699ff2f41e283  
Time: Sat Jul 5 09:12:07 2014   

-----

```
commit 4ba2a8725e094534609d9afae97699ff2f41e283
Author: crediar@rypp.net <crediar@rypp.net@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Jul 5 09:12:07 2014 +0000

    *Fixed a bug that non Triforce games were reading from Triforce hardware areas (Thanks to sabykos for finding the bug).
    This should fix any game broken by r72 (i.e. Mario Party 7 EUR, Mario Power Tennis EUR, Harry Potter POA EUR, ... )
```

```
commit 1c7ebdf45076f8386538fac23d2456738f29e939
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Jul 4 22:13:47 2014 +0000

    -loader game list is now sorted alphabetically
    -you can control the loader now by holding down the dpad/stick, you dont need to constantly press, if you press left/right you move even faster
    -the classic controller analog stick now works in the loader
    -the current position in the game list wont get reset anymore after entering the options
```
