# Nintendont 2.194
Commit: 76ccaea3b8296191d58411ce84002235e5751c4f  
Time: Sun Oct 26 18:49:21 2014   

-----

```
commit 76ccaea3b8296191d58411ce84002235e5751c4f
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Oct 26 18:49:21 2014 +0000

    Fixes for PSO 1&2 Plus
    -Move access from 0x80001800 to 0x931C0000
    -Apply dol entry mod after switch.prs extraction to dol
    -Don't mod psov3.dol entry point.  Used after DVD load.  Patch entry hack.
```
