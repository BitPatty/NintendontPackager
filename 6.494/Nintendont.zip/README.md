# Nintendont 6.494
Commit: 812354d75300686d7a3ae8e3fb31daacbb443769  
Time: Sat May 22 00:16:41 2021   

-----

```
commit 812354d75300686d7a3ae8e3fb31daacbb443769
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Sat May 22 00:16:41 2021 +0100

    Fix The Fairly OddParents: Shadow Showdown "no String"
    
    Made sure no matter your console language or forced language in nintendont settings the game The Fairly OddParents: Shadow Showdown runs with english language so it doesnt crash at the no string issue due to dummy language files.
```
