# Nintendont 3.348
Commit: e3885c6447d4673481f84d03c440080040957d25  
Time: Wed Jun 24 23:19:19 2015   

-----

```
commit e3885c6447d4673481f84d03c440080040957d25
Author: FIX94 <fix94.1@gmail.com>
Date:   Wed Jun 24 23:19:19 2015 +0200

    -corrected a small mistake on the disc read speed emulation code, it was too fast because of a missing number, this might help out certain game desync issues
    -added slow read speed settings for king kong to improve its chances of all triggers working, please note that it still has a possibility of not triggering events at times
    -made it possible to start triforce games from disc/WODE
    -added code to clear out the emulated audio ram for general safety
```
