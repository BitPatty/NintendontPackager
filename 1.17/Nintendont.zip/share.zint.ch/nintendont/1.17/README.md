# Nintendont 1.17
Commit: a278ce8039d3bb0ba69d86a748cb7c29aa70f060  
Time: Tue Apr 29 07:06:30 2014   

-----

```
commit a278ce8039d3bb0ba69d86a748cb7c29aa70f060
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Apr 29 07:06:30 2014 +0000

    Fixed meta.xml not updating to the correct version
```
