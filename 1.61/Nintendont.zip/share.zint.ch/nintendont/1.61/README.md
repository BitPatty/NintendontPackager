# Nintendont 1.61
Commit: 1a6278fd6c5d1755bf3650822132fa9f3b017750  
Time: Sun May 25 14:34:04 2014   

-----

```
commit 1a6278fd6c5d1755bf3650822132fa9f3b017750
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun May 25 14:34:04 2014 +0000

    sorry for the wiiu crash in r61, recompiled...
```

```
commit 23aa8cebc8bd2f74408143fc5a6bee3a2f96638d
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun May 25 13:03:23 2014 +0000

    -leave in the ARQPostRequest patch, only skip it for games which really get problems otherwise
    -made a few loader changes to try to fix some crashes on game startup
```
