# Nintendont 5.477
Commit: f5a27ba76b5eaa0d22c27bbe76c900728ab1168d  
Time: Mon Oct 30 03:46:09 2017   

-----

```
commit f5a27ba76b5eaa0d22c27bbe76c900728ab1168d
Author: FIX94 <fix94.1@gmail.com>
Date:   Mon Oct 30 03:46:09 2017 +0100

    -added Big Mutha Truckers to arstartdma exception list
    -added 60hz patches to pal versions of mario party 4,5,6 and 7
    -improved logic for arstartdma out-of-bounds requests (fixes Pool Edge)
```
