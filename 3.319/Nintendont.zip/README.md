# Nintendont 3.319
Commit: 88716fd03edafd53b47dd5ed029e7e6003ead1d1  
Time: Sat Mar 7 20:54:10 2015   

-----

```
commit 88716fd03edafd53b47dd5ed029e7e6003ead1d1
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Mar 7 20:54:10 2015 +0000

    -removed f-zero ax initial overscan so the menus dont look weird when pressing start before title screen
    -better anti-crash hack for f-zero ax which doesnt require constant value overwriting
```
