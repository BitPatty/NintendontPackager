# Nintendont 2.252
Commit: f3eb76581a4367721c854e5c43c7eb202fe062b4  
Time: Sat Dec 13 16:09:20 2014   

-----

```
commit f3eb76581a4367721c854e5c43c7eb202fe062b4
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Dec 13 16:09:20 2014 +0000

    -added a patch for f-zero ax which replaces the motor init screen directly with the controller setup in order to greatly reduce the initial loading time
    -made triforce game patching a bit more dynamic
    -removed unused triforce code
```
