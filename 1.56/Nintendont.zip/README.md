# Nintendont 1.56
Commit: e74691bae6505b781faa99065b122e3ce02b0de3  
Time: Sat May 24 05:51:54 2014   

-----

```
commit e74691bae6505b781faa99065b122e3ce02b0de3
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat May 24 05:51:54 2014 +0000

    -Fixed reading <DeadZone> and<Radius> default values when their were "," in subsiquent commands in the controller.ini
    The only controller in the svn this would affect controller_ps4.ini
```
