# Nintendont 2.260
Commit: 22587757b5c4a2c196e82682094a95420688b110  
Time: Sat Dec 20 17:06:31 2014   

-----

```
commit 22587757b5c4a2c196e82682094a95420688b110
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Dec 20 17:06:31 2014 +0000

    -cleaned up disc support for original wiis, for developers: to tell nintendont to load a  disc just set the game path to "di"
    -fixed a small mistake in PatchFuncInterface, that will fix various bugs such as games not booting or enemies are not killable in prince of persia warrior within
```
