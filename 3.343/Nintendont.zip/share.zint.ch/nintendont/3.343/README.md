# Nintendont 3.343
Commit: eaeddc6a05e4a63b38ac78e23e4acf74fcb580b1  
Time: Wed Jun 3 13:32:53 2015   

-----

```
commit eaeddc6a05e4a63b38ac78e23e4acf74fcb580b1
Author: FIX94 <fix94.1@gmail.com>
Date:   Wed Jun 3 13:32:53 2015 +0200

    -slightly adjusted the gt cube timer to work a bit more accurate
    -added patches for nintendo puzzle collection and panel de pon in order to fix its weird timer issues
```
