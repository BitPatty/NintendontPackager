# Nintendont 3.364
Commit: e7883ec6b17e3ed40538884404e439853fb2764c  
Time: Sun Aug 2 16:29:20 2015   

-----

```
commit e7883ec6b17e3ed40538884404e439853fb2764c
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Aug 2 16:29:20 2015 +0200

    -limiting GXLoadTlut patch to Burnout 1 to prevent other games from having problems with it
```
