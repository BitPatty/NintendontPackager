# Nintendont 2.146
Commit: 8e8d5bd006454beaa14cd108c1625f867507b701  
Time: Mon Aug 18 17:07:41 2014   

-----

```
commit 8e8d5bd006454beaa14cd108c1625f867507b701
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Aug 18 17:07:41 2014 +0000

    -slightly optimized the asm behind audio streaming, also added updater for the current offset, games like crazy taxi will always play the same song otherwise
    -added audio streaming support for FST games
    -crash bandicoot timer fix
```
