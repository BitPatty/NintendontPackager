# Nintendont 4.449
Commit: a216954b555b4846d24e31b3d36270b621d262ee  
Time: Thu Aug 31 04:50:39 2017   

-----

```
commit a216954b555b4846d24e31b3d36270b621d262ee
Author: FIX94 <fix94.1@gmail.com>
Date:   Thu Aug 31 04:50:39 2017 +0200

    fixed a bug that crashed nintendont when booting certain games
```
