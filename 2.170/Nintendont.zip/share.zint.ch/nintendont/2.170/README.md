# Nintendont 2.170
Commit: 6b7a45e60707cb98c348dee7c35e6060caa74481  
Time: Sat Oct 11 18:36:44 2014   

-----

```
commit 6b7a45e60707cb98c348dee7c35e6060caa74481
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Oct 11 18:36:44 2014 +0000

    -added a security check for the EXIDMA callback value, this fixes billy hatcher memcard emulation waiting forever because of a wrong value
    -did some small memcard emu patch cleanup
    -added memcard patch for the japanese version of pokemon colosseum
```
