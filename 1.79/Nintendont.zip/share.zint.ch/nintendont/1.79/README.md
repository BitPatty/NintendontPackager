# Nintendont 1.79
Commit: 6f90f625b9a5ea34827e26cbb003301f91d8de04  
Time: Wed Jun 4 14:43:05 2014   

-----

```
commit 6f90f625b9a5ea34827e26cbb003301f91d8de04
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Jun 4 14:43:05 2014 +0000

    -corrected cache for triforce games, now gp1 should run crashless
```
