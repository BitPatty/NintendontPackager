# Nintendont 2.145
Commit: 82bc996b87c4b8501310c5cdefe514605b147e63  
Time: Sun Aug 17 21:21:21 2014   

-----

```
commit 82bc996b87c4b8501310c5cdefe514605b147e63
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Aug 17 21:21:21 2014 +0000

    -added audio streaming, works well in most games, updated nintendonts major version to v2
    -fixed xg3 running too fast
    -general patcher optimizations
```
