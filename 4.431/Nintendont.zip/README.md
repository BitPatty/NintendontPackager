# Nintendont 4.431
Commit: c5e2da33505e2196fe81122a87340c8d17fff2d3  
Time: Sun Dec 18 02:12:43 2016   

-----

```
commit c5e2da33505e2196fe81122a87340c8d17fff2d3
Merge: 9584209 191ad0d
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Dec 18 02:12:43 2016 +0100

    Merge pull request #233 from capnfunky77/master
    
    Logitech F310 USB Controller Support
```

```
commit 9584209d95eb1432561bf5336c861767c90b1529
Merge: c6e89d4 92a9306
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Dec 18 02:12:28 2016 +0100

    Merge pull request #322 from darkalemanbr/master
    
    Add mapping for Logitech F310
```

```
commit c6e89d44df954f9fa1012b5f6f5da96afac3ec26
Merge: eab1271 6ac7cd9
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Dec 18 02:11:59 2016 +0100

    Merge pull request #350 from nastys/master
    
    Wiimote rumble with Classic Controller, option to enable/disable IPL, fixed TRI Arcade mode
```

```
commit eab127167c637ce1f380e79a027a4923a1574878
Merge: 6c78e6f 322ffbd
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Dec 18 02:09:44 2016 +0100

    Merge pull request #349 from GerbilSoft/feature/game-info.r430
    
    New "Game Info" screen, plus some bugfixes.
```
