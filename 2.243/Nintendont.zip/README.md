# Nintendont 2.243
Commit: a90fd188650736221b06f884be418687d71dbd21  
Time: Sun Dec 7 23:21:25 2014   

-----

```
commit a90fd188650736221b06f884be418687d71dbd21
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Dec 7 23:21:25 2014 +0000

    -added security checks for DVD patches and added DVDLowSeek patch instead of using DVDSeekAbsAsyncPrio patch
```
