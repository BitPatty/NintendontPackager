# Nintendont 3.383
Commit: 46f390d83d6550305997c54bfa38ee0faa012c8e  
Time: Wed Jan 20 19:56:34 2016   

-----

```
commit 46f390d83d6550305997c54bfa38ee0faa012c8e
Author: FIX94 <fix94.1@gmail.com>
Date:   Wed Jan 20 19:56:34 2016 +0100

    -added a special game id check for Knights Of The Temple to not be detected as a Triforce game
```
