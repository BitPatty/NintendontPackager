# Nintendont 1.23
Commit: 605f66b41382239e747ad0a8c3a7e904db6bbdc5  
Time: Sun May 4 14:46:15 2014   

-----

```
commit 605f66b41382239e747ad0a8c3a7e904db6bbdc5
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun May 4 14:46:15 2014 +0000

    Actually implement the change meant for r22 (Fix UStealth).
```
