# Nintendont 2.291
Commit: c10d0d5e566fe72cd748320bcd413a359994bba1  
Time: Sun Feb 8 01:30:05 2015   

-----

```
commit c10d0d5e566fe72cd748320bcd413a359994bba1
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Feb 8 01:30:05 2015 +0000

    -removed some menu timers in virtua striker 4
    -added a proper widescreen patch to virtua striker 4
    -reworked the controls code for the 4 triforce games, now the controls are going properly through the devices they should go through which should overall run really well now
    -slightly modified the anti-crash code for gp1 and gp2, now its possible to enter the test menu of them, please note they both have the same problem as vs4 and ax which makes it impossible to exit the test menu for unknown reasons
```
