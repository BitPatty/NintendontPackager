# Nintendont 3.312
Commit: 6701c572891737b2ac44538b0fcd6b1d1411c0f7  
Time: Mon Mar 2 17:24:27 2015   

-----

```
commit 6701c572891737b2ac44538b0fcd6b1d1411c0f7
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Mar 2 17:24:27 2015 +0000

    -relocated interrupt and audio streaming registers into mem2 to avoid problems with real memory cards in certain games
```
