# Nintendont 4.435
Commit: e446824094d9b356f9fea0a6fce6a43c40effad7  
Time: Sun Feb 5 17:41:51 2017   

-----

```
commit e446824094d9b356f9fea0a6fce6a43c40effad7
Merge: 275c849 4034c93
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Feb 5 17:41:51 2017 +0100

    Merge pull request #359 from Chickoodel/master
    
    8bitdo NES30 Pro USB support
```

```
commit 275c849f56935621ac73f7eb0a592ebf1b8b9f45
Merge: 9507600 a3ce9e5
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Feb 5 17:40:37 2017 +0100

    Merge pull request #365 from angelXwind/master
    
    DualShock 3/DualShock 4 improvements, added support for 2nd HW revision of the DualShock 4
```

```
commit 95076002570290c84fde739da47ef368d2dadead
Merge: e9d1261 bffb48e
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Jan 21 22:10:21 2017 +0100

    Merge pull request #363 from GerbilSoft/bugfix/IPL-enable-by-default
    
    Change "Load IPL" to "Skip IPL".
```
