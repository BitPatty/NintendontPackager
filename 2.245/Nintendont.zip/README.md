# Nintendont 2.245
Commit: 1dc82e406eced57b6c63c78afb5453067f6ed144  
Time: Mon Dec 8 00:12:38 2014   

-----

```
commit 1dc82e406eced57b6c63c78afb5453067f6ed144
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Dec 8 00:12:38 2014 +0000

    -added security check to PatchFunc, should fix frogger ancient shadow
```
