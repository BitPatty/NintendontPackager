# Nintendont 3.328
Commit: 7ff362f59688e39781951a76341e997dff0670d8  
Time: Fri Apr 17 11:19:07 2015   

-----

```
commit 7ff362f59688e39781951a76341e997dff0670d8
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Apr 17 11:19:07 2015 +0000

    -restricted the aggressive timer patching to the hobbit, fixes various side problems such as pikmin 2 crashing and the gc bios slowing down
    -changed the exi interrupt times a bit to further prevent lagging in the gc bios and in triforce games
```
