# Nintendont 2.198
Commit: e8bec1363262f28ada2c49465ceb11e03ed98c3e  
Time: Thu Oct 30 04:51:47 2014   

-----

```
commit e8bec1363262f28ada2c49465ceb11e03ed98c3e
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Thu Oct 30 04:51:47 2014 +0000

    -Added CronusMax Xbox360 Adapter controller.ini (Thanks Khar00f)
    -Added Microsoft Sidewinder Precision 2 Joystick controller.ini
```

```
commit ba8dd287a7ac02954348d6aac421bc85efb4a332
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Oct 29 19:11:45 2014 +0000

    -added a different approach to fix ARStartDMA issues for certain games, check the Patch.c diff to see which games are affected
```
