# Nintendont 3.377
Commit: 2954785058dd23e72f473ca9c426acd336aae0dd  
Time: Mon Nov 23 20:31:17 2015   

-----

```
commit 2954785058dd23e72f473ca9c426acd336aae0dd
Author: FIX94 <fix94.1@gmail.com>
Date:   Mon Nov 23 20:31:17 2015 +0100

    -make sure to only apply the virtua striker 4 widescreen patch to the 2006 export version so all other versions stop crashing when force widescreen is enabled
```
