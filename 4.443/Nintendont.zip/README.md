# Nintendont 4.443
Commit: 9bc610abbca17619e11838aceb6beafd1ce67bb3  
Time: Fri May 19 22:50:30 2017   

-----

```
commit 9bc610abbca17619e11838aceb6beafd1ce67bb3
Author: FIX94 <fix94.1@gmail.com>
Date:   Fri May 19 22:50:30 2017 +0200

    -dont set progressive flag when starting ntsc prince of persia warrior within and a language setting of spanish to avoid the game crashing (issue #416)
```
