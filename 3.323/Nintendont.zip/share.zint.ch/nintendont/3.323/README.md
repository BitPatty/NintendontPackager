# Nintendont 3.323
Commit: 1cd82728922db7f86c96500a174d82d4f62529cd  
Time: Thu Mar 12 20:54:15 2015   

-----

```
commit 1cd82728922db7f86c96500a174d82d4f62529cd
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Thu Mar 12 20:54:15 2015 +0000

    -cleaned up cheats code and made them work when booting games via bios
```
