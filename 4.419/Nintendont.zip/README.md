# Nintendont 4.419
Commit: ea4b9fb5aef131cf42ab7ca86992bbc246ffb92d  
Time: Sat Jul 16 00:33:03 2016   

-----

```
commit ea4b9fb5aef131cf42ab7ca86992bbc246ffb92d
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Jul 16 00:33:03 2016 +0200

    -got rid of the codehandler right before game boot again introduced in the last build, while it might have been useful for some cheats it seems to reduce game compatibility
    -zipping the kernel right before building the loader to get the dol size down a little more
```
