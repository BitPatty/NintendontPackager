# Nintendont 3.400
Commit: 5b2affe7302f46fe6e78f99e24b930a486fce841  
Time: Wed May 25 13:22:56 2016   

-----

```
commit 5b2affe7302f46fe6e78f99e24b930a486fce841
Merge: f5d0c79 bd4b50d
Author: FIX94 <fix94.1@gmail.com>
Date:   Wed May 25 13:22:56 2016 +0200

    Merge pull request #249 from GerbilSoft/menuhax-v2
    
    menuhax-v2 branch: Menu memory and usability improvements.
```
