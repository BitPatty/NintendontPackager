# Nintendont 3.342
Commit: 9cf8f5e10c828b622aa1ff6ef8054241bde940cb  
Time: Tue Jun 2 16:48:42 2015   

-----

```
commit 9cf8f5e10c828b622aa1ff6ef8054241bde940cb
Author: FIX94 <fix94.1@gmail.com>
Date:   Tue Jun 2 16:48:42 2015 +0200

    -created a timer patch for gt cube which fixes all the random speedups the game still had, this should be the last game with speed problems
```
