# Nintendont 1.66
Commit: e430b3e29562c493bdfbdee75b76194898d10fb3  
Time: Tue May 27 00:45:46 2014   

-----

```
commit e430b3e29562c493bdfbdee75b76194898d10fb3
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue May 27 00:45:46 2014 +0000

    Only use non-zero DMA interrupt size for Megaman X Command Mission.
```
