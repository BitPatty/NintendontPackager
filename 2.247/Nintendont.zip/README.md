# Nintendont 2.247
Commit: 1c331d8ff23195f5d46c919ff0d232f971c7d507  
Time: Mon Dec 8 04:18:08 2014   

-----

```
commit 1c331d8ff23195f5d46c919ff0d232f971c7d507
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Dec 8 04:18:08 2014 +0000

    -Added Donkey Kong Bongo support to the gamecube adapter for wii u
```
