# Nintendont 3.360
Commit: 07152170d1e7ac2bac78bc27815b3a5d74c085b6  
Time: Sat Jul 25 04:12:46 2015   

-----

```
commit 07152170d1e7ac2bac78bc27815b3a5d74c085b6
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Jul 25 04:12:46 2015 +0200

    nobody will notice my mistake if I just commit it quick
```

```
commit 4a6ab0265a3a51a471becd3ab4ae6b794d1f6043
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Jul 25 04:06:21 2015 +0200

    -added proper majoras mask audio patch so now the ocarina confirm and the credits work properly
    -cleaned up patch.c and removed the the read limiter for the n64 by default to improve its overall performance
    -added a n64 emu check which should work no matter which game id you use
```
