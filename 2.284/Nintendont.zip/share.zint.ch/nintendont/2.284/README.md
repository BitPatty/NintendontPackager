# Nintendont 2.284
Commit: 2368cf6838f29a00136b814758d9bda9de374564  
Time: Mon Jan 26 18:44:40 2015   

-----

```
commit 2368cf6838f29a00136b814758d9bda9de374564
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Jan 26 18:44:40 2015 +0000

    -added basic support for the triforce bios obtainable from virtua striker 4 (segaboot.img1), simply place it into your device root and rename it to segaboot.bin, triforce games now should start using it, if you want to enter its test menu press start while the media board init message is on screen
```
