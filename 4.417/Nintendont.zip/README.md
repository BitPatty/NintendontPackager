# Nintendont 4.417
Commit: c8df2607d27cc798534f35b98d17528ff6d67762  
Time: Sun Jul 10 23:43:57 2016   

-----

```
commit c8df2607d27cc798534f35b98d17528ff6d67762
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Jul 10 23:43:57 2016 +0200

    -no need for PADInit patch if native controls are active, disabled it in that case
    -updated meta.xml to now also include no_ios_reload, needed for older homebrew channel versions
```
