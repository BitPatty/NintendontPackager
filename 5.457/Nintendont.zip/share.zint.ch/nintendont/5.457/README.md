# Nintendont 5.457
Commit: 6e464cd703d0a21d6c4737783dde3c1a7344b486  
Time: Mon Sep 18 23:41:30 2017   

-----

```
commit 6e464cd703d0a21d6c4737783dde3c1a7344b486
Author: FIX94 <fix94.1@gmail.com>
Date:   Mon Sep 18 23:41:30 2017 +0200

    -now wii vc internal game.iso files should actually boot up
    -when starting wii vc with the gamepad off, it should allow player 1 to be taken by other controllers again instead of being taken by the disabled gamepad
```
