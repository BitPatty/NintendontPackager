# Nintendont 3.341
Commit: bf57d5cbad1f7ecb47b48d070dbb79e7ef6fc7a9  
Time: Sun May 31 14:34:55 2015   

-----

```
commit bf57d5cbad1f7ecb47b48d070dbb79e7ef6fc7a9
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun May 31 14:34:55 2015 +0200

    -updated the meta.xml to point to the new github location
```

```
commit 0f4982169103dd086984047fc5ae009b9a64ba1a
Author: FIX94 <fix94.1@gmail.com>
Date:   Tue May 26 17:37:40 2015 +0200

    -added widscreen patches for all ocarina of time and majoras mask versions from both the oot bonus disc and collectors edition
```
