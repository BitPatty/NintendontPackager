# Nintendont 5.476
Commit: 89b64cb7f3a9d774d23826afdf90a4e623102cbd  
Time: Wed Oct 25 00:50:47 2017   

-----

```
commit 89b64cb7f3a9d774d23826afdf90a4e623102cbd
Author: FIX94 <fix94.1@gmail.com>
Date:   Wed Oct 25 00:50:47 2017 +0200

    -added patches to make gamecube service disc v1.0 bootable
```
