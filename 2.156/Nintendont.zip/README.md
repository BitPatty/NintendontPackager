# Nintendont 2.156
Commit: 50a48b1720559a21adc3eda71d244aaa87f69f74  
Time: Wed Sep 10 00:43:35 2014   

-----

```
commit 50a48b1720559a21adc3eda71d244aaa87f69f74
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Sep 10 00:43:35 2014 +0000

    -Enhanced Internal game menu to default to the most recently selected game
    -Increased internal game menus ability to handle up to 500 games
    -Added new boot status messages for what controllers are enabled
    -Enhanced to allow gamecube and hid controllers to be turned off at the same time
    -Fixed Multiplayer using MultiIn=2 again. (bluetooth changes keep breaking it)
```
