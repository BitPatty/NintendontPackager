# Nintendont 3.310
Commit: 66043c7efe3ae765a5d0f55e521ce8b12e2b921c  
Time: Sun Mar 1 17:40:24 2015   

-----

```
commit 66043c7efe3ae765a5d0f55e521ce8b12e2b921c
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Mar 1 17:40:24 2015 +0000

    -added wait patch for sonic riders so on loading screens the game doesnt try to copy non-loaded files, should fix the game crashing at random file loads
```
