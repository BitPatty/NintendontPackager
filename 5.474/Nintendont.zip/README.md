# Nintendont 5.474
Commit: 155a77d0399a6abdcf16c7ea19d646d1d57090f2  
Time: Tue Oct 24 07:49:37 2017   

-----

```
commit 155a77d0399a6abdcf16c7ea19d646d1d57090f2
Merge: f3299f4 2bf95d0
Author: FIX94 <fix94.1@gmail.com>
Date:   Tue Oct 24 07:49:37 2017 +0200

    Merge pull request #475 from ShadowOne333/patch-1
    
    Adding RE Remake, Zero, 2 & 3 to Widescreen exceptions
```

```
commit f3299f449859d0306925a0f684098ba222897464
Author: FIX94 <fix94.1@gmail.com>
Date:   Tue Oct 24 07:13:11 2017 +0200

    -proper widescreen patch for doshin the giant
    -when forcing to progressive or any other 60hz mode, added proper 60hz patch to the pal versions of doshin the giant and luigis mansion
```
