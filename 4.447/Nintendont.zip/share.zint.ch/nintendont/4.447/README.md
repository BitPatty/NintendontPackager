# Nintendont 4.447
Commit: e16fbf3a566a21e2677fe6e8a53ef80977b95a54  
Time: Thu Aug 10 22:10:04 2017   

-----

```
commit e16fbf3a566a21e2677fe6e8a53ef80977b95a54
Author: FIX94 <fix94.1@gmail.com>
Date:   Thu Aug 10 22:10:04 2017 +0200

    added support for the JP version of mario kart arcade gp 2 (check out triforce-nand-iso-extract)
```
