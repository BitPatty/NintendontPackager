# Nintendont 1.123
Commit: 3cf645f3dbeb68227930bd386381cd68b22f2898  
Time: Sat Jul 5 22:07:25 2014   

-----

```
commit 3cf645f3dbeb68227930bd386381cd68b22f2898
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Jul 5 22:07:25 2014 +0000

    -corrected a mistake in the dsp patch, thanks sabykos for pointing it out
    -ignore the title case when sorting alphabetically to get correct results
    -display ID6 to the right of the title, that makes it easier to identify games
```
