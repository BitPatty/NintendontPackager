# Nintendont 1.0
Commit: 2d643621b2f212ed88f93970f91e776f465d5ce8  
Time: Sun Apr 27 16:06:56 2014   

-----

```
commit 2d643621b2f212ed88f93970f91e776f465d5ce8
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Apr 27 16:06:56 2014 +0000

    -calculating trigger deadzones a bit better now
    -displaying the version info properly now
```

```
commit bcda999e9de5d991ab37f8942907bac8316b8cbe
Author: crediar@rypp.net <crediar@rypp.net@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Apr 27 13:44:42 2014 +0000
```

```
commit 7318c8c33f3766893231bd7506f53947e7b93ca6
Author: crediar@rypp.net <crediar@rypp.net@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Apr 27 13:19:31 2014 +0000

    *Added apps folder files
```

```
commit 3d2c74276fd3b880e64e38d4742d882674e685a3
Author: crediar@rypp.net <crediar@rypp.net@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Apr 27 13:16:02 2014 +0000

    #Added loader.dol
```

```
commit 9a86d28ba7a8e76559cb441a9b75c37ab5129336
Author: crediar@rypp.net <crediar@rypp.net@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Apr 27 13:07:28 2014 +0000

    To prevent endless revision/version confusion nintendont will no longer use revisions but versions starting at 1.0
    
    1.0:
    
    release = r89
    date = 2014-4-27
    -If your loader provides a return stub, the reset combination will now use it, if no loader was used, you will return to the system menu
    
    release = r88
    date = 2014-4-26
    -Added Mayflash 3 in 1 Magic Joy Box support (Thanks Adeka & Fludit)
    -Added Thrustmaster Firestorm Dual Analog 2 support
    -Cleared message to plug in HID controller once it is plugged in
    -Added error message for "PS3 controller init error"
    -Added display of error codes for unknown HID init errors
    -Added updates.txt
    
    release = r87
    date = 2014-4-26
    -Removed the DSP patches
    
    
    release = r86
    date = 2014-4-26
    -Added a dead zone to L and R triggers for both GameCube and USB controllers, should stop triggers from staying at one place
    
    release = r85
    date = 2014-4-25
    -Moved r85 to new SVN
```
