# Nintendont 2.244
Commit: 9db72ab5d25f5499ecf0ff72e575c642fb88b06c  
Time: Mon Dec 8 00:03:20 2014   

-----

```
commit 9db72ab5d25f5499ecf0ff72e575c642fb88b06c
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Dec 8 00:03:20 2014 +0000

    -Skip Datel patches for non-Datel games.
```
