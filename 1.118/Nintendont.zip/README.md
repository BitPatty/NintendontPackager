# Nintendont 1.118
Commit: c5fbd7f41809884a44101f14b54f587cc4127a3b  
Time: Fri Jul 4 16:14:47 2014   

-----

```
commit c5fbd7f41809884a44101f14b54f587cc4127a3b
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Jul 4 16:14:47 2014 +0000

    -the power button should now shutdown on wii and reset to menu on wiiu at all times instantly
```
