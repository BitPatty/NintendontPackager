# Nintendont 1.48
Commit: 594fabdb89789cdc9a22d6b02302d7d68c2113b7  
Time: Fri May 16 20:46:04 2014   

-----

```
commit 594fabdb89789cdc9a22d6b02302d7d68c2113b7
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri May 16 20:46:04 2014 +0000

    -more memory card emu tweaks, now nintendont will wait at least 3 seconds before it actually saves a file to your drive, that way it should not freeze because of too early storing, also optimized the save timing a bit to improve stability
```
