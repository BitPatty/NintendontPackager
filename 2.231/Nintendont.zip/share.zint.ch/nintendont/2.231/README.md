# Nintendont 2.231
Commit: 50c8b83a9b13424bb6fd7ffd662092e1770b76b6  
Time: Sat Nov 29 14:48:27 2014   

-----

```
commit 50c8b83a9b13424bb6fd7ffd662092e1770b76b6
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Nov 29 14:48:27 2014 +0000

    -added timeouts to both USB and HID detection, this way init errors should be greatly reduced
```
