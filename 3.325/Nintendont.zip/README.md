# Nintendont 3.325
Commit: d816ebc4da4ce2ebb68c269967524a60ad0f0ece  
Time: Wed Mar 18 16:53:24 2015   

-----

```
commit d816ebc4da4ce2ebb68c269967524a60ad0f0ece
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Mar 18 16:53:24 2015 +0000

    -added back manual memory invalidation because some games (turok evolution) dont seem todo it on their own
```
