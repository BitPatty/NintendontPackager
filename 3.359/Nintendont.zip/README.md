# Nintendont 3.359
Commit: de57c47588c95021df43d0dd1fc5828e44a9eda7  
Time: Fri Jul 24 20:16:31 2015   

-----

```
commit de57c47588c95021df43d0dd1fc5828e44a9eda7
Author: FIX94 <fix94.1@gmail.com>
Date:   Fri Jul 24 20:16:31 2015 +0200

    -added missing __CARDUnlock patch for the BIOS and the launch games
    -added widescreen patches for NFL Blitz 2002, 2003 and Pro
```
