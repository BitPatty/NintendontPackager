# Nintendont 4.434
Commit: e9d12614e0d6bb808a0bb637e2a05175f4804410  
Time: Tue Jan 17 21:12:28 2017   

-----

```
commit e9d12614e0d6bb808a0bb637e2a05175f4804410
Author: FIX94 <fix94.1@gmail.com>
Date:   Tue Jan 17 21:12:28 2017 +0100

    updated for and recompiled with the latest devkitARM r46, devkitPPC r29 and libOGC 1.8.16
```
