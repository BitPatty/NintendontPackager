# Nintendont 3.391
Commit: 614fa315e4070b7546f98c4830c91487e3f13607  
Time: Thu May 5 21:35:12 2016   

-----

```
commit 614fa315e4070b7546f98c4830c91487e3f13607
Author: FIX94 <fix94.1@gmail.com>
Date:   Thu May 5 21:35:12 2016 +0200

    -swapped left and right channel for audio streaming data, it was reversed before
```
