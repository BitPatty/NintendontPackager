# Nintendont 2.242
Commit: 004695c77872c17d8dc9f1b6fca8ab7881a5ef49  
Time: Sun Dec 7 21:19:53 2014   

-----

```
commit 004695c77872c17d8dc9f1b6fca8ab7881a5ef49
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Dec 7 21:19:53 2014 +0000

    -Remove second PSO memcard emu hack.  This was also made unnecessary by r227.
    -Add support for Datel AGP disc.  This disc does not use the Nintendo SDK, so many functions are done in different ways are have different patterns.  Currently only supports Native SI and MemcardEmu off.  The actual hardware reading is not yet functional.
```
