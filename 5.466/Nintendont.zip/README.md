# Nintendont 5.466
Commit: 6653c99e42ce5ad3ad8f7fa2a35994bb4b5ec18c  
Time: Fri Sep 29 21:37:44 2017   

-----

```
commit 6653c99e42ce5ad3ad8f7fa2a35994bb4b5ec18c
Author: FIX94 <fix94.1@gmail.com>
Date:   Fri Sep 29 21:37:44 2017 +0200

    -improved wiiu gamepad stick range a bit
    -when in device/game selection in the loader, allow console shutdown
```
