# Nintendont 1.97
Commit: 36fbe8457cee51ea79a407344107324d0a0b339b  
Time: Mon Jun 23 18:20:36 2014   

-----

```
commit 36fbe8457cee51ea79a407344107324d0a0b339b
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Jun 23 18:20:36 2014 +0000

    -moved some more disc read code into the disc read thread, this should not change game behavior or compatibility
```
