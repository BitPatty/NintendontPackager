# Nintendont 2.169
Commit: 5439a4aa7b230a238cf1b40b6cfa10e5bf1b79eb  
Time: Fri Oct 10 21:13:38 2014   

-----

```
commit 5439a4aa7b230a238cf1b40b6cfa10e5bf1b79eb
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Oct 10 21:13:38 2014 +0000

    -added hardcoded patches for pokemon colosseum pal and ntsc which will report the memory card is always inserted with memcard emu enabled, this way you can actually save and load
```
