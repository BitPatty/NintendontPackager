# Nintendont 4.425
Commit: 2260400bbc994f9069a621f0c73dc023610771e9  
Time: Fri Oct 14 02:58:30 2016   

-----

```
commit 2260400bbc994f9069a621f0c73dc023610771e9
Author: FIX94 <fix94.1@gmail.com>
Date:   Fri Oct 14 02:58:30 2016 +0200

    -forgot to update segaboot ambb checksum in tri arcade mode
```
