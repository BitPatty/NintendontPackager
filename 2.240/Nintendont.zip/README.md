# Nintendont 2.240
Commit: 7720012f0772259633f01a567fe6cf1a3a40928f  
Time: Sat Dec 6 22:40:46 2014   

-----

```
commit 7720012f0772259633f01a567fe6cf1a3a40928f
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Dec 6 22:40:46 2014 +0000

    -reworked audio stream base to go through the actual disc interface code instead of a hacked one, that way starfox adventures should have enough time to properly enable its subtitles
    -use the same fatfs settings as we did in the past
    -minor cache sync corrections
```
