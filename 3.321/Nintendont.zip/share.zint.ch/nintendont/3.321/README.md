# Nintendont 3.321
Commit: 142b6d3deed222e899f8a220d4c4768655af1559  
Time: Thu Mar 12 16:51:33 2015   

-----

```
commit 142b6d3deed222e899f8a220d4c4768655af1559
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Thu Mar 12 16:51:33 2015 +0000

    -added more timers and made the timer patches more agressive, fixes hitman 2 and hobbit
    -added disneys haunted mansion to the arstartdma exception list
```
