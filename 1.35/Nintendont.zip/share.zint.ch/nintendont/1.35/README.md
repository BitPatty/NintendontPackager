# Nintendont 1.35
Commit: 675a4838227c4e1fa27e386410ccbe36e152f706  
Time: Fri May 9 02:58:55 2014   

-----

```
commit 675a4838227c4e1fa27e386410ccbe36e152f706
Author: JoostinOnline@gmail.com <JoostinOnline@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri May 9 02:58:55 2014 +0000

    -Set Patch.c dbgprintf code as a separate category so it can be disabled if necessary
```
