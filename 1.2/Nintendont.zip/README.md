# Nintendont 1.2
Commit: 4126b9e0f0c81419ba33d30c886ff0ff662431ff  
Time: Sun Apr 27 17:54:51 2014   

-----

```
commit 4126b9e0f0c81419ba33d30c886ff0ff662431ff
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Apr 27 17:54:51 2014 +0000

    -added a small patch to fix up some japanese games on non-japanese consoles
```
