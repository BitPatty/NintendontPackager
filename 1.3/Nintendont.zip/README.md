# Nintendont 1.3
Commit: b6ec3f2fe1116185ebb842e4ecd7b31ba9c18398  
Time: Sun Apr 27 20:57:46 2014   

-----

```
commit b6ec3f2fe1116185ebb842e4ecd7b31ba9c18398
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Apr 27 20:57:46 2014 +0000

    Attempt to fix reset hangups.
    Speed up memory card writes.
```
