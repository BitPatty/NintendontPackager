# Nintendont 5.479
Commit: d6bf7e53bf27b99e648d983b3c09b50f5e1374ce  
Time: Mon Oct 30 22:44:46 2017   

-----

```
commit d6bf7e53bf27b99e648d983b3c09b50f5e1374ce
Author: FIX94 <fix94.1@gmail.com>
Date:   Mon Oct 30 22:44:46 2017 +0100

    -added tales of symphonia into arstartdma exception list to remove its beeps on battle start/end
    -added fire emblem into read limit remove list to hopefully stabilize its chapter transitions
    -added triforce titles into manual DI invalidate exception list to hopefully make its loading more stable
```
