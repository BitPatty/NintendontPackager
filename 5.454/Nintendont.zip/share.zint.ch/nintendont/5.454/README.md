# Nintendont 5.454
Commit: f97a4bdcebf938a1f6a73712da069fae3222bf87  
Time: Sat Sep 16 23:11:01 2017   

-----

```
commit f97a4bdcebf938a1f6a73712da069fae3222bf87
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Sep 16 23:11:01 2017 +0200

    -use reset code for wii vc so pressing the power button or pressing the exit combo will reboot into wiiu menu
    -add wii vc to wiiu detection
```
