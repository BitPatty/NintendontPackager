# Nintendont 2.162
Commit: bfda49daef9c57a5a1033ad4824643bf03bed39d  
Time: Sat Sep 20 15:25:07 2014   

-----

```
commit bfda49daef9c57a5a1033ad4824643bf03bed39d
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Sep 20 15:25:07 2014 +0000

    -sending interrupt messages through unused EXI device 2 hardware registers instead of main memory, saves some time and space
    -added starfox assault ntsc save exception and commented out baten kaitos save hack
    -made all gc relevant patches static, this might fix a bunch of games
```
