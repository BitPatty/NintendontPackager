# Nintendont 3.392
Commit: aa6dbe6758505d2356806702472bebb2e22ec20f  
Time: Thu May 12 18:40:20 2016   

-----

```
commit aa6dbe6758505d2356806702472bebb2e22ec20f
Author: FIX94 <fix94.1@gmail.com>
Date:   Thu May 12 18:40:20 2016 +0200

    -added __PADSetSamplingRate patch to fix crashes in certain ntsc games when forcing pal60
```
