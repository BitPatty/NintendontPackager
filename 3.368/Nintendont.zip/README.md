# Nintendont 3.368
Commit: d67e48778db265f6a9f35632f3121365e8c378af  
Time: Thu Aug 6 00:38:33 2015   

-----

```
commit d67e48778db265f6a9f35632f3121365e8c378af
Author: FIX94 <fix94.1@gmail.com>
Date:   Thu Aug 6 00:38:33 2015 +0200

    -mistakes! I do them all the time
```

```
commit 24ce55308476243a059d4c53fbef6b44b956989f
Author: FIX94 <fix94.1@gmail.com>
Date:   Thu Aug 6 00:36:39 2015 +0200

    -added an option to patch PAL50 when using a forced video mode, note that enabling this option will turn the patcher more aggressive and will change its compatibility
```
