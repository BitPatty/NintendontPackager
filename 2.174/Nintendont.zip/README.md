# Nintendont 2.174
Commit: fccdb6759e63797ce155fd1dc99ef1552f64760e  
Time: Tue Oct 14 13:24:59 2014   

-----

```
commit fccdb6759e63797ce155fd1dc99ef1552f64760e
Author: JoostinOnline@gmail.com <JoostinOnline@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Oct 14 13:24:59 2014 +0000

    -Added in-app updater, accessible through Settings menu
```
