# Nintendont 1.32
Commit: e873e88887b32974e1e6c046ca2062f29472ab92  
Time: Thu May 8 23:17:15 2014   

-----

```
commit e873e88887b32974e1e6c046ca2062f29472ab92
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Thu May 8 23:17:15 2014 +0000

    Add support for japanese font.
    -Use either ipl.bin or font_sjis.bin
```
