# Nintendont 3.306
Commit: 11443ee3eebda2e04f321459546adbcd780df465  
Time: Thu Feb 26 20:42:56 2015   

-----

```
commit 11443ee3eebda2e04f321459546adbcd780df465
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Thu Feb 26 20:42:56 2015 +0000

    -fixed some broken pad rumble code and added a missing pattern
    -changed up some disc code, it should still work just like before, the only difference is that no actual disc drive needs to be in place to work from sd/usb
    -added widescreen patch for super monkey ball
```
