# Nintendont 5.472
Commit: 83ef71c72cf3d8cd4ac3a139b9cad2bf2e9f0fe4  
Time: Wed Oct 18 06:57:50 2017   

-----

```
commit 83ef71c72cf3d8cd4ac3a139b9cad2bf2e9f0fe4
Author: FIX94 <fix94.1@gmail.com>
Date:   Wed Oct 18 06:57:50 2017 +0200

    -added timer patch to sonic mega collection to fix its occasional audio skipping
```
