# Nintendont 1.116
Commit: 12c11754c66e4a008a0c4cb93f46a3c3a129c1e0  
Time: Thu Jul 3 16:43:37 2014   

-----

```
commit 12c11754c66e4a008a0c4cb93f46a3c3a129c1e0
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Thu Jul 3 16:43:37 2014 +0000

    Add Dspv14 Dspv15.
    Attempt to speed up Dsp searching code.
```
