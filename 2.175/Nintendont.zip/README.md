# Nintendont 2.175
Commit: 63c0bcd774b9cd0b9ad88d945053e978ad7afb0e  
Time: Wed Oct 15 18:30:11 2014   

-----

```
commit 63c0bcd774b9cd0b9ad88d945053e978ad7afb0e
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Oct 15 18:30:11 2014 +0000

    -added a very general game timer patcher which should cover up most games which run too fast
```
