# Nintendont 4.451
Commit: a960793ce4b61fbe90fc92b8acf9271d2689f99f  
Time: Sat Sep 2 04:57:37 2017   

-----

```
commit a960793ce4b61fbe90fc92b8acf9271d2689f99f
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Sep 2 04:57:37 2017 +0200

    -improved pokemon colosseum/xd memset patch so it wont blackscreen anymore when using cheats/debugger
    -fixed pokemon colosseum/xd ingame code that when pressing all the way down could incorrectly register it as pressing all the way up
```
