# Nintendont 6.495
Commit: bcebe931a32385a5f347190c38b4db78011916fc  
Time: Mon May 24 22:28:58 2021   

-----

```
commit bcebe931a32385a5f347190c38b4db78011916fc
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Mon May 24 22:28:58 2021 +0100

    removed some files
```

```
commit b6946f98dbaaa892a12ff792c06e4c0ff09cd409
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Mon May 24 22:27:45 2021 +0100

    Fixed some issues with hid and wiiugamepad prioritys
    
    Ps3 and single hids should now work correctly along with wiiu gamepad setting.
    
    Also all dualshock 3 controllers should rumble on wiiu being in vwii or wiivc
```
