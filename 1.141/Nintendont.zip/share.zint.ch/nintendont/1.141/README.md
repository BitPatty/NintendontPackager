# Nintendont 1.141
Commit: 19b48a7487ec83d24fabf88bbf376c6e59ff6632  
Time: Sun Aug 10 00:46:52 2014   

-----

```
commit 19b48a7487ec83d24fabf88bbf376c6e59ff6632
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Aug 10 00:46:52 2014 +0000

    -rewrote the mechanics of the multidol loader, now it can load everything from zelda collectors edition including the nes games and the movies
    -slighly changed the code behind the patching system, shouldnt make any difference
    -returning ORed bitmap of pads which can rumble as the official nintendo function does, this might fix games having no rumble
```
