# Nintendont 5.465
Commit: 2d8376951a441493b32d4ff0c18791fec680c61e  
Time: Fri Sep 29 09:42:12 2017   

-----

```
commit 2d8376951a441493b32d4ff0c18791fec680c61e
Author: FIX94 <fix94.1@gmail.com>
Date:   Fri Sep 29 09:42:12 2017 +0200

    -added timer values when running on a wiiu with the cpu clocked up at 1.215ghz
    -added string in displayed version to indicate when the wiiu cpu runs that higher clock
```
