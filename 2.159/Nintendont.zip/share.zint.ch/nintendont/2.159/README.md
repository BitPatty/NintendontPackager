# Nintendont 2.159
Commit: fc7bc5f5309a58adf3255da572e9df4c94df8b95  
Time: Sun Sep 14 23:53:22 2014   

-----

```
commit fc7bc5f5309a58adf3255da572e9df4c94df8b95
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Sep 14 23:53:22 2014 +0000

    -Fixed wii classic controller analog triggers getting stuck slightly in when connecting using bluetooth
```
