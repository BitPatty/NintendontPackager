# Nintendont 2.204
Commit: a1290aae5ebed6ea912172cee9f927611a242eee  
Time: Sun Nov 2 17:32:24 2014   

-----

```
commit a1290aae5ebed6ea912172cee9f927611a242eee
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Nov 2 17:32:24 2014 +0000

    -Added Nvidia Shield controller.ini (Thanks bobmcjr)
```

```
commit 1f9c244c964ba32120760834e6f600b74d2152ca
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Nov 2 14:09:58 2014 +0000

    -correct force video mode setting in the loader menu, it should now navigate properly
    -added a security patch reset when the game is about to reset itself, fixes sonic cd exit
    -added a better GXInit search, should fix virtua striker 3
    -added disney hide and sneak ARStartDMA exception
```
