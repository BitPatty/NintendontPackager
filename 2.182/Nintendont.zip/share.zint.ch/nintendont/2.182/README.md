# Nintendont 2.182
Commit: 2952124f9a89f016bd74db838a8ef2ad9f083b6a  
Time: Sun Oct 19 20:14:58 2014   

-----

```
commit 2952124f9a89f016bd74db838a8ef2ad9f083b6a
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Oct 19 20:14:58 2014 +0000

    -making sure to clear the current stream position after the audio stream ends, fixes xg3 stream looping
```
