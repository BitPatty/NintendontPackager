# Nintendont 2.280
Commit: 61097b361ce594cd5605504075415dded5504214  
Time: Sat Jan 24 01:09:47 2015   

-----

```
commit 61097b361ce594cd5605504075415dded5504214
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Jan 24 01:09:47 2015 +0000

    -added Piglet's Big Game to the ARStartDMA exception list to fix sound issues ingame
    -added an additional DOL file security check before patching, fixes WrestleMania X8
```
