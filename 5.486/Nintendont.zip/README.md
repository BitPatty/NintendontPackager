# Nintendont 5.486
Commit: 7be1b6df41f07f39fd8e67dfd8be7b0b68209fc7  
Time: Tue Dec 18 00:36:12 2018   

-----

```
commit 7be1b6df41f07f39fd8e67dfd8be7b0b68209fc7
Author: FIX94 <fix94.1@gmail.com>
Date:   Tue Dec 18 00:36:12 2018 +0100

    -added piece treasure battle demo to arstartdma exception list
    -compiled with latest devkitppc r33, libogc 1.8.21 and devkitarm r50
```
