# Nintendont 6.488
Commit: 685d039d26e7575b65b7eb9c2b2454c7d0342722  
Time: Mon Oct 7 23:27:27 2019   

-----

```
commit 685d039d26e7575b65b7eb9c2b2454c7d0342722
Author: FIX94 <fix94.1@gmail.com>
Date:   Mon Oct 7 23:27:27 2019 +0200

    Update BBA_Readme.md
```

```
commit 88bd74a274c78482eff9176279ce100f695ee495
Author: FIX94 <fix94.1@gmail.com>
Date:   Mon Oct 7 23:19:09 2019 +0200

    -added yet another redirection patch to pso ep 3 which should fix some crashes when cheats or debugger is used
    -only allow usb keyboards when native controls are off, or else it would make it impossible to use a real gc keyboard in native mode if wanted
```
