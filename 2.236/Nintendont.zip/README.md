# Nintendont 2.236
Commit: 8d6f77cb79b7bdbd20955b5c2e5f2d82b5dc7234  
Time: Tue Dec 2 23:06:53 2014   

-----

```
commit 8d6f77cb79b7bdbd20955b5c2e5f2d82b5dc7234
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Dec 2 23:06:53 2014 +0000

    -changed up HID reading to not rely on a timer anymore, this way it should run more precise
```
