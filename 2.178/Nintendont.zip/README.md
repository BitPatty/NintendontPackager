# Nintendont 2.178
Commit: e62e26557d39399c715c47dba62b29a2ce8b3f41  
Time: Fri Oct 17 16:31:11 2014   

-----

```
commit e62e26557d39399c715c47dba62b29a2ce8b3f41
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Oct 17 16:31:11 2014 +0000

    -fixed tiny mistake in f-zero ax pad read function, messed up the dpad, also slighly reduced its pad updating to save some time
```
