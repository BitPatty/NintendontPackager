# Nintendont 3.382
Commit: 17b995a3336fac8c2ecc0614e6f8796ae26c1309  
Time: Sun Jan 3 22:30:57 2016   

-----

```
commit 17b995a3336fac8c2ecc0614e6f8796ae26c1309
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Jan 3 22:30:57 2016 +0100

    -added a proper multi-iso game check so it wont be confused for call of duty anymore
```
