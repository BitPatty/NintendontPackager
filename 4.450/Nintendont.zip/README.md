# Nintendont 4.450
Commit: e02a6df593b49cb7a2cf61a1fb5711c7b1264f3a  
Time: Fri Sep 1 07:35:01 2017   

-----

```
commit e02a6df593b49cb7a2cf61a1fb5711c7b1264f3a
Author: FIX94 <fix94.1@gmail.com>
Date:   Fri Sep 1 07:35:01 2017 +0200

    loader somehow did not get pushed through...
```

```
commit 43ff919915bf32fd346c0ee1b119ac2467dea5f4
Author: FIX94 <fix94.1@gmail.com>
Date:   Fri Sep 1 07:25:20 2017 +0200

    -added aggressive rel timer patches for blood omen 2
    -only look and patch timer code in rel patches to avoid false timer float writes
```
