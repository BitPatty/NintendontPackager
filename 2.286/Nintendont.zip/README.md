# Nintendont 2.286
Commit: 8f5326e2a0be34972aba7faff56cbe65108806e1  
Time: Tue Feb 3 23:07:26 2015   

-----

```
commit 8f5326e2a0be34972aba7faff56cbe65108806e1
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Feb 3 23:07:26 2015 +0000

    -fixed a drastic bug in triforce code which randomly broke all sorts of commands, this should help out various problems such as JVSIO errors and not working controls
    -enabled CARD support in both GP1 and GP2 because they now seem to work on a usable level, to save into them you just need to say "no" on continue after racing, just wait a few seconds after that until you exit nintendont
```
