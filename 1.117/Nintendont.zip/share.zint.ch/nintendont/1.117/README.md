# Nintendont 1.117
Commit: ecd2a2f466f56364e7c57ed75a58af7757d1e65a  
Time: Thu Jul 3 17:28:53 2014   

-----

```
commit ecd2a2f466f56364e7c57ed75a58af7757d1e65a
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Thu Jul 3 17:28:53 2014 +0000

    -further optimized and cleaned up the multidol tgc loader code
```
