# Nintendont 2.216
Commit: c8ac904677811de007c0100ca768b3b89f05b30c  
Time: Wed Nov 12 00:20:34 2014   

-----

```
commit c8ac904677811de007c0100ca768b3b89f05b30c
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Nov 12 00:20:34 2014 +0000

    -make sure that SetInterruptMask from the debug sdk cant write to EXI Channel 2 when memcard emu is disabled (fixes batman vengeance from real memory card)
```
