# Nintendont 3.393
Commit: a6151a3c5de8571ce677b286006c5ac2d7a4caa2  
Time: Sat May 14 17:12:30 2016   

-----

```
commit a6151a3c5de8571ce677b286006c5ac2d7a4caa2
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat May 14 17:12:30 2016 +0200

    -renamed the "Drive Read LED" option to "Drive Access LED" and changed its code to also enable the drive tray led when writing to sd/usb to know if things are getting done correctly
```
