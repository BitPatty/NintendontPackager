# Nintendont 2.251
Commit: 96b3922aaa5faa26c791f2b570972ee170f0e849  
Time: Fri Dec 12 12:40:29 2014   

-----

```
commit 96b3922aaa5faa26c791f2b570972ee170f0e849
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Dec 12 12:40:29 2014 +0000

    -Do not recenter axes when using Bongos with the WiiU Gamecube Adapter.
    -Make Datel timer patching use a pattern instead of hard-coded offsets.
```
