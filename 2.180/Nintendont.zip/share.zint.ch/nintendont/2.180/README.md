# Nintendont 2.180
Commit: dab54dac1e01efaece9ead729aa3a450c3d5165b  
Time: Sat Oct 18 18:54:27 2014   

-----

```
commit dab54dac1e01efaece9ead729aa3a450c3d5165b
Author: JoostinOnline@gmail.com <JoostinOnline@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Oct 18 18:54:27 2014 +0000

    -Nintenont updater now shows what revision is being downloaded, and makes sure you don't already have the latest version
    -Additional minor changes to the updater
```
