# Nintendont 2.210
Commit: e39ec5026cf887a43f4fa9f03e6d0cb12236d272  
Time: Sun Nov 9 22:28:20 2014   

-----

```
commit e39ec5026cf887a43f4fa9f03e6d0cb12236d272
Author: JoostinOnline@gmail.com <JoostinOnline@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Nov 9 22:28:20 2014 +0000

    -Gave Nintendont a nice polished interface.  It now has a background and a truetype font (no more jaggies)
    -You can now see more of the game title.
    -Fixed a warning if DEBUG_PATCH is disabled.
    
    Thanks to ccfman2004, VinsCool, and Shiranui-san for the valuable input they've provided on this release.
```
