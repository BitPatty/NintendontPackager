# Nintendont 1.41
Commit: 30b5ad4efac693d486864b86005119c3eb7eb42b  
Time: Sat May 10 01:05:17 2014   

-----

```
commit 30b5ad4efac693d486864b86005119c3eb7eb42b
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat May 10 01:05:17 2014 +0000

    -took out the disc read input check of r40 again, I dont know why it would break for some people but whatever...
```

```
commit bb8d7abee9ddbad1527f722b2703b88a826c018a
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat May 10 00:03:56 2014 +0000

    -Moved writing the version info into ndebug.log so it is always written first
```
