# Nintendont 2.285
Commit: 74838f446a2fc6872d5510b1b1a4adcbf0ada5b9  
Time: Tue Feb 3 17:49:18 2015   

-----

```
commit 74838f446a2fc6872d5510b1b1a4adcbf0ada5b9
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Feb 3 17:49:18 2015 +0000

    -if memcard emu is disabled skip the gc bios for now because it doesnt work
    -added a missing EXI call, fixes f-zero ax starting via segaboot if OSReport is disabled
    -made it possible to press service and test button in triforce games, the test button is Z and the service button is X, please note that as of now there is no way to exit the test menu
```
