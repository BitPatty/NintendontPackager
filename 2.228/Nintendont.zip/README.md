# Nintendont 2.228
Commit: 88bf67ea177b65c40b900ee68d94a24deece0ba3  
Time: Wed Nov 26 17:18:17 2014   

-----

```
commit 88bf67ea177b65c40b900ee68d94a24deece0ba3
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Nov 26 17:18:17 2014 +0000

    -added init code and rumble support for the wiiu gc adapter, thank you ToadKing for providing the magic numbers and GreyRogue for testing everything out
```
