# Nintendont 3.390
Commit: 0bbc39ec5105d954690f1c88981dc62cdd70c9b3  
Time: Mon May 2 02:50:00 2016   

-----

```
commit 0bbc39ec5105d954690f1c88981dc62cdd70c9b3
Author: FIX94 <fix94.1@gmail.com>
Date:   Mon May 2 02:50:00 2016 +0200

    -fixed up triforce free play patch when using segaboot 3.11.2 from gdt-0022a
    -added back video mode debug prints into the loader, accidentally deleted them on the last changes
```
