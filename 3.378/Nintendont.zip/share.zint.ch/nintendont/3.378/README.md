# Nintendont 3.378
Commit: 570221daa65e461d047379e6661612033dcd6d37  
Time: Sat Nov 28 15:41:30 2015   

-----

```
commit 570221daa65e461d047379e6661612033dcd6d37
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Nov 28 15:41:30 2015 +0100

    -changed the cache control in the main pad read file, this should fix the massive delay with the port 3 and 4 gc adapter reads some games had
```
