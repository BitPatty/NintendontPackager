# Nintendont 2.154
Commit: e0eb72dc0c2031a677b9215fb478001e9e8c1a7a  
Time: Mon Sep 8 03:37:18 2014   

-----

```
commit e0eb72dc0c2031a677b9215fb478001e9e8c1a7a
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Sep 8 03:37:18 2014 +0000

    -Added shutdown combination (B,Z,R,PAD_BUTTON_DOWN) to bluetooth controllers
    -Fixed Multi controller adapters using MultiIn=2 working in conjunction with blutooth controllers
    -Added Hori Real Arcade Pro 3 SA controller.ini (Thanks galneon)
```
