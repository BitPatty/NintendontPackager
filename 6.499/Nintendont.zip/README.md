# Nintendont 6.499
[Direct Download](./Nintendont.zip)

Commit: 7b1b4cd0562e36fb37f5373e2da5d66e218c084e  
Time: Fri Jan 20 18:07:25 2023   

-----

```
commit 7b1b4cd0562e36fb37f5373e2da5d66e218c084e
Merge: 2760631 1321680
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Fri Jan 20 18:07:25 2023 +0000

    Merge pull request #1049 from bibarub/bibarub-patch-1
    
    DualSense controller config
```

```
commit 27606319cd9ab16231accd0968870ee67c0514d6
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Tue Nov 1 23:02:11 2022 +0000

    Fixed Disney Skatboarding freeze on objectives
    
    Made some  merges and added sonic dx to always connected so it doesnt disconnect wiiugc adapter controllers.
```
