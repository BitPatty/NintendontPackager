# Nintendont 2.191
Commit: c6706e81248dfdc29102d9742b2d9da80e1e4009  
Time: Fri Oct 24 00:08:05 2014   

-----

```
commit c6706e81248dfdc29102d9742b2d9da80e1e4009
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Oct 24 00:08:05 2014 +0000

    -Added Trust Predator Gamepad controller.ini(Thanks L0r3n20)
```

```
commit f5085cc74dcf5de2892c48d70a8284fe9f4b8d6b
Author: JoostinOnline@gmail.com <JoostinOnline@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Thu Oct 23 21:38:30 2014 +0000

    -The controller files now use the VID and PID.
    
    Sorry, you need to redownload controllers.zip
```

```
commit 079aafd4ac8c7a4452c941d5f1f25e3db834d336
Author: JoostinOnline@gmail.com <JoostinOnline@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Thu Oct 23 17:33:55 2014 +0000

    -Your controller will now be detected and the appropriate .ini file will be selected.  Extract the contents of controllers.zip to a folder named controllers in the root of your FAT device (so you'll have FAT:\controllers\0001.ini).
    -Added exceptions for Virtua Striker v4 2006 (GVSJ9P, GVS46J, GVS46E) in the title database.  This doesn't include ISO's that, for some weird reason, have had the title ID modified to match the 2002 version.
    -Removed "Sonic Adventure DX: Director's Cut (Preview) Prototype" entry because it was useless and conflicting with some custom titles.
    
    Note: The old controller.ini method still works, so if you only use one controller you don't have to change anything.
```
