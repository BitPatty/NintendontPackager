# Nintendont 1.81
Commit: 7d5c060a62038f8cca9f1de432f0363927562aed  
Time: Sat Jun 7 04:47:48 2014   

-----

```
commit 7d5c060a62038f8cca9f1de432f0363927562aed
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Jun 7 04:47:48 2014 +0000

    Disable SI interrupts if disabled by game.
    -Fixes 007 games.
    Reset patch found variables when loading a new elf/dol.
    -Fixes 007 games.
    Use the log for patch_fwrite instead of UsbGecko.
    -Shows OSReport strings in ndebug.log
    -Should probably make this an option for one or the other, or always do both instead.
```
