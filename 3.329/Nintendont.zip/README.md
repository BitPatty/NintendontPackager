# Nintendont 3.329
Commit: 8d3b0b02dc392f36da4d2a74c0f4dc4135f812e4  
Time: Sat Apr 18 18:54:45 2015   

-----

```
commit 8d3b0b02dc392f36da4d2a74c0f4dc4135f812e4
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Apr 18 18:54:45 2015 +0000

    -added a dirty workaround for freekstyle running too quick, this is not an actual timer fix but more of a slowdown effect
```
