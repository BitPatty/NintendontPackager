# Nintendont 2.176
Commit: 582ab3a7d16dc0d22f66421709d59925e1338ebc  
Time: Fri Oct 17 01:04:33 2014   

-----

```
commit 582ab3a7d16dc0d22f66421709d59925e1338ebc
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Oct 17 01:04:33 2014 +0000

    -moved resident evil 4 and sonic gems collection into the paper mario arstartdma exception list to fix their sound issues
    -added yet another timer check, this time for the cpu speed, might help out more games
```
