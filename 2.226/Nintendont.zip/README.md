# Nintendont 2.226
Commit: a4713fab334cff63106a076b6e738014822a05d6  
Time: Sun Nov 23 22:34:09 2014   

-----

```
commit a4713fab334cff63106a076b6e738014822a05d6
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Nov 23 22:34:09 2014 +0000

    -optimized ISO reading and caching code, might be a bit faster in certain situations
    -removed cache.txt support because in most cases its slower anyways
    -added super smash bros melee widescreen patch
```
