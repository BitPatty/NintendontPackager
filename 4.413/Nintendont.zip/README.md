# Nintendont 4.413
Commit: 8aa1f8331a8e099e294a9d8e1f29cf45a0ccb729  
Time: Wed Jun 29 17:18:02 2016   

-----

```
commit 8aa1f8331a8e099e294a9d8e1f29cf45a0ccb729
Author: FIX94 <fix94.1@gmail.com>
Date:   Wed Jun 29 17:18:02 2016 +0200

    -fixed a small bug with the mario karts, after entering the test menu the wheel init would not work anymore when leaving it
    -only allow the service button getting pressed when you are in the test menu, it just freezes up the game for a second otherwise
    -updated internal triforce game versions, now the mario karts have the build date as version and the unknown f-zero ax revision is now set to revision d
```
