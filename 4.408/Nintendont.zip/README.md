# Nintendont 4.408
Commit: 803e651738887b236dbc65a1236f6c818c9a5450  
Time: Sun Jun 19 03:08:10 2016   

-----

```
commit 803e651738887b236dbc65a1236f6c818c9a5450
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Jun 19 03:08:10 2016 +0200

    -starting mario kart arcade gp and gp 2 through their main function now, this allows them to do more startup checks and also fixes some issues the games had such as the not correctly working attract mode in gp 2, now they should work exactly as you would expect
```
