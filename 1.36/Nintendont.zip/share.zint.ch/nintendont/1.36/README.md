# Nintendont 1.36
Commit: 052b9375e4a8f4b744e5c0e185e26d3e550aa0c5  
Time: Fri May 9 13:18:18 2014   

-----

```
commit 052b9375e4a8f4b744e5c0e185e26d3e550aa0c5
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri May 9 13:18:18 2014 +0000

    -creating cache before we enter the game now, this way too slow devices should not cause any error anymore
```
