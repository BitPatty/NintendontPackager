# Nintendont 1.27
Commit: 6f1e448aca99fe566f4069c4cfab9290e9083adc  
Time: Wed May 7 01:57:00 2014   

-----

```
commit 6f1e448aca99fe566f4069c4cfab9290e9083adc
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed May 7 01:57:00 2014 +0000

    -used wrong devkit for r27, sorry
```

```
commit a6179982cc764f5720b8eddfc8ac833d6bfe1788
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed May 7 01:39:48 2014 +0000

    -added a new controller patching method which seems to be required for some games to be controllable, its still not fully tested so I cant promise every game is controllable now
```
