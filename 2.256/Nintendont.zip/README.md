# Nintendont 2.256
Commit: c36eb07bd29981e332f0b8aa1d31e795d459d93e  
Time: Sun Dec 14 23:42:12 2014   

-----

```
commit c36eb07bd29981e332f0b8aa1d31e795d459d93e
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Dec 14 23:42:12 2014 +0000

    -allow the DSP patch to get applied multiple times for games which have multiple DSP ROMs, this should fix broken audio in the remaining games with audio problems
```
