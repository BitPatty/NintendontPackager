# Nintendont 3.375
Commit: 2c67824800ec4068b76cd636c0bd14341a22d91e  
Time: Sat Nov 7 19:02:39 2015   

-----

```
commit 2c67824800ec4068b76cd636c0bd14341a22d91e
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Nov 7 19:02:39 2015 +0100

    -added support for the triforce game gekitou pro yakyuu (rev b and c) and adjusted the controls of the virtua striker games to be closer to what they should be
```
