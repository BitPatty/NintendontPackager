# Nintendont 1.4
Commit: b96da97ca2a686e21ac48ed78e4da10eb7322661  
Time: Sun Apr 27 23:10:40 2014   

-----

```
commit b96da97ca2a686e21ac48ed78e4da10eb7322661
Author: cyan@mangaheart.org <cyan@mangaheart.org@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Apr 27 23:10:40 2014 +0000

    Fix black screen when using interlace with component cable.
```
