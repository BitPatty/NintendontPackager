# Nintendont 2.289
Commit: c41ddd625da01dbf52e945340aac08494dccb621  
Time: Thu Feb 5 23:32:16 2015   

-----

```
commit c41ddd625da01dbf52e945340aac08494dccb621
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Thu Feb 5 23:32:16 2015 +0000

    -added proper widescreen patches to mario kart gp1 as well as gp2
    -removed a few menu timers in mario kart gp1
    -fixed the killer7 pal version running too fast
```
