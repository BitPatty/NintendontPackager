# Nintendont 4.418
Commit: 27595ea0ebfacca096be0e87e8205856f51211c8  
Time: Fri Jul 15 19:36:06 2016   

-----

```
commit 27595ea0ebfacca096be0e87e8205856f51211c8
Author: FIX94 <fix94.1@gmail.com>
Date:   Fri Jul 15 19:36:06 2016 +0200

    -executing the codehandler once directly before the game boot, this will make sure that cheats which affect the game boot will work properly
    -added a low memory patch for f-zero gx, this will make sure the codehandler wont crash on execution
```
