# Nintendont 3.403
Commit: 3287519e38a8d119f83793827f8c457787bb4027  
Time: Wed Jun 8 16:10:51 2016   

-----

```
commit 3287519e38a8d119f83793827f8c457787bb4027
Author: FIX94 <fix94.1@gmail.com>
Date:   Wed Jun 8 16:10:51 2016 +0200

    -improved kernel time conversion to be more accurate over longer time periods
    -set the initial kernel loop delay to be equal to the one used when a game is running to ensure hid controllers get the same amount of updates in the loader already
```
