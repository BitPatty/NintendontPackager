# Nintendont 6.496
[Direct Download](./Nintendont.zip)
Commit: fd5e85c4fe4c4015936e21b16242fa0f15449e99  
Time: Sat May 29 15:35:48 2021   

-----

```
commit fd5e85c4fe4c4015936e21b16242fa0f15449e99
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Sat May 29 15:35:48 2021 +0100

    Workaround for wiiugamepad and autoboot injects
    
    if you got an autoboot game in internal wiiunand/wiiu formated hdd, the wiiu gamepad will be player 1 if no hid is connected to usb ports, if an hid is connected to usb ports wiiugamepad goes to player 2.
```
