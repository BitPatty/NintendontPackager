# Nintendont 2.157
Commit: 72ad2b71d8f3ac803f69b691725b2360e2f04d4e  
Time: Wed Sep 10 17:39:50 2014   

-----

```
commit 72ad2b71d8f3ac803f69b691725b2360e2f04d4e
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Sep 10 17:39:50 2014 +0000

    -calibrating the bluetooth controller analog sticks now when you sync the controller, the first value it reads will be taken as the analog stick middle, to recalibrate just reconnect the controller
    -if you press "-" on your wiimote it will enable/disable rumble
    -if you press "-" on your classic controller/wiiu pro controller, it will change the control scheme to be rotated a quarter clockwise or to the original control scheme
    -if you hold "L" on your classic controller/wiiu pro controller, your inputs on ZL/ZR will be used as half pressed L and R buttons ingame
```
