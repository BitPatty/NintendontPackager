# Nintendont 3.369
Commit: e112c0598a01e791d9ea736fdc244fca6ac4dad9  
Time: Thu Aug 6 00:54:52 2015   

-----

```
commit e112c0598a01e791d9ea736fdc244fca6ac4dad9
Author: FIX94 <fix94.1@gmail.com>
Date:   Thu Aug 6 00:54:52 2015 +0200

    -adjusted progressive patch to the pal50 patch option accordingly
```
