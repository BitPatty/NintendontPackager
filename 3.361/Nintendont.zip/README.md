# Nintendont 3.361
Commit: c92053b3d1f09e4e1412a9a447ef5c85321533b1  
Time: Sat Jul 25 12:01:18 2015   

-----

```
commit c92053b3d1f09e4e1412a9a447ef5c85321533b1
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Jul 25 12:01:18 2015 +0200

    -added yet another __CARDUnlock IPL patch
```
