# Nintendont 1.1
Commit: a5b24842c0f7a63a0be3eed3d020d73e019a82ff  
Time: Sun Apr 27 16:51:39 2014   

-----

```
commit a5b24842c0f7a63a0be3eed3d020d73e019a82ff
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Apr 27 16:51:39 2014 +0000

    DSP fixes for v2, v3, v4, v6, and v9.
```
