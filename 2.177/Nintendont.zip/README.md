# Nintendont 2.177
Commit: f891c1b5065f1cbd92f3d8413822043f0c481b05  
Time: Fri Oct 17 13:46:38 2014   

-----

```
commit f891c1b5065f1cbd92f3d8413822043f0c481b05
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Oct 17 13:46:38 2014 +0000

    -added a small patch security check to make sure we actually patch a game loader and not some random data, should fix games like resident evil
    -added a few more hacks from quadforce for f-zero ax to make it bootable (thanks crediar)
    -added pad read function patches for f-zero ax to make it controllable
```
