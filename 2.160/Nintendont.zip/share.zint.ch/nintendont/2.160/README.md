# Nintendont 2.160
Commit: 548753c8461bff0ec0b31eb00fdeb2fbacb24111  
Time: Mon Sep 15 22:27:49 2014   

-----

```
commit 548753c8461bff0ec0b31eb00fdeb2fbacb24111
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Sep 15 22:27:49 2014 +0000

    -added libwupc, now you can use the wiiu pro controller in the loader and not just ingame
```
