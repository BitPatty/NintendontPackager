# Nintendont 2.166
Commit: 3752296ad0f370423d0ab7eac8e4269aaff9343d  
Time: Tue Sep 30 13:39:06 2014   

-----

```
commit 3752296ad0f370423d0ab7eac8e4269aaff9343d
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Sep 30 13:39:06 2014 +0000

    -added a new ARStartDMA patch which hooks itself into the original nintendo code instead of completely replacing it, this patch will be used by burnout 2, viewtiful joe, animal crossing and megaman x command mission
```
