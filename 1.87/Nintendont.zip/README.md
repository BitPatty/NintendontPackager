# Nintendont 1.87
Commit: ca95191c1b4e454134f9b4335c7daecea4ac2bfc  
Time: Mon Jun 16 22:35:09 2014   

-----

```
commit ca95191c1b4e454134f9b4335c7daecea4ac2bfc
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Jun 16 22:35:09 2014 +0000

    Change method to protect interrupt variables by separating interfaces to different locations.
```
