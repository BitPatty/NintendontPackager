# Nintendont 3.353
Commit: 092088664d8de79593d0d4aafe8eb7258cd40d47  
Time: Fri Jul 10 20:02:33 2015   

-----

```
commit 092088664d8de79593d0d4aafe8eb7258cd40d47
Author: FIX94 <fix94.1@gmail.com>
Date:   Fri Jul 10 20:02:33 2015 +0200

    -made the manual memory invalidation only for turok evolution because it seems to break other games
    -only apply the PSO related patches if the game is PSO, speeds up patching
    -let the game id be read once so we dont waste time on constantly re-reading it
```
