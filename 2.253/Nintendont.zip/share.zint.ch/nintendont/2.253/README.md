# Nintendont 2.253
Commit: 97a94f3ac5747da75efe6bd7238a23e996980d05  
Time: Sat Dec 13 17:25:08 2014   

-----

```
commit 97a94f3ac5747da75efe6bd7238a23e996980d05
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Dec 13 17:25:08 2014 +0000

    -added proper memory syncing in the jvsio code which might lower the chances of triforce games not having any coins or having other issues
```
