# Nintendont 1.21
Commit: c899ea706d9ac59f148ad231a39cfb3cbb11ebde  
Time: Sat May 3 16:36:44 2014   

-----

```
commit c899ea706d9ac59f148ad231a39cfb3cbb11ebde
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat May 3 16:36:44 2014 +0000

    Fix zero length DMA behavior.  Fixes Animal Crossing (others?).
```
