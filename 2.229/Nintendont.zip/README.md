# Nintendont 2.229
Commit: 2995cbd8173dd2511feef3b178b9150244d84566  
Time: Thu Nov 27 02:51:46 2014   

-----

```
commit 2995cbd8173dd2511feef3b178b9150244d84566
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Thu Nov 27 02:51:46 2014 +0000

    -Fixed gamecube adapter for wii u wavebird support with gray cable unplugged
    -Disabled rumble on gamecube adapter for wii u wavebird when the gray cable is unplugged
    -Fixed boot status error message display
    -Increased boot status error message display time before reboot
    -Added boot status error "Gamecube adapter for Wii u init error"
    -Added boot status message "Init HID devices... Using ONLY NATIVE Gamecube Ports"
```
