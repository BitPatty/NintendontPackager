# Nintendont 5.470
Commit: 53edd8d3d4f37b2268954e5a719344b8af8865c0  
Time: Wed Oct 11 08:38:38 2017   

-----

```
commit 53edd8d3d4f37b2268954e5a719344b8af8865c0
Author: FIX94 <fix94.1@gmail.com>
Date:   Wed Oct 11 08:38:38 2017 +0200

    added support for brazilian mpal v1.1 gamecube bios
```
