# Nintendont 4.410
Commit: f249dee207b2ebc42021998fb03f94136bec6597  
Time: Tue Jun 21 00:34:34 2016   

-----

```
commit f249dee207b2ebc42021998fb03f94136bec6597
Author: FIX94 <fix94.1@gmail.com>
Date:   Tue Jun 21 00:34:34 2016 +0200

    -added triforce virtua striker 2002 patches to now actually initialize the media board in the way nintendont emulates it instead of skipping the media board init
```
