# Nintendont 2.213
Commit: a29048cc0a329654391c2032d50138cec10b5d78  
Time: Mon Nov 10 17:53:41 2014   

-----

```
commit a29048cc0a329654391c2032d50138cec10b5d78
Author: cyan@mangaheart.org <cyan@mangaheart.org@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Nov 10 17:53:41 2014 +0000

    - Fix game region detection when video mode set to Auto or None.
```
