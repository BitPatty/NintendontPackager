# Nintendont 3.398
Commit: f5d0c79f26f045ea156f1813364c125015627929  
Time: Tue May 24 15:44:15 2016   

-----

```
commit f5d0c79f26f045ea156f1813364c125015627929
Merge: e3a2db7 b23fed9
Author: FIX94 <fix94.1@gmail.com>
Date:   Tue May 24 15:44:15 2016 +0200

    Merge pull request #246 from GerbilSoft/gpt-support-v3.rebase-for-merge
    
    GPT Support v3: Ignore EFI System Partition; support MBR extended; code optimizations
```

```
commit e3a2db70dabcc9cef5092bf65eabf77b7304f07d
Author: FIX94 <fix94.1@gmail.com>
Date:   Mon May 23 01:43:56 2016 +0200

    -added a total of 19 demos into their respective arstartdma exception lists (as we know from the full versions), pleast let me know if I missed anything
    -added in a new dsp patch found in the us demo of pikmin 1
```
