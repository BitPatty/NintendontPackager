# Nintendont 5.459
Commit: cef0ee0261e337e8356dc8a67bfa071db125581c  
Time: Wed Sep 20 22:28:59 2017   

-----

```
commit cef0ee0261e337e8356dc8a67bfa071db125581c
Author: FIX94 <fix94.1@gmail.com>
Date:   Wed Sep 20 22:28:59 2017 +0200

    -corrected value that wasnt moved in the last rev (made some games uncontrollable)
    -add proper shutdown wait in bluetooth code (this is why it sometimes froze on exit)
    -cleaned up interrupt code to just its essentials
```
