# Nintendont 4.439
Commit: 39905674297f41c377d35d27faaa8d08cbc262d1  
Time: Thu Apr 27 18:18:34 2017   

-----

```
commit 39905674297f41c377d35d27faaa8d08cbc262d1
Author: FIX94 <fix94.1@gmail.com>
Date:   Thu Apr 27 18:18:34 2017 +0200

    -put dora the explorer into the manually invalidated disc data exception list to make it properly bootable (issue #400)
```
