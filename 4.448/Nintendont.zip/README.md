# Nintendont 4.448
Commit: ee65e45a99f7f0b57e126d0684f6382780f2ac6c  
Time: Sat Aug 12 23:49:41 2017   

-----

```
commit ee65e45a99f7f0b57e126d0684f6382780f2ac6c
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Aug 12 23:49:41 2017 +0200

    added support for more virtua striker 3/4 versions
```
