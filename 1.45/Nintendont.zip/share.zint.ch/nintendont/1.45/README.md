# Nintendont 1.45
Commit: fd20c6a79b97c9fc50b950114ef7ec7cb669b249  
Time: Wed May 14 05:18:32 2014   

-----

```
commit fd20c6a79b97c9fc50b950114ef7ec7cb669b249
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed May 14 05:18:32 2014 +0000

    -Added disk read activity led support
    -Fixed dump that could occur when the last line on controller.ini didn't have a carriage return linefeed
    -Added testing of file system on SD: to match testing on usb:
    -Added message to loading patched kernel 8 indicating using gamecube ports
```
