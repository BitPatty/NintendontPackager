# Nintendont 1.83
Commit: 1aca712007ae1ce61a06c3907ef0ec47c6da3f52  
Time: Sat Jun 7 19:37:29 2014   

-----

```
commit 1aca712007ae1ce61a06c3907ef0ec47c6da3f52
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Jun 7 19:37:29 2014 +0000

    Fix ARStartDMA mem1 addressing.
    -Fixes Star Wars Rogue Squadron
```
