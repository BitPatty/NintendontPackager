# Nintendont 1.138
Commit: b71209ae38fe878cad534bc8a40127f406c1ba07  
Time: Thu Aug 7 22:41:41 2014   

-----

```
commit b71209ae38fe878cad534bc8a40127f406c1ba07
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Thu Aug 7 22:41:41 2014 +0000

    Undo unnecessary complicated memorycard memory processing and just avoid overwriting kernel memory.
```
