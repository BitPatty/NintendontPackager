# Nintendont 4.436
Commit: a1e4a337f903f5d229c658f5bcf61ab4de372ba7  
Time: Sun Feb 5 17:48:59 2017   

-----

```
commit a1e4a337f903f5d229c658f5bcf61ab4de372ba7
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Feb 5 17:48:59 2017 +0100

    added dma exception patch for one piece treasure battle and updated controller configs
```
