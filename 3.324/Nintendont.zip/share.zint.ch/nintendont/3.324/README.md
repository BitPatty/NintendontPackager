# Nintendont 3.324
Commit: bf9491647afba95b42b02dc30954ca65256c4777  
Time: Sun Mar 15 20:44:50 2015   

-----

```
commit bf9491647afba95b42b02dc30954ca65256c4777
Author: cyan@mangaheart.org <cyan@mangaheart.org@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Mar 15 20:44:50 2015 +0000

    - Fixed autoboot with arguments if HID controller is connected (Thanks Airline38)
    - Added version string for version detection by external loaders (Thanks GreyWolf)
```
