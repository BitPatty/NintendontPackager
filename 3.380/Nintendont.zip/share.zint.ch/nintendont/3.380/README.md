# Nintendont 3.380
Commit: 220973f6b3ac4e188184a057008aa7a1254a566b  
Time: Sat Dec 5 18:19:01 2015   

-----

```
commit 220973f6b3ac4e188184a057008aa7a1254a566b
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Dec 5 18:19:01 2015 +0100

    why do I always forget the .S files hm
```

```
commit b34879fd458b3fb6b43a3b47d8d12ecebed1f937
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Dec 5 17:43:41 2015 +0100

    -added support for rev c and rev e of f-zero ax and added a missing patch for virtua striker 4 (export)
```
