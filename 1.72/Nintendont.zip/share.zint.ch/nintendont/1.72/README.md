# Nintendont 1.72
Commit: 70177ab764f365f183274a4f7db5aec7839efcf8  
Time: Sun Jun 1 20:43:38 2014   

-----

```
commit 70177ab764f365f183274a4f7db5aec7839efcf8
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Jun 1 20:43:38 2014 +0000

    -added more patch exceptions to fix Dragon Drive, Odama and True Crime New York
    -fixed wrong game save timestamp
    -mario kart gp1 works now
    -finished up the triforce controls code so it now returns to hbc and works with usb controllers
```

```
commit 19b1b151a2722c21ee2df3f3b74692b7811400bb
Author: crediar@rypp.net <crediar@rypp.net@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Jun 1 16:12:53 2014 +0000

    *Increase code size in linker script and updated related code
    *Added JVS-IO emulation
    *Added Baseboard emulation
    *Added DIMM board emulation
```
