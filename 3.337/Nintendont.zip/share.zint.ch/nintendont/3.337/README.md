# Nintendont 3.337
Commit: 09ac8dd5220b84a14083afdd0a728b5becc313c6  
Time: Sun May 17 19:50:37 2015   

-----

```
commit 09ac8dd5220b84a14083afdd0a728b5becc313c6
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun May 17 19:50:37 2015 +0200

    Create README.md
```

```
commit 85d7621bceec8d47c04a2ae6d49b34a3221ee122
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat May 16 03:26:17 2015 +0200

    -added a second hook for the codehandler to allow cheat support in a wider variety of games
```
