# Nintendont 3.396
Commit: 835c13db7e561a29fa95bf2d820c451c71ed4967  
Time: Fri May 20 20:03:44 2016   

-----

```
commit 835c13db7e561a29fa95bf2d820c451c71ed4967
Author: FIX94 <fix94.1@gmail.com>
Date:   Fri May 20 20:03:44 2016 +0200

    -removed all sorts of old patches which havent been used for a long time/ever
    -set the kernel code optimization to -O3 for max speed
    -some more small patcher optimizations
```
