# Nintendont 1.47
Commit: e689dbcb6e01b8ce0c0481b5a25dea3b5fbf3575  
Time: Wed May 14 21:15:54 2014   

-----

```
commit e689dbcb6e01b8ce0c0481b5a25dea3b5fbf3575
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed May 14 21:15:54 2014 +0000

    -added missing parts for drive led to still work
```
