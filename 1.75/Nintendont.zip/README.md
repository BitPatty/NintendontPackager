# Nintendont 1.75
Commit: 9101cd4a9f24facbfc9df8d7ab8715c3ad58e7bc  
Time: Mon Jun 2 05:03:58 2014   

-----

```
commit 9101cd4a9f24facbfc9df8d7ab8715c3ad58e7bc
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Jun 2 05:03:58 2014 +0000

    Fix disc swapping.
    -Also clears cache when swapping discs.
    Use corrected ARStartDMA for all games for interrupt timing.  (Original attempt missed an exchange for r6/r7).
```
