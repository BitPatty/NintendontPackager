# Nintendont 1.115
Commit: a80ee900272c6eb77a82cf3872b7fdaad5956c5b  
Time: Wed Jul 2 20:18:47 2014   

-----

```
commit a80ee900272c6eb77a82cf3872b7fdaad5956c5b
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Jul 2 20:18:47 2014 +0000

    Add exceptions to ARStartDMA
    -Mario Baseball
    -Viewtiful Joe
    Combine common shutdown code in PADReadGC.S
    Add Dspv13.
```
