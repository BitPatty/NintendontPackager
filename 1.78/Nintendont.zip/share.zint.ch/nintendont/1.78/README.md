# Nintendont 1.78
Commit: 2c5a395369105afa515cdb2e5b28b6286477d090  
Time: Tue Jun 3 19:28:04 2014   

-----

```
commit 2c5a395369105afa515cdb2e5b28b6286477d090
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Jun 3 19:28:04 2014 +0000

    -always skip SITransfer if its a normal gc game
    -skip ARQPostRequest unless we are booting super mario sunshine
    -use length 0 for ARStartDMA unless we boot mega man x command mission
```
