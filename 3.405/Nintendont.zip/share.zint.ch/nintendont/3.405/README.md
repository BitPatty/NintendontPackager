# Nintendont 3.405
Commit: 3c87be35f85d44cf2270005c9486499f861b4106  
Time: Sat Jun 18 16:30:26 2016   

-----

```
commit 3c87be35f85d44cf2270005c9486499f861b4106
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Jun 18 16:30:26 2016 +0200

    -added triforce patch to disable all the DI encryption, this should get rid of the random shutdown problems while playing triforce games
```
