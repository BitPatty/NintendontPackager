# Nintendont 4.442
Commit: 13e76cc77f1708fa50dbb1214a9cd7039c7d46d4  
Time: Sun May 14 18:10:07 2017   

-----

```
commit 13e76cc77f1708fa50dbb1214a9cd7039c7d46d4
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun May 14 18:10:07 2017 +0200

    added pal dol size for sonic the fighters in sonic gems collection
```
