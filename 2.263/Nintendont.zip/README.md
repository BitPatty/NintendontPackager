# Nintendont 2.263
Commit: c175ecd333f7a2feb305dcbb412d483ea8af6371  
Time: Tue Dec 23 16:48:51 2014   

-----

```
commit c175ecd333f7a2feb305dcbb412d483ea8af6371
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Dec 23 16:48:51 2014 +0000

    -added multi-iso disc support, it has been verified to work from burned discs, wode and as direct iso on sd/usb
    -slightly adjusted the loader game selection, the controls should be a bit better now
```
