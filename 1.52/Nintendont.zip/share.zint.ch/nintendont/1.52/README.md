# Nintendont 1.52
Commit: 148083f402e7dd7f0ed195b18d9fe72e5cb6b842  
Time: Sun May 18 13:00:33 2014   

-----

```
commit 148083f402e7dd7f0ed195b18d9fe72e5cb6b842
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun May 18 13:00:33 2014 +0000

    -added some code to fix games like pal luigis mansion
    -added a new bin2h, this one should be compilable for linux etc as well
```
