# Nintendont 1.112
Commit: b758e02aaceffe62a3fc58b4cea5db2d6fb3fbd4  
Time: Wed Jul 2 06:03:29 2014   

-----

```
commit b758e02aaceffe62a3fc58b4cea5db2d6fb3fbd4
Author: crediar@rypp.net <crediar@rypp.net@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Jul 2 06:03:29 2014 +0000

    *Added shut down via power button
```
