# Nintendont 2.171
Commit: d610679ed9687707f44eed963a06133d367915ce  
Time: Sun Oct 12 15:38:06 2014   

-----

```
commit d610679ed9687707f44eed963a06133d367915ce
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Oct 12 15:38:06 2014 +0000

    -did some more patchwork, now most of our required patches get applied dynamically, this should fix up some problems with games using the debug version of the sdk
    -commented out the multidol loader code for now, with this update all those game should work properly on their own with the corrected patches
```
