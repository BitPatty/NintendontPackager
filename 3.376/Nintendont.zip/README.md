# Nintendont 3.376
Commit: 145c8d269d752c129d2e95a445095a35b254753d  
Time: Fri Nov 20 15:41:12 2015   

-----

```
commit 145c8d269d752c129d2e95a445095a35b254753d
Author: FIX94 <fix94.1@gmail.com>
Date:   Fri Nov 20 15:41:12 2015 +0100

    -added back missing ax timer patch and fixed its analog inputs (they behave a little different from quadforce)
```
