# Nintendont 2.237
Commit: dec81fd6cd273a799e642be8aea023af47cc34ed  
Time: Wed Dec 3 16:44:10 2014   

-----

```
commit dec81fd6cd273a799e642be8aea023af47cc34ed
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Dec 3 16:44:10 2014 +0000

    -added proper luigis mansion widescreen patch for all regions to solve random crashes with the default one
```
