# Nintendont 1.80
Commit: 01c75b58e4b6609cd53e8181811545f40341f91e  
Time: Wed Jun 4 20:56:21 2014   

-----

```
commit 01c75b58e4b6609cd53e8181811545f40341f91e
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Jun 4 20:56:21 2014 +0000

    -fixed a potential problem with ps3 controllers where the memory allocation for the rumble can interfere with the disc reading thread thanks the debug log provided by daxtsu
```
