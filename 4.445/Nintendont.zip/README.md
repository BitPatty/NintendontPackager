# Nintendont 4.445
Commit: ed9e9099c83fd2d946f9cc3f25158ff6667fdd9b  
Time: Sun Jun 18 19:36:35 2017   

-----

```
commit ed9e9099c83fd2d946f9cc3f25158ff6667fdd9b
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Jun 18 19:36:35 2017 +0200

    -added patch to Swingerz Golf NTSC-U to allow forcing other video modes
    -extended getTiming patch to fix a few more games when forcing other video modes (such as Crazy Taxi NTSC-U)
    -clearing out more cache of controller inputs to allow controllers with bigger messages to work properly
```
