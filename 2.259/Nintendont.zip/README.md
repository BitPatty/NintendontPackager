# Nintendont 2.259
Commit: 67aebc97dbf48a49f67a3da7cf2b80965fa131c8  
Time: Sat Dec 20 00:10:23 2014   

-----

```
commit 67aebc97dbf48a49f67a3da7cf2b80965fa131c8
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Dec 20 00:10:23 2014 +0000

    -resetting wiiu widescreen setting after the game finished to make sure we are on the right one
    -added some basic disc reading on wii which supports the most basic features, its the very first "game" for wii users and supports pretty much everything which is supported from normal sd and usb reading, its not quite finished yet
    -updated all registers needed to not use the original disc drive registers anymore
```
