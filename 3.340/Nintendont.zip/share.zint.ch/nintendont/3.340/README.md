# Nintendont 3.340
Commit: 1e5479d9756f2efe37863b5f74a817dbe979001e  
Time: Sun May 24 19:00:26 2015   

-----

```
commit 1e5479d9756f2efe37863b5f74a817dbe979001e
Merge: 259486d 8c105b8
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun May 24 19:00:26 2015 +0200

    Merge branch 'master' of https://github.com/FIX94/Nintendont
```

```
commit 259486d69f85a757a768ad3c0385d32a0fd662ad
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun May 24 18:59:33 2015 +0200

    -removed majoras mask sound workaround again, its too unstable to be used right now
    -added workaround for midway arcade treasures 2 initial beeping by initializing sound engine on the intro video begin
    -added workaround for powerpuff girls ntsc and pal missing video sound
```
