# Nintendont 2.249
Commit: ffaa7590eb5c4991c5120e59319fd9061e0c5e9e  
Time: Tue Dec 9 17:47:41 2014   

-----

```
commit ffaa7590eb5c4991c5120e59319fd9061e0c5e9e
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Dec 9 17:47:41 2014 +0000

    -removed most DVD patches except __DVDInterruptHandler and GCAMSendCommand and replaced it with a full register search, this update might break games, it needs quite some testing to be sure
```
