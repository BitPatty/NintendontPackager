# Nintendont 3.327
Commit: cef5c00f5e8312518ce8401c7b5b5379453cc05b  
Time: Sun Apr 12 20:02:19 2015   

-----

```
commit cef5c00f5e8312518ce8401c7b5b5379453cc05b
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Apr 12 20:02:19 2015 +0000

    -added hunter the reckoning exception
    -added missing audio stream playback check, fixes tony hawk pro skater 3 never pausing its audio stream
```
