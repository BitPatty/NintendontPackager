# Nintendont 4.430
Commit: 6c78e6fccbc008f919711474155993e801538002  
Time: Sun Dec 18 02:05:24 2016   

-----

```
commit 6c78e6fccbc008f919711474155993e801538002
Merge: 004c2c6 eefe868
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Dec 18 02:05:24 2016 +0100

    Merge pull request #343 from greyrogue/master
    
    Fix Datel AGP
```

```
commit 004c2c6132b13c74e9fd9f0edaf3f6ff9771aa63
Merge: adf3de5 a4012d5
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Dec 3 05:17:45 2016 +0100

    Merge pull request #338 from GerbilSoft/bugfix/disc2.off-by-one.r429
    
    Fix off-by-one in 2disc
```
