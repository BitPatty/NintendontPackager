# Nintendont 2.301
Commit: 36a9d2dbe176808ef068c1f7f1191a4ced9e5d6b  
Time: Thu Feb 19 22:46:26 2015   

-----

```
commit 36a9d2dbe176808ef068c1f7f1191a4ced9e5d6b
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Thu Feb 19 22:46:26 2015 +0000

    -updated the pso patches to now work with all pso1&2 and pso3 pal and ntsc versions even when compressed
```
