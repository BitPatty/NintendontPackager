# Nintendont 2.222
Commit: cc00c799c72348fe83e57da602616bb4f09e61eb  
Time: Fri Nov 21 23:14:31 2014   

-----

```
commit cc00c799c72348fe83e57da602616bb4f09e61eb
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Nov 21 23:14:31 2014 +0000

    -further worked on the per-game widescreen patches, now also animal crossing and all mario party games have proper patches
    -added code to hopefully help recent blackscreens with memcard emu enabled
```
