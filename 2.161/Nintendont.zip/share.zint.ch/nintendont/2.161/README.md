# Nintendont 2.161
Commit: be39d3be7d321f9e98b2a835637d32fca16abd91  
Time: Tue Sep 16 12:38:15 2014   

-----

```
commit be39d3be7d321f9e98b2a835637d32fca16abd91
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Sep 16 12:38:15 2014 +0000

    -Fixed Bluetooth TR remotes requiring an expansion controller needing to be disconnected and then reconnected to sync.
    -updated Thrustmaster Dual Analog 4 controller.ini to support ZL button (Thanks nastysdsi)
```
