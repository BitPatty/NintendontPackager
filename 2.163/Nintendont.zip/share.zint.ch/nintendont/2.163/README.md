# Nintendont 2.163
Commit: 18ea1c595d001eb5fd608535cc31507bcc342c03  
Time: Thu Sep 25 18:24:10 2014   

-----

```
commit 18ea1c595d001eb5fd608535cc31507bcc342c03
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Thu Sep 25 18:24:10 2014 +0000

    -Fixed HID controller analog triggers being broken since v2.158
```
