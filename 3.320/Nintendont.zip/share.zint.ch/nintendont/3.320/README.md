# Nintendont 3.320
Commit: 667b9cff2916b1632b90a782142ed855ae405819  
Time: Wed Mar 11 20:22:50 2015   

-----

```
commit 667b9cff2916b1632b90a782142ed855ae405819
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Mar 11 20:22:50 2015 +0000

    -added back a slighly modified version of Patch31A0 because it appears to be needed in certain situations, also made some small modifications with the memory usage of patches
    -slightly modified the game start process to make sure everything gets inited in the correct order
```
