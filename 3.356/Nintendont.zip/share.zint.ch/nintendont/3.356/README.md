# Nintendont 3.356
Commit: a422b4e13346ff505b14f10d66f581123b5967d5  
Time: Fri Jul 17 11:35:17 2015   

-----

```
commit a422b4e13346ff505b14f10d66f581123b5967d5
Author: FIX94 <fix94.1@gmail.com>
Date:   Fri Jul 17 11:35:17 2015 +0200

    -apply video patches on video scale and offset change too
```
