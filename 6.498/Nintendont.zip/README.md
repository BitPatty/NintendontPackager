# Nintendont 6.498
[Direct Download](./Nintendont.zip)

Commit: 5cfb2f17765cf0722865c0a9aba22402bf182283  
Time: Sun Sep 5 14:07:29 2021   

-----

```
commit 5cfb2f17765cf0722865c0a9aba22402bf182283
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Sun Sep 5 14:07:29 2021 +0100

    forgot to check for triforce
```

```
commit 6f8bf7348eeafa96a91111478b5bad52f82ae4c8
Author: pedro702 <pedroaxel15@hotmail.com>
Date:   Sun Sep 5 13:58:24 2021 +0100

    Re-enabled Iso cache
    
    Lots of games had random freezes without iso cache, so i re-enabled it for all games but fire emblem, seems much more stable  now.
```
