# Nintendont 4.440
Commit: bb6802e12fc0aa2ff34ffbd7a03054d6b0f3c32a  
Time: Sat May 6 00:38:01 2017   

-----

```
commit bb6802e12fc0aa2ff34ffbd7a03054d6b0f3c32a
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat May 6 00:38:01 2017 +0200

    corrected silly #define mistake which broke cheats and possibly more
```
