# Nintendont 2.202
Commit: eb18eb5b587ba8b69547e596615030d414e3a6cd  
Time: Sat Nov 1 19:44:05 2014   

-----

```
commit eb18eb5b587ba8b69547e596615030d414e3a6cd
Author: JoostinOnline@gmail.com <JoostinOnline@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Nov 1 19:44:05 2014 +0000

    -Fixed the update system (still don't know why it wasn't working for some people)
    -Updated controllers.zip
```
