# Nintendont 1.77
Commit: 988364d9cbb797a8031590e82775c19f1ec0cd7d  
Time: Tue Jun 3 12:41:08 2014   

-----

```
commit 988364d9cbb797a8031590e82775c19f1ec0cd7d
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Jun 3 12:41:08 2014 +0000

    -skip SITransfer for mario strikers so it stays controllable
    -use ARStartDMA length 0 for melee and kirby air ride so it doesnt freeze
```
