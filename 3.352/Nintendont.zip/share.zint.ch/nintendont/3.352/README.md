# Nintendont 3.352
Commit: 79ac3d9045fa14dd8bc9dc4b3b12b788eb62b321  
Time: Sun Jul 5 14:39:38 2015   

-----

```
commit 79ac3d9045fa14dd8bc9dc4b3b12b788eb62b321
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Jul 5 14:39:38 2015 +0200

    -ARStartDMA now will actively refuse to write out of its memory bounds, this fixes ultimate spiderman memory card emu problems
```
