# Nintendont 4.441
Commit: ec2c15e608ec34ce16a48c68e4614e45dbd66a12  
Time: Sun May 7 23:55:09 2017   

-----

```
commit ec2c15e608ec34ce16a48c68e4614e45dbd66a12
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun May 7 23:55:09 2017 +0200

    dont use hardcoded memory for ciso check since that breaks memcard emu in certain situations (issue #409)
```
