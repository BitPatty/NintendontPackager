# Nintendont 1.127
Commit: fedd640097130d96dfb8d5ae3056cf39948cda6c  
Time: Thu Jul 10 21:35:05 2014   

-----

```
commit fedd640097130d96dfb8d5ae3056cf39948cda6c
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Thu Jul 10 21:35:05 2014 +0000

    -heavly increased sd buffer from 2kb to 64kb which makes playing from slow sd cards actually enjoyable
    -fixed two possible small patch bugs
```
