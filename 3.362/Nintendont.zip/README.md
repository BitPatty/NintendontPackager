# Nintendont 3.362
Commit: 97c0479995609fc075bd4babc655cf8bcdbb5b6f  
Time: Sat Jul 25 12:29:22 2015   

-----

```
commit 97c0479995609fc075bd4babc655cf8bcdbb5b6f
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Jul 25 12:29:22 2015 +0200

    the curse of the commit button strikes again...
```

```
commit 9cb54cb5f69eb956164dcd4a35484eaafe4abf57
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Jul 25 12:25:45 2015 +0200

    -ipl patch correction, its more complex than I thought
```
