# Nintendont 1.55
Commit: d24d5ad2bef3e31bed5a48a995bcbe9cc8d54345  
Time: Wed May 21 20:13:00 2014   

-----

```
commit d24d5ad2bef3e31bed5a48a995bcbe9cc8d54345
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed May 21 20:13:00 2014 +0000

    -you can now use gc and hid controller at the same time on a wii, if hid is enabled it will still check the gc ports if you are using a normal wii
```
