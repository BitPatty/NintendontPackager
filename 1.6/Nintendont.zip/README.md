# Nintendont 1.6
Commit: 7a39981fd5c8a49ee6aedfbe6519f20bc4641b13  
Time: Mon Apr 28 19:18:24 2014   

-----

```
commit 7a39981fd5c8a49ee6aedfbe6519f20bc4641b13
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Apr 28 19:18:24 2014 +0000

    Revert minor DSP change from r13.
```
