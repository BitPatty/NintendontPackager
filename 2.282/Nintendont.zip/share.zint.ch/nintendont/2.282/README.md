# Nintendont 2.282
Commit: 04ed31b0607e4673d4f135dde895b554632e8f0f  
Time: Sun Jan 25 15:26:48 2015   

-----

```
commit 04ed31b0607e4673d4f135dde895b554632e8f0f
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Jan 25 15:26:48 2015 +0000

    -removed sonic adventure dx again from the pad exception list, that game must've been fixed with some previous change
    -added a proper f-zero ax widescreen patch, thanks CosmoCortney
    -removed a few mario kart gp2 menu timers, thanks conanac
```
