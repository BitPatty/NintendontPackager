# Nintendont 2.275
Commit: 5e5e605b0af9ca958c841cad0ddf216c3d167f06  
Time: Fri Jan 9 19:28:34 2015   

-----

```
commit 5e5e605b0af9ca958c841cad0ddf216c3d167f06
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Fri Jan 9 19:28:34 2015 +0000

    -hopefully improved the audio streaming code to not crash certain games on the end of the audio file
    -added triforce video mode patches so all 4 triforce games can be patched to run with force progressive
```
