# Nintendont 3.354
Commit: 686dc3709ec2b63770161bd065457695c1151993  
Time: Sun Jul 12 12:58:32 2015   

-----

```
commit 686dc3709ec2b63770161bd065457695c1151993
Author: FIX94 <fix94.1@gmail.com>
Date:   Sun Jul 12 12:58:32 2015 +0200

    -setting name correction
```

```
commit 36a2eb4b159e0272f6a1726ede0bc06edde42866
Author: FIX94 <fix94.1@gmail.com>
Date:   Sat Jul 11 21:10:59 2015 +0200

    -added 2 new settings which allow the modification of the video width as well as the vertical video offset, this should help in getting gc games to fullscreen if required, note that this way will worsen the picture quality as a tradeoff
```
