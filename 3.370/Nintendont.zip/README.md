# Nintendont 3.370
Commit: a8d3e6167288f4ae91179ddf945e9c84036342b8  
Time: Fri Aug 7 01:22:27 2015   

-----

```
commit a8d3e6167288f4ae91179ddf945e9c84036342b8
Author: FIX94 <fix94.1@gmail.com>
Date:   Fri Aug 7 01:22:27 2015 +0200

    -set menu timer in mario kart gp1 invisible
    -set coin count in mario kart gp1 and gp2 invisible
```
