# Nintendont 2.190
Commit: 987fa570fbfa0c7e7b420f953bd23461c32fa60b  
Time: Thu Oct 23 02:22:36 2014   

-----

```
commit 987fa570fbfa0c7e7b420f953bd23461c32fa60b
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Thu Oct 23 02:22:36 2014 +0000

    Fix Native Control/PATCHSI backwards logic.
```
