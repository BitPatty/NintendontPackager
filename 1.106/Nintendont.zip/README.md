# Nintendont 1.106
Commit: f6c63e34122ed5cafc3c05797e27e2526ee58180  
Time: Mon Jun 30 05:26:59 2014   

-----

```
commit f6c63e34122ed5cafc3c05797e27e2526ee58180
Author: greyrogue@gmail.com <greyrogue@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Jun 30 05:26:59 2014 +0000

    Code cleanup
    -Combine GC and HID Pad functions
    -Use enum for 0xdead function patterns.
    -Minor ARStartDMA rearranging.
```
