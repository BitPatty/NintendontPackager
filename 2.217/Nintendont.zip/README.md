# Nintendont 2.217
Commit: cc76d8542dc7ba9672a293921af90fc224ebc630  
Time: Sat Nov 15 23:53:25 2014   

-----

```
commit cc76d8542dc7ba9672a293921af90fc224ebc630
Author: JoostinOnline@gmail.com <JoostinOnline@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sat Nov 15 23:53:25 2014 +0000

    -Reapplied the new UI with a truetype font
    -Increased the number of games shown on one screen
    -Increased the number of characters shown per-title
    -Slowed down scrolling up/down and sped up left/right
    -Fixed Nintendont not running without an SD card inserted
    -Fixed a warning in Patch.c if DEBUG_PATCH was disabled
    
    NOTE: Don't bother asking for a full GUI, coverflow, or anything else graphics related.  This is as good as it's going to get.  Use another loader if you want something nicer.  The purpose was to make the text easier to read on small screens, and to add flexibility for the devs by making font size customizable.
```
