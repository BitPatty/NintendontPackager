# Nintendont 2.265
Commit: e6c7e0a628d30043fe5ada8df3e21c7456585f34  
Time: Wed Dec 24 15:21:10 2014   

-----

```
commit e6c7e0a628d30043fe5ada8df3e21c7456585f34
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Wed Dec 24 15:21:10 2014 +0000

    -Added Support for some generic Classic controllers (Thanks Abz)
```
