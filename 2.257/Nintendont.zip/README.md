# Nintendont 2.257
Commit: cda8e887d7323c55e2842052ce3f3af7c6c5eb07  
Time: Tue Dec 16 23:25:11 2014   

-----

```
commit cda8e887d7323c55e2842052ce3f3af7c6c5eb07
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Dec 16 23:25:11 2014 +0000

    -made the constantly refreshed HID messages part of the nintendont kernel memory instead of always newly allocating it to try help out stability
```
