# Nintendont 3.389
Commit: 4d5530df4c03608e28bc0ac5811e76f014122dad  
Time: Wed Apr 20 18:01:30 2016   

-----

```
commit 4d5530df4c03608e28bc0ac5811e76f014122dad
Author: FIX94 <fix94.1@gmail.com>
Date:   Wed Apr 20 18:01:30 2016 +0200

    -added getTiming patch which acts as a anti-crash patch when forcing pal60 on old ntsc sdk games such as luigis mansion
```
