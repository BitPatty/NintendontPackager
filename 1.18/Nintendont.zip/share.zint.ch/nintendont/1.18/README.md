# Nintendont 1.18
Commit: 69d40693f379f70f4ce911080ee784f21a3144e0  
Time: Tue Apr 29 19:56:40 2014   

-----

```
commit 69d40693f379f70f4ce911080ee784f21a3144e0
Author: JoostinOnline@gmail.com <JoostinOnline@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Apr 29 19:56:40 2014 +0000

    Added elf file for analyzing code dumps.
```

```
commit fd708c01094923321f0238c00d2562066e8305a7
Author: Howard_M_Busch@yahoo.com <Howard_M_Busch@yahoo.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Tue Apr 29 07:15:03 2014 +0000

    Forgot the .dol
```
