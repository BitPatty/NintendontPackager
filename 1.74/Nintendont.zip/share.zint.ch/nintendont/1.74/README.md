# Nintendont 1.74
Commit: c247c18732098c06d2379c10612ab7dbf2dccd2f  
Time: Sun Jun 1 22:34:15 2014   

-----

```
commit c247c18732098c06d2379c10612ab7dbf2dccd2f
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Sun Jun 1 22:34:15 2014 +0000

    -changed up disc reading and other small stuff
```
