# Nintendont 1.133
Commit: 849cfbf4b50d8bc665e02a8fd798403f4845ffe8  
Time: Mon Aug 4 17:39:23 2014   

-----

```
commit 849cfbf4b50d8bc665e02a8fd798403f4845ffe8
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Aug 4 17:39:23 2014 +0000
```

```
commit 5c29db040eab9e6cb826e03e865a15fa3cdf0013
Author: fix94.1@gmail.com <fix94.1@gmail.com@6acfca08-c3de-247c-4448-9f1a92385553>
Date:   Mon Aug 4 17:23:06 2014 +0000

    -32-bit aligning the addresses of ARStartDMA, this will fix the background music in megaman collection
    -added a hardcoded fix for the too fast videos in megaman collection
    -cleaned up FakeInterrupt
```
